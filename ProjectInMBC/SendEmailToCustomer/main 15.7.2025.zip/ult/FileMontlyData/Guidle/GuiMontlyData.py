import tkinter as tk
from tkinter import messagebox, ttk, filedialog
import os
import pandas as pd
import calendar
import datetime

CHECK_DIR = os.path.join(os.getcwd(), "DATASETC", "dataMontlydata", "Check")
os.makedirs(CHECK_DIR, exist_ok=True)
CHECK_CSV = os.path.join(CHECK_DIR, "DataMontlyCheck.csv")
DATA_CSV = os.path.join(os.getcwd(), "DATASETC", "dataMontlydata", "dataMontly.csv")
DISPLAY_COLUMNS = ["Chủng loại", "Mã hàng", "Khách hàng", "Link", "Status"]

def update_check_data():
    # Xóa file cũ nếu có
    if os.path.exists(CHECK_CSV):
        os.remove(CHECK_CSV)
    # Đọc dataMontly.csv
    if os.path.exists(DATA_CSV):
        df = pd.read_csv(DATA_CSV, encoding="utf-8-sig")
        # Thêm cột Link, Status nếu chưa có
        if "Link" not in df.columns:
            df["Link"] = ""
        if "Status" not in df.columns:
            df["Status"] = ""
        df = df[["Chủng loại", "Mã hàng", "Khách hàng", "Link", "Status"]]
        df.to_csv(CHECK_CSV, index=False, encoding="utf-8-sig")
    else:
        df = pd.DataFrame(columns=DISPLAY_COLUMNS)
        df.to_csv(CHECK_CSV, index=False, encoding="utf-8-sig")

def load_check_data():
    if os.path.exists(CHECK_CSV):
        try:
            return pd.read_csv(CHECK_CSV, encoding="utf-8-sig")
        except Exception:
            return pd.DataFrame(columns=DISPLAY_COLUMNS)
    return pd.DataFrame(columns=DISPLAY_COLUMNS)

def save_check_data(df):
    df.to_csv(CHECK_CSV, index=False, encoding="utf-8-sig")

def open_gui_monthly_data(root):
    window = tk.Toplevel(root)
    window.title("Gửi Monthly Data")
    window.geometry("1200x700")
    window.configure(bg="#e8ecef")
    window.lift()
    window.grab_set()
    window.focus_force()

    # ==== Khu vực chọn file KJS và chọn tháng ====
    frame_top = tk.Frame(window, bg="#e8ecef")
    frame_top.pack(pady=10, fill="x")

    # Chọn file KJS
    tk.Label(frame_top, text="Chọn file KJS:", font=("Helvetica", 12), bg="#e8ecef").pack(side=tk.LEFT, padx=(10,0))
    entry_kjs = tk.Entry(frame_top, width=40, font=("Helvetica", 12))
    entry_kjs.pack(side=tk.LEFT, padx=5)
    def select_kjs_file():
        path = filedialog.askopenfilename(title="Chọn file KJS", filetypes=[("Excel/CSV", "*.xlsx *.xls *.csv"), ("All files", "*.*")])
        if path:
            entry_kjs.delete(0, tk.END)
            entry_kjs.insert(0, path)
    tk.Button(frame_top, text="Chọn", command=select_kjs_file, font=("Helvetica", 11, "bold"), bg="#3498db", fg="white", padx=10).pack(side=tk.LEFT, padx=5)

    # Chọn tháng
    tk.Label(frame_top, text="Chọn tháng:", font=("Helvetica", 12), bg="#e8ecef").pack(side=tk.LEFT, padx=(30,0))
    month_var = tk.StringVar()
    def pick_month():
        top = tk.Toplevel(window)
        top.title("Chọn tháng")
        top.geometry("300x120")
        top.configure(bg="#e8ecef")

        # Chọn tháng
        tk.Label(top, text="Tháng:", font=("Helvetica", 12), bg="#e8ecef").pack(pady=5)
        month_cb = ttk.Combobox(top, values=[f"{i:02d}" for i in range(1, 13)], width=5, font=("Helvetica", 12), state="readonly")
        month_cb.pack()
        month_cb.set(datetime.datetime.now().strftime("%m"))

        # Chọn năm
        tk.Label(top, text="Năm:", font=("Helvetica", 12), bg="#e8ecef").pack(pady=5)
        year_cb = ttk.Combobox(top, values=[str(y) for y in range(datetime.datetime.now().year-3, datetime.datetime.now().year+4)], width=7, font=("Helvetica", 12), state="readonly")
        year_cb.pack()
        year_cb.set(datetime.datetime.now().strftime("%Y"))

        def set_month():
            month_var.set(f"{month_cb.get()}/{year_cb.get()}")
            top.destroy()
        tk.Button(top, text="Chọn", command=set_month, font=("Helvetica", 12, "bold"), bg="#27ae60", fg="white").pack(pady=10)

    entry_month = tk.Entry(frame_top, textvariable=month_var, width=10, font=("Helvetica", 12))
    entry_month.pack(side=tk.LEFT, padx=5)
    tk.Button(frame_top, text="Chọn tháng", command=pick_month, font=("Helvetica", 11, "bold"), bg="#3498db", fg="white", padx=10).pack(side=tk.LEFT, padx=5)

    # Nút Update dữ liệu
    def update_data():
        update_check_data()
        refresh_tree()

    # TreeView
    frame_table = tk.Frame(window, bg="#e8ecef")
    frame_table.pack(pady=10, fill="both", expand=True)
    tree = ttk.Treeview(frame_table, columns=DISPLAY_COLUMNS, show="headings", height=20)
    for col in DISPLAY_COLUMNS:
        tree.heading(col, text=col)
        tree.column(col, width=200, anchor="center")
    tree.pack(side="left", fill="both", expand=True)
    scrollbar = ttk.Scrollbar(frame_table, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=scrollbar.set)
    scrollbar.pack(side="right", fill="y")

    # Load data
    df = load_check_data()
    def refresh_tree():
        nonlocal df
        df = load_check_data()
        tree.delete(*tree.get_children())
        for _, row in df.iterrows():
            tree.insert("", "end", values=(row["Chủng loại"], row["Mã hàng"], row["Khách hàng"], row["Link"], row["Status"]))
    refresh_tree()

    def confirm_data():
        kjs_path = entry_kjs.get().strip()
        if not kjs_path or not os.path.exists(kjs_path):
            messagebox.showwarning("Thiếu file", "Vui lòng chọn file KJS hợp lệ!")
            return

        try:
            # Đọc file KJS (Excel hoặc CSV)
            if kjs_path.lower().endswith(('.xlsx', '.xls')):
                kjs_df = pd.read_excel(kjs_path, dtype=str)
            else:
                kjs_df = pd.read_csv(kjs_path, dtype=str, encoding="utf-8-sig")
        except Exception as e:
            messagebox.showerror("Lỗi", f"Không thể đọc file KJS: {e}")
            return

        # Tìm cột mã hàng trong file KJS (ưu tiên tên cột chứa 'mã hàng' hoặc 'ma hang', nếu không lấy cột đầu)
        kjs_col = None
        for col in kjs_df.columns:
            if "mã hàng" in col.lower() or "ma hang" in col.lower():
                kjs_col = col
                break
        if not kjs_col:
            kjs_col = kjs_df.columns[0]
        kjs_codes = set(str(x).strip() for x in kjs_df[kjs_col].dropna())

        # Đọc DataMontlyCheck.csv
        df = load_check_data()
        found_count = 0
        for idx, row in df.iterrows():
            ma_hang = str(row["Mã hàng"])
            # Lấy phần cuối sau dấu "-"
            if "-" in ma_hang:
                code = ma_hang.split("-")[-1].strip()
            else:
                code = ma_hang.strip()
            # Check trong KJS
            if code in kjs_codes:
                df.at[idx, "Status"] = "Xác nhận có dữ liệu KJS"
                found_count += 1
            else:
                df.at[idx, "Status"] = "Không có dữ liệu trong KJS"
        save_check_data(df)
        refresh_tree()
        messagebox.showinfo("Kết quả", f"Đã xác nhận xong!\nCó {found_count} mã hàng tìm thấy dữ liệu KJS.")
        
    # Nút chức năng
    frame_btn = tk.Frame(window, bg="#e8ecef")
    frame_btn.pack(pady=10)
    
    tk.Button(frame_btn, text="Xác nhận dữ liệu", font=("Helvetica", 12, "bold"),
            bg="#27ae60", fg="white", padx=18, pady=6,
            command=confirm_data).pack(side=tk.LEFT, padx=10)
    tk.Button(frame_btn, text="Nén file", font=("Helvetica", 12, "bold"),
              bg="#f39c12", fg="white", padx=18, pady=6,
              command=lambda: messagebox.showinfo("Thông báo", "Chức năng nén file đang phát triển!")).pack(side=tk.LEFT, padx=10)
    tk.Button(frame_btn, text="Chỉnh sửa nội dung", font=("Helvetica", 12, "bold"),
              bg="#3498db", fg="white", padx=18, pady=6,
              command=lambda: messagebox.showinfo("Thông báo", "Chức năng chỉnh sửa đang phát triển!")).pack(side=tk.LEFT, padx=10)
    tk.Button(frame_btn, text="Reset", font=("Helvetica", 12, "bold"),
              bg="#e74c3c", fg="white", padx=18, pady=6,
              command=refresh_tree).pack(side=tk.LEFT, padx=10)
    tk.Button(frame_btn, text="Update dữ liệu", font=("Helvetica", 12, "bold"),
              bg="#f39c12", fg="white", padx=18, pady=6,
              command=update_data).pack(side=tk.LEFT, padx=10)
    tk.Button(window, text="Đóng", command=window.destroy, font=("Helvetica", 12, "bold"),
              bg="#8e44ad", fg="white", padx=20, pady=8).pack(pady=12)