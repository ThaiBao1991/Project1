import re

old_html = """
<!-- EXERCISE START -->
<div class="exercise-container" style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; padding: 20px; margin-top: 30px;">
    <h2 style="color: #0078d4; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 10px; margin-top: 0;">Bài Tập & Lời Giải</h2>
    <div style="margin-bottom: 15px;">
        <h3 style="color: #e0e0f0; margin-bottom: 5px;">Hỏi</h3>
        <div style="background: rgba(255,255,255,0.05); padding: 10px; border-radius: 5px; border-left: 4px solid #f39c12; color: #d0d0d0;">123</div>
    </div>
</div>
<!-- EXERCISE END -->
"""

new_html = """
<!-- EXERCISE START -->
<div class="exercise-container" style="background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; padding: 20px; margin-top: 30px;">
    <h2 style="color: #0078d4; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 10px; margin-top: 0;">Bài Tập & Lời Giải</h2>
    <div class="exercise-body ql-editor" style="color: #e0e0f0; padding: 0;">
        <h1>Test Quill</h1>
    </div>
</div>
<!-- EXERCISE END -->
"""

def extract_inner_html(content):
    start_marker = "<!-- EXERCISE START -->"
    end_marker = "<!-- EXERCISE END -->"
    if start_marker not in content or end_marker not in content:
        return ""
    
    start_idx = content.find(start_marker) + len(start_marker)
    end_idx = content.find(end_marker)
    ex_html = content[start_idx:end_idx].strip()
    
    if '<div class="exercise-body ql-editor"' in ex_html:
        body_start = ex_html.find('<div class="exercise-body ql-editor"')
        body_start = ex_html.find('>', body_start) + 1
        
        # We need to drop the last 2 </div> tags: one for exercise-body, one for exercise-container
        body_end = ex_html.rfind('</div>')
        body_end = ex_html.rfind('</div>', 0, body_end) 
        return ex_html[body_start:body_end].strip()
    else:
        core = re.sub(r'<div class="exercise-container"[^>]*>', '', ex_html, count=1)
        core = re.sub(r'<h2[^>]*>.*?</h2>', '', core, count=1, flags=re.DOTALL)
        core = core.rstrip()
        if core.endswith('</div>'):
            core = core[:-6]
        return core.strip()

print("OLD:")
print(extract_inner_html(old_html))
print("\nNEW:")
print(extract_inner_html(new_html))
