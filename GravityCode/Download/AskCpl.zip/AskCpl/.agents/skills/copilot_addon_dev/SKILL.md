---
name: "Copilot Addon Dev (AskCpl)"
description: "Kích hoạt kỹ năng này khi người dùng yêu cầu sửa chữa, nâng cấp hoặc tìm hiểu về cấu trúc của Chrome Extension (Addon) có chức năng tự động hỏi Copilot/Gemini và tải file về."
---

# Hướng dẫn phát triển Copilot Addon (AskCpl)

Kỹ năng này cung cấp kiến thức nền tảng và tài liệu tham khảo về luồng hoạt động của Addon tự động hóa việc xuất nội dung từ các trợ lý AI (Gemini, Copilot, v.v.). Khi bảo trì hoặc phát triển tính năng mới cho Addon này, hãy luôn tuân theo các quy ước và ghi nhớ các bẫy kỹ thuật dưới đây.

---

## 1. Cấu trúc Addon (Manifest V3)

| File | Vai trò |
|------|---------|
| `manifest.json` | Phân quyền (`downloads`, `storage`, `scripting`), Host Permission |
| `popup.html` & `popup.js` | Giao diện điều khiển — nạp Roadmap, gửi Start/Stop/Resume |
| `background.js` | Service Worker — xử lý `chrome.downloads` (CSP workaround) |
| `content_script.js` | "Bộ não" — DOM injection, điền prompt, thu thập kết quả |

---

## 2. Luồng hoạt động chính (State Machine)

1. **Khởi tạo**: Popup → `{ action: "start_loop", tabId }` → Content Script.
2. **State Memory**: `isRunning = true`, `currentTabId` → lưu vào `chrome.storage.local`.
3. **Run Day X**: `_runNextDayAttempt()` → tìm ô nhập → điền prompt → Enter/Click → `waitForResponseComplete()`.
4. **Trích xuất & Tải file**: HTML → gửi về `background.js` Base64 Data URI → `chrome.downloads.download()`.
5. **Chuyển ngày**: Tăng `currentDay` → cập nhật storage → reload nếu cần → tiếp tục loop.

---

## 3. QUY TẮC BẮT BUỘC KHI VIẾT CODE

### ⚠️ VÀNG — Mã hóa Base64 2 chiều đồng bộ
Khi lưu/đọc dữ liệu JSON qua Base64 (đặc biệt khi có tiếng Việt, ký hiệu Unicode):

```javascript
// Khi LƯU (Encode):
btoa(unescape(encodeURIComponent(JSON.stringify(obj))))

// Khi ĐỌC (Decode):
JSON.parse(decodeURIComponent(escape(atob(str))))
```

**Hậu quả nếu thiếu `decodeURIComponent` khi đọc:** Chuỗi byte UTF-8 bị hiểu nhầm thành Latin-1. Sau hàng trăm vòng lặp Auto-Resume, dung lượng ký tự nhân đôi theo cấp số nhân → file JSON phình từ 4MB lên 50MB+ → IPC bị drop → Addon treo hoàn toàn.

### ⚠️ IPC (sendMessage) giới hạn kích thước payload
- `chrome.runtime.sendMessage` bị **drop im lặng** nếu payload quá lớn (~5-10MB).
- **Không bao giờ nhúng Roadmap Data** (3000 bài) vào payload.
- Luôn lưu vào `chrome.storage.local` key riêng (`roadmap_active`, `roadmap_{profile}`) rồi đọc trong Content Script.

### ⚠️ chrome.storage.local giới hạn 10MB/key
- Không lưu toàn bộ `addonConfigs` (bao gồm roadmap) vào 1 key duy nhất.
- Roadmap phải lưu tách biệt: `chrome.storage.local.set({ ['roadmap_' + profileName]: data })`.

---

## 4. LỖI KINH ĐIỂN & GIẢI PHÁP (Đã áp dụng)

### A. Edge không tạo thư mục khi tải file
- **Hiện tượng**: Edge bỏ qua tham số `filename` từ `data:` URI, đổ hết ra thư mục Downloads ngoài.
- **Giải pháp**: Dùng `chrome.downloads.onDeterminingFilename` trong `background.js`. Dùng `suggest({ filename: "thu_muc/file.html" })` để ép tên file.

### B. Vòng lặp vô tận sau Stop (Thread Leaking)
- **Hiện tượng**: Bấm Stop, trang vẫn tự chạy sau khi reload.
- **Giải pháp**: Ghi `isRunning = false` xuống `chrome.storage.local` khi Stop. Chèn `if (!isRunning) return 'stop';` tại **mọi điểm await** trong luồng chính.

### C. Multi-Tab xung đột (chung biến `runningState`)
- **Hiện tượng**: Tab B vô tình chạy cùng Tab A.
- **Giải pháp**: Lưu trạng thái theo Dictionary `runningStates[tabId]`. Tab chỉ Auto-Resume khi `get_tab_id` từ Background khớp với tabId lưu trong storage.

### D. Roadmap quá lớn → Popup treo + IPC Drop [GĐ 43/44]
- **Hiện tượng**: Load session.json → click Run → Addon không phản hồi, icon không lên.
- **Giải pháp**:
  - Strip `roadmapData` khỏi `sendMessage` payload.
  - Lưu roadmap vào key riêng `roadmap_active`.
  - `updateRoadmapPreview` chỉ hiển thị số bài, không `JSON.stringify` toàn bộ.
  - Content Script đọc roadmap từ storage (async) thay vì nhận qua IPC.

### E. Encoding Loop → file JSON phình to [GĐ 45]
- **Hiện tượng**: Sau nhiều ngày chạy, session.json phình từ 4MB lên 28-53MB. Nội dung xuất hiện ký tự lỗi "ÃÂÃÂ...".
- **Nguyên nhân**: `btoa(unescape(encodeURIComponent(...)))` khi lưu, nhưng chỉ `atob(...)` khi đọc — thiếu `decodeURIComponent`.
- **Giải pháp**: Sửa `atob(str)` → `decodeURIComponent(escape(atob(str)))` ở `content_script.js` dòng tải lại session sau reload.

### F. `isErrorContent` False Positive — Day 1503 bị reject [GĐ 46]
- **Hiện tượng**: Add-on kẹt mãi ở bài có số chứa mã lỗi HTTP (VD: Day **1503** chứa **503**).
- **Nguyên nhân**: `isErrorContent()` dùng `.includes('503')` → số `1503` bị nhận nhầm là lỗi 503.
- **Giải pháp**:
  1. **Length guard**: nếu `text.length > 400` → bypass kiểm tra (chắc chắn là bài giảng).
  2. **Word Boundary**: dùng regex `\b503\b` thay cho `.includes('503')`.

### G. `validateContent` False Reject với tiếng Nhật/Trung [GĐ 46]
- **Nguyên nhân**: Đếm số từ bằng `split(/\s+/)`. Tiếng Nhật/Trung không có khoảng trắng → 2000 ký tự = "1 từ" → spam filter kích hoạt sai.
- **Giải pháp**: Đổi sang tỷ lệ ký tự: `nameCharCount > text.length * 0.4`.

### H. Background Throttling — Chrome chậm khi bị ẩn [GĐ 47]
- **Hiện tượng**: Khi dùng app khác (Chrome bị ẩn/thu nhỏ), cả tiếng chưa xong 1 bài.
- **Nguyên nhân**: Chrome throttle `setTimeout` của tab bị ẩn. Silent Audio có thể bị block bởi Autoplay Policy sau reload → bị tắt ngầm → throttle kích hoạt.
- **Giải pháp (A+B)**:
  - **A — Audio Health Check**: `_audioHealthInterval` (5s) kiểm tra `_silentAudio.paused` → tự `play()` lại nếu bị tắt.
  - **B — Web Locks API**: `navigator.locks.request('askcpl_wakeLock', { mode: 'shared' }, () => new Promise(...))` — giữ lock suốt vòng lặp. Tab giữ lock sẽ không bị Chrome/Edge đưa vào trạng thái ngủ/frozen.

---

## 5. KIẾN TRÚC KEEPALIVE (chống Chrome throttle)

```
setupKeepAlive()
  ├── _silentAudio (loop=true, volume=0.01)    ← phát audio im lặng
  ├── _audioHealthInterval (5s)                ← restart audio nếu bị tắt [GĐ47-A]
  ├── _wakeLockAbort (Web Locks API)           ← giữ lock chặn throttle [GĐ47-B]
  ├── _keepAliveInterval (20s)                 ← ping background Service Worker
  └── _heartbeatInterval (15s)                 ← cập nhật timestamp cho popup

teardownKeepAlive()
  ├── pause + removeAttribute('src') _silentAudio
  ├── clearInterval _audioHealthInterval
  ├── _wakeLockAbort._resolve() + .abort()     ← giải phóng lock
  ├── clearInterval _keepAliveInterval
  └── clearInterval _heartbeatInterval
```

---

## 6. TÍNH NĂNG NÂNG CAO

| Tính năng | Mô tả |
|-----------|-------|
| **Auto-Summarizer** | Hỏi AI secondary prompt tóm tắt < 20 từ sau mỗi bài. Xây dựng `historySummaries`. |
| **Multi-Step Interrogation** | Hỏi sâu chủ đề đến khi đủ `targetCount`. Lưu vào `topicMemory`. |
| **Roadmap Injection** | Nạp danh sách bài từ `.md` (cú pháp `## Day X`), tạo mục lục `index.html`. |
| **Multi-Platform** | Hỗ trợ Gemini (`message-content`), Copilot (`.ac-textBlock`), ChatGPT (`div.markdown`). |
| **Tab Binding** | Mỗi tab AI chạy lộ trình riêng song song. Trạng thái lưu theo `runningStates[tabId]`. |
| **Auto End Day** | Tự tính ngày kết thúc từ số bài trong Roadmap nếu không nhập `endDay`. |

---

## 7. QUY TẮC BẢO TRÌ

- **LUÔN cập nhật `ProjectLog.md`** sau mỗi lần sửa lỗi hoặc thêm tính năng.
- **Đọc `ProjectLog.md` TRƯỚC** khi bắt đầu bất kỳ thay đổi nào.
- **Đề xuất phương án trước**, chờ người dùng "ok" mới viết code.
- Mỗi lần sửa phải tự verify: kiểm tra không còn bug tương tự, không phá vỡ flow cũ.
