---
name: Generate Roadmap
description: Kích hoạt kỹ năng này khi người dùng yêu cầu tạo mới, chỉnh sửa, hoặc tối ưu hóa file Lộ trình (Roadmap) học tập (ngôn ngữ, lập trình) hoặc các file Python sinh lộ trình (generate_*_roadmap.py).
---

# Workflow Tạo Lộ Trình (Roadmap)

Khi nhận được yêu cầu tạo hoặc cập nhật Roadmap, bạn phải thực hiện nghiêm ngặt theo quy trình sau:

1. **Phân tích yêu cầu**: Xác định rõ số ngày (vd: 2500 ngày), thời gian học mỗi ngày (vd: 30-45 phút), và sự phân chia các giai đoạn (Phase).
2. **Viết Script sinh tự động**: TUYỆT ĐỐI KHÔNG tự viết tay/gõ phím toàn bộ file Markdown lộ trình vì nó quá dài. Bắt buộc phải viết một file Python (vd: `generate_[topic]_roadmap.py`) chứa logic vòng lặp để sinh text.
3. **Thực thi (Run)**: Chạy script đó để tạo file `.md`. (Lưu ý: Khi chạy trên Windows, phải thiết lập `$env:PYTHONIOENCODING="utf-8"` trước khi gọi lệnh `python` để tránh lỗi Unicode Console).
4. **Kiểm duyệt (Verify)**: Đọc thử vài dòng của file Markdown đầu ra để đảm bảo nó đúng định dạng chuẩn.
5. **Cập nhật Log**: Ghi chú lại thành quả vào file `ProjectLog.md`.

---

## 1. Chuẩn Định Dạng File Markdown (Parsing Standard)
Để Add-on có thể cắt chuỗi chính xác bằng Regex, file `.md` đầu ra BẮT BUỘC phải tuân thủ format:

```markdown
## Day X — Tiêu đề bài học
**Prompt:**
Nội dung lệnh gửi AI... (Add-on sẽ copy mọi thứ từ dưới chữ "Prompt:" cho đến khi gặp từ khóa chặn).

**Bài tập:**
- Bài 1
- Bài 2

**Tags:** #tag
```
*(Từ khóa chặn thường là `**Bài tập:**` hoặc `**Tags:**` hoặc một tiêu đề `## Day` mới)*

---

## 2. Quy Tắc Thiết Kế Roadmap V2 (Học Ngôn ngữ: Anh, Nhật, Trung, Hàn)
Đối với lộ trình ngôn ngữ phiên bản 2, cấu trúc bắt buộc là **7 ngày / 1 Unit**:
- **Day 1 (Vocab Foundation):** Dạy 15-20 từ vựng cốt lõi + 1 điểm ngữ pháp. Lấy từ vựng làm ví dụ ngữ pháp.
- **Day 2 (Grammar Deep Dive):** Dạy sâu ngữ pháp. Bài tập thực hành bắt buộc phải nhúng từ vựng của Day 1.
- **Day 3 (Pronunciation/Kanji):** Luyện phát âm / chữ viết, dựa trên từ vựng Unit.
- **Day 4 (Reading Immersion):** 1 bài đọc nhúng tự nhiên từ vựng & ngữ pháp. Có câu hỏi đọc hiểu.
- **Day 5 (Listening Immersion):** 1 Script nghe nhúng từ vựng Unit. Có câu hỏi bài nghe.
- **Day 6 (Speaking Practice):** Hội thoại mẫu hoàn chỉnh (song ngữ) để luyện Shadowing.
- **Day 7 (Review & Mini Test):** Bài test tổng hợp toàn Unit.

---

## 3. Quy Tắc Thiết Kế Roadmap IT/Lập Trình (Python, JS, C++, v.v.)
Khác với học ngoại ngữ, lập trình đòi hỏi sự kết hợp giữa lý thuyết, thực hành, tối ưu, bảo mật, và kiến trúc hệ thống. Để tạo ra một **giáo trình hoàn hảo, toàn diện tuyệt đối**, không được phép cắt xén nội dung. Mọi chủ đề IT sẽ được quy chuẩn thành **Chu kỳ 15 Ngày (15-Day Ultimate Mastery Cycle)**. Mỗi chủ đề sẽ nhận chính xác 15 ngày để trải qua 15 bước mài giũa:

**Cấu trúc 15 ngày chuẩn mực (Áp dụng 1 ngày = 1 Focus Area):**
1. **Day 1 (Core Concept):** Tổng quan cơ bản, cài đặt, và ví dụ "Hello World".
2. **Day 2 (Syntax):** Cú pháp nền tảng, các tham số phổ biến.
3. **Day 3 (Deep Dive):** Kiến trúc bên dưới, luồng thực thi (execution flow), memory.
4. **Day 4 (Advanced Methods):** Các tính năng nâng cao, phương thức ít người biết.
5. **Day 5 (Error Handling):** Xử lý lỗi, Edge Cases (Trường hợp dị biệt).
6. **Day 6 (Performance):** Tối ưu hiệu suất, Clean Code, tốc độ/bộ nhớ.
7. **Day 7 (Architecture):** Kiến trúc & Design Patterns áp dụng.
8. **Day 8 (Testing):** Testing & Debugging (Unit Test, Integration Test).
9. **Day 9 (Integration):** Tích hợp với các công cụ/thư viện khác.
10. **Day 10 (Open Source):** Phân tích mã nguồn mở của các dự án lớn.
11. **Day 11 (Interview Prep):** Bộ câu hỏi phỏng vấn thực tế.
12. **Day 12 (Reinvent the wheel):** Tự code lại công nghệ từ con số 0 để hiểu bản chất.
13. **Day 13 (Mini-Project 1):** Lên ý tưởng, cấu trúc thư mục, setup.
14. **Day 14 (Mini-Project 2):** Triển khai core logic (Xử lý nghiệp vụ chính).
15. **Day 15 (Mini-Project 3):** Hoàn thiện, thuật toán và Refactor.

*(Lưu ý: Mọi prompt thực hành/bài test ở Day 13, 14, 15 đều phải áp dụng Quy tắc Tối thượng "Không Tương Tác" bên dưới để cấm AI code giải sẵn hoặc tạo trắc nghiệm).*




---

## 4. Quy Tắc Tối Thượng: KHÔNG TƯƠNG TÁC (Non-Interactive)
Khi tạo Prompt cho người dùng gửi AI, câu lệnh PHẢI ép AI xuất kết quả **hoàn chỉnh một chiều**. Tránh việc AI (đặc biệt là Gemini) tưởng người dùng đang muốn chơi đố vui và tự động bật giao diện trắc nghiệm chờ click.
- ❌ **Sai:** "Đặt câu hỏi và chờ người dùng trả lời" / "Hãy chấm điểm cho tôi".
- ✅ **Đúng (Bắt buộc dùng cho các bài test/bài tập ở Day 2, 4, 5, 7):**
  > `(⚠️ QUAN TRỌNG: TUYỆT ĐỐI KHÔNG tạo bài test/quiz tương tác chờ tôi trả lời. HÃY IN RA TOÀN BỘ câu hỏi VÀ ĐÁP ÁN CHI TIẾT CÙNG LÚC để tôi tự đọc và đối chiếu)`

---

## 5. Quy Tắc File & Encoding
- Tất cả các file `.py` và `.md` sinh ra PHẢI ghi với `encoding="utf-8"`.
- Không sử dụng các lệnh PowerShell string replace (như `-replace`) cho nội dung tiếng Việt vì môi trường Windows CP1252 sẽ gây lỗi mất dấu chữ Quốc ngữ/Kanji. Hãy dùng Python hoặc thay thế trực tiếp trên file gốc.
