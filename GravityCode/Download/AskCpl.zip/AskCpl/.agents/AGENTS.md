# General Rules

- **KI First**: Always review Knowledge Items (KI) first when starting a new conversation or task.
- **ProjectLog.md**: Always read `ProjectLog.md` before starting to understand the current context. ALWAYS update `ProjectLog.md` after making significant changes to reflect the new state.
- **Strict Plan Before Code**: Always propose an implementation plan before execution. You MUST wait for the user's explicit approval (e.g., "ok") BEFORE writing or modifying any code.
- **Self-Correction, Verification & Proactive Fixing**: After writing code, you MUST review, check, and fix any immediate errors (e.g., run tests, build, or analyze output). Furthermore, you must also proactively identify and fix any potential errors or edge cases that might occur. Do not mark the task as complete until all errors are resolved and verified.

## ⚠️ Checklist Bắt Buộc Trước Khi Code (Pre-Code Checklist)
Trước **bất kỳ** thao tác chỉnh sửa file hay viết code nào, tôi PHẢI tự hỏi:
- [ ] Tôi đã đề xuất phương án rõ ràng và chờ người dùng nói "ok" chưa?
- [ ] Tôi đã đọc file liên quan để hiểu ngữ cảnh hiện tại chưa?
- [ ] Tôi đã xác định chính xác những file nào sẽ bị thay đổi chưa?
- [ ] Sau khi sửa, tôi có kế hoạch tự verify kết quả không?

> ⛔ KHÔNG được bắt đầu gõ code, sửa file, hay chạy lệnh sửa đổi nếu chưa qua checklist này.


## ⚠️ Quy tắc VÀNG về Mã Hóa (Encoding) Base64
Tuyệt đối lưu ý khi lưu trữ và truyền tải dữ liệu JSON (đặc biệt là dữ liệu có chứa ký hiệu Unicode, tiếng Việt, file markdown):
1. **LUÔN LUÔN DÙNG MÃ HÓA 2 CHIỀU ĐỒNG BỘ:**
   - Khi mã hóa lưu trữ (Save): toa(unescape(encodeURIComponent(JSON.stringify(obj))))
   - Khi giải mã đọc ra (Load): JSON.parse(decodeURIComponent(escape(atob(str))))
2. **Hậu quả nếu bỏ quên decodeURIComponent:** Nếu bạn chỉ dùng tob(...) để giải nén nhưng thiếu decodeURIComponent, chuỗi byte UTF-8 sẽ bị ép hiểu nhầm thành các ký tự Latin-1. Khi chuỗi này bị lặp lại lưu/đọc trong vòng lặp (như vòng lặp Auto-Resume reload trang), dung lượng ký tự sẽ **bị nhân đôi liên tục theo cấp số nhân**, làm file JSON phình to từ vài MB lên hàng chục MB, gây nghẽn RAM, treo máy và sập luồng gửi tin nhắn IPC của Chrome.
