import re
import os

day = "day_1.html"
target_dir = "test_dir"
mode = "direct"
html_content = "<p>Test 123</p>"
is_completed = True

os.makedirs(target_dir, exist_ok=True)
html_path = os.path.join(target_dir, day)
with open(html_path, "w", encoding="utf-8") as f:
    f.write("<html><body></body></html>")

index_path = os.path.join(target_dir, "index.html")
with open(index_path, "w", encoding="utf-8") as f:
    f.write('<html><body><a href="day_1.html">Day 1</a></body></html>')

# Now run the save logic
html_snippets = ["<!-- EXERCISE START -->"]

day_file_base = os.path.splitext(day)[0]
archival_file_name = f"{day_file_base} exercise.html"

if mode == "archival":
    pass

html_snippets.append('<div class="exercise-container">')
html_snippets.append('  <h2>Bài Tập & Lời Giải</h2>')
html_snippets.append(f'  <div class="ql-editor">{html_content}</div>')
html_snippets.append('</div>')

if mode == "archival":
    pass

html_snippets.append("<!-- EXERCISE END -->")
new_ex_content = "\n".join(html_snippets)

if mode == "direct":
    content = ""
    if os.path.exists(html_path):
        with open(html_path, "r", encoding="utf-8") as f:
            content = f.read()

    start_marker = "<!-- EXERCISE START -->"
    end_marker = "<!-- EXERCISE END -->"
    if start_marker in content and end_marker in content:
        start_idx = content.find(start_marker)
        end_idx = content.find(end_marker) + len(end_marker)
        content = content[:start_idx] + content[end_idx:]

    if "</body>" in content:
        content = content.replace("</body>", new_ex_content + "\n</body>")
    else:
        content += "\n" + new_ex_content

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(content)

def update_index_links(index_content, day, status_html, archival_link_html, mode):
    search_str = f'href="{day}"'
    idx = index_content.find(search_str)
    if idx == -1:
        return index_content
        
    a_end_idx = index_content.find('</a>', idx)
    if a_end_idx == -1:
        return index_content
    a_end_idx += 4
    
    chunk = index_content[a_end_idx:a_end_idx+500]
    escaped_day = re.escape(day)
    pattern = r'^(?:\s*<span class="ex-status" data-day="' + escaped_day + r'".*?</span>)?(?:\s*<a href="exercise/[^"]+" class="ex-archival-link" data-day="' + escaped_day + r'".*?</a>)?'
    
    match = re.match(pattern, chunk, flags=re.DOTALL)
    if match:
        replace_len = len(match.group(0))
        if mode == "direct":
            new_chunk = status_html
        else:
            new_chunk = status_html + archival_link_html
        return index_content[:a_end_idx] + new_chunk + index_content[a_end_idx + replace_len:]
    return index_content

if os.path.exists(index_path):
    with open(index_path, "r", encoding="utf-8") as f:
        index_content = f.read()
        
    status_html = ""
    if is_completed:
        status_html = f'\n<span class="ex-status" data-day="{day}">[Đã hoàn thành]</span>'
        
    archival_link_html = f'\n<a href="exercise/{archival_file_name}" class="ex-archival-link" data-day="{day}">[Bản lưu trữ]</a>'
    
    new_index_content = update_index_links(index_content, day, status_html, archival_link_html, mode)
    
    with open(index_path, "w", encoding="utf-8") as f:
        f.write(new_index_content)

print("Done")
