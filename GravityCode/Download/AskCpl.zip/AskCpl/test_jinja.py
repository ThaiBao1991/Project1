from jinja2 import Template

t = Template('const targetDir = "{{ target_dir|replace(\'\\\\\', \'\\\\\\\\\') }}";')
print("Jinja template rendering:")
print(t.render(target_dir=r"C:\Users\games\Desktop"))
