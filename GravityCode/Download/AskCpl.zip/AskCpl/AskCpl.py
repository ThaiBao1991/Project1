import os
import json
import time
import threading
from tkinter import Tk, filedialog, messagebox, Button, Label, Frame, StringVar, Entry, Text, END, Listbox, Scrollbar, BooleanVar, Checkbutton
from tkinter import ttk

try:
    import win32com.client
except ImportError:
    win32com = None
    print("Vui lòng cài đặt pywin32: pip install pywin32")

# Import các module mới
from settings import load_settings, update_github_settings
from github_api import GitHubSync
from exercise_builder import save_exercise_to_html, remove_exercise_from_html
from nav_injector import inject_all, rebuild_index, get_day_files
import webbrowser
try:
    from exercise_server import run_server
except ImportError:
    run_server = None

class AskCplApp:
    def __init__(self, root):
        if run_server:
            threading.Thread(target=run_server, daemon=True).start()
        self.root = root
        self.root.title("Copilot Addon Manager")
        self.root.state('zoomed')
        
        # Load settings
        self.settings = load_settings()
        
        # Tạo Notebook (Tabs)
        self.notebook = ttk.Notebook(self.root)
        self.notebook.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Tabs
        self.tab_word = ttk.Frame(self.notebook)
        self.tab_github = ttk.Frame(self.notebook)
        self.tab_exercise = ttk.Frame(self.notebook)
        self.tab_config_index = ttk.Frame(self.notebook)
        
        self.notebook.add(self.tab_word, text="Xuất Word")
        self.notebook.add(self.tab_github, text="Upload GitHub")
        self.notebook.add(self.tab_exercise, text="Trình Tạo Bài Tập")
        self.notebook.add(self.tab_config_index, text="⚙️ Config Index")
        
        self.setup_tab_word()
        self.setup_tab_github()
        self.setup_tab_exercise()
        self.setup_tab_config_index()
        
    # --- TAB 1: XUẤT WORD ---
    def setup_tab_word(self):
        Label(self.tab_word, text="Chuyển đổi dữ liệu JSON thành Word", font=("Arial", 14, "bold")).pack(pady=20)
        btn = Button(self.tab_word, text="Chọn file JSON & Tạo Word", bg="#0078d4", fg="white", font=("Arial", 12), command=self.json_to_word, padx=20, pady=10)
        btn.pack(pady=10)
        Label(self.tab_word, text="(Hỗ trợ giữ nguyên định dạng bảng biểu, in đậm của Copilot)", fg="gray").pack(pady=10)

    def json_to_word(self):
        if not win32com:
            messagebox.showerror("Lỗi", "Chưa cài đặt thư viện pywin32. Hãy chạy lệnh: pip install pywin32")
            return

        json_path = filedialog.askopenfilename(
            title="Chọn file JSON tải từ Add-on",
            filetypes=[("JSON files", "*.json")]
        )
        
        if not json_path:
            return

        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            messagebox.showerror("Lỗi", f"Không thể đọc file JSON:\n{e}")
            return

        if not isinstance(data, list) or len(data) == 0:
            messagebox.showerror("Lỗi", "Dữ liệu JSON trống hoặc không đúng định dạng.")
            return

        base_dir = os.path.dirname(os.path.abspath(__file__))
        temp_dir = os.path.join(base_dir, "temp_htmls")
        if not os.path.exists(temp_dir):
            os.makedirs(temp_dir)

        print("Đang khởi động MS Word...")
        try:
            word = win32com.client.Dispatch("Word.Application")
            word.Visible = False
            word.DisplayAlerts = False
        except Exception as e:
            messagebox.showerror("Lỗi", f"Không thể khởi động MS Word:\n{e}")
            return

        output_docx = os.path.join(base_dir, f"KhoaHoc_Copilot_{int(time.time())}.docx")

        try:
            doc = word.Documents.Add()
            doc.SaveAs(output_docx)
            
            for idx, item in enumerate(data):
                day_title = item.get("day", f"Day {idx+1}")
                html_content = item.get("html", "")
                
                temp_html_path = os.path.join(temp_dir, f"temp_{idx}.html")
                full_html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>{day_title}</title>
</head>
<body style="font-family: 'Segoe UI', Arial, sans-serif; line-height: 1.6; padding: 20px;">
<h1 style="color: #0078d4; text-align: center; border-bottom: 2px solid #0078d4; padding-bottom: 10px;">{day_title}</h1>
{html_content}
</body>
</html>"""
                with open(temp_html_path, 'w', encoding='utf-8') as f:
                    f.write(full_html)
                
                word.Selection.EndKey(Unit=6) 
                if idx > 0:
                    word.Selection.InsertBreak(Type=7)
                    
                word.Selection.Collapse(Direction=0)
                print(f"Đang gộp: {day_title}...")
                word.Selection.InsertFile(FileName=temp_html_path, ConfirmConversions=False, Link=False, Attachment=False)
                time.sleep(0.5)
                doc.Save()
                
            doc.Close()
            messagebox.showinfo("Thành công", f"Đã xuất file Word thành công tại:\n{output_docx}")
            os.startfile(output_docx)
            
        except Exception as e:
            messagebox.showerror("Lỗi quá trình tạo Word", str(e))
        finally:
            try:
                word.Quit()
            except:
                pass

    # --- TAB 2: GITHUB SYNC ---
    def setup_tab_github(self):
        Label(self.tab_github, text="Cấu hình GitHub", font=("Arial", 12, "bold")).pack(pady=5)
        
        f1 = Frame(self.tab_github)
        f1.pack(fill='x', padx=20, pady=5)
        Label(f1, text="Username:", width=10, anchor='w').pack(side='left')
        self.entry_gh_user = Entry(f1)
        self.entry_gh_user.pack(side='left', fill='x', expand=True)
        self.entry_gh_user.insert(0, self.settings["github"].get("username", ""))
        
        f2 = Frame(self.tab_github)
        f2.pack(fill='x', padx=20, pady=5)
        Label(f2, text="Token:", width=10, anchor='w').pack(side='left')
        self.entry_gh_token = Entry(f2, show="*")
        self.entry_gh_token.pack(side='left', fill='x', expand=True)
        self.entry_gh_token.insert(0, self.settings["github"].get("token", ""))
        
        Button(self.tab_github, text="Lưu Cấu Hình", command=self.save_github_settings).pack(pady=5)
        
        ttk.Separator(self.tab_github, orient='horizontal').pack(fill='x', pady=10)
        
        Label(self.tab_github, text="Upload Thư Mục (HTML)", font=("Arial", 12, "bold")).pack(pady=5)
        
        f3 = Frame(self.tab_github)
        f3.pack(fill='x', padx=20, pady=5)
        self.gh_folder_var = StringVar()
        Entry(f3, textvariable=self.gh_folder_var, state='readonly').pack(side='left', fill='x', expand=True)
        Button(f3, text="Chọn Thư Mục", command=self.select_gh_folder).pack(side='right', padx=5)
        
        f4 = Frame(self.tab_github)
        f4.pack(fill='x', padx=20, pady=5)
        Label(f4, text="Tên Repo:", width=10, anchor='w').pack(side='left')
        self.entry_gh_repo = Entry(f4)
        self.entry_gh_repo.pack(side='left', fill='x', expand=True)
        
        Button(self.tab_github, text="Đẩy lên GitHub", bg="#2ea043", fg="white", font=("Arial", 10, "bold"), command=self.upload_to_github).pack(pady=10)
        
        self.gh_log = Text(self.tab_github, height=8, state='disabled')
        self.gh_log.pack(fill='both', expand=True, padx=20, pady=5)

    def save_github_settings(self):
        user = self.entry_gh_user.get().strip()
        token = self.entry_gh_token.get().strip()
        update_github_settings(username=user, token=token)
        self.settings = load_settings()
        messagebox.showinfo("Thành công", "Đã lưu cài đặt GitHub an toàn!")

    def select_gh_folder(self):
        folder = filedialog.askdirectory(title="Chọn thư mục tải về từ Addon")
        if folder:
            self.gh_folder_var.set(folder)
            repo_name = os.path.basename(folder).replace(" ", "-")
            self.entry_gh_repo.delete(0, END)
            self.entry_gh_repo.insert(0, repo_name)

    def log_gh(self, msg):
        self.gh_log.config(state='normal')
        self.gh_log.insert(END, msg + "\n")
        self.gh_log.see(END)
        self.gh_log.config(state='disabled')

    def upload_to_github(self):
        user = self.entry_gh_user.get().strip()
        token = self.entry_gh_token.get().strip()
        repo = self.entry_gh_repo.get().strip()
        folder = self.gh_folder_var.get()
        
        if not user or not token:
            messagebox.showerror("Lỗi", "Vui lòng nhập GitHub Username và Token!")
            return
        if not folder or not repo:
            messagebox.showerror("Lỗi", "Vui lòng chọn thư mục và nhập tên Repo!")
            return
            
        def run():
            gh = GitHubSync(user, token, repo, self.log_gh)
            self.log_gh("--- Bắt đầu Upload ---")
            gh.upload_folder(folder)
            self.log_gh("--- Kết thúc ---")
            
        threading.Thread(target=run, daemon=True).start()

    # --- TAB 3: BÀI TẬP (INTERACTIVE BUILDER) ---
    def setup_tab_exercise(self):
        self.ex_current_dir = ""
        self.ex_current_file = ""
        self.ex_blocks_data = {} # format: { "day_1.html": [{"type": "text", "content": "..."}, ...] }
        
        pw = ttk.PanedWindow(self.tab_exercise, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=5, pady=5)
        
        # --- LEFT FRAME ---
        left_frame = Frame(pw, width=200)
        pw.add(left_frame, weight=1)
        
        Button(left_frame, text="1. Chọn Thư Mục HTML", command=self.ex_select_dir).pack(fill='x', pady=5)
        self.ex_lbl_dir = Label(left_frame, text="Chưa chọn", fg="blue", wraplength=180)
        self.ex_lbl_dir.pack(fill='x')
        
        Label(left_frame, text="Danh sách Ngày:").pack(anchor='w', pady=(10,0))
        
        scroll_l = Scrollbar(left_frame)
        scroll_l.pack(side='right', fill='y')
        self.ex_listbox = Listbox(left_frame, yscrollcommand=scroll_l.set, exportselection=False)
        self.ex_listbox.pack(side='left', fill='both', expand=True)
        scroll_l.config(command=self.ex_listbox.yview)
        self.ex_listbox.bind("<<ListboxSelect>>", self.ex_on_day_select)
        self.ex_listbox.bind("<Double-1>", self.ex_on_day_double_click)
        
        # --- RIGHT FRAME ---
        right_frame = Frame(pw)
        pw.add(right_frame, weight=3)
        
        self.ex_lbl_current = Label(right_frame, text="Chưa chọn ngày nào", font=("Arial", 12, "bold"))
        self.ex_lbl_current.pack(pady=5)
        
        f_mode = Frame(right_frame)
        f_mode.pack(fill='x', padx=5, pady=2)
        Label(f_mode, text="Chế độ xuất:").pack(side='left')
        self.ex_combo_mode = ttk.Combobox(f_mode, values=["Nhúng trực tiếp (Mặc định)", "Lưu trữ (Thư mục exercise)"], state="readonly", width=30)
        self.ex_combo_mode.current(0)
        self.ex_combo_mode.pack(side='left', padx=5)
        
        # Add Block Frame
        add_frame = ttk.LabelFrame(right_frame, text="Thêm Khối Nội Dung (Block)")
        add_frame.pack(fill='x', padx=5, pady=5)
        
        f_type = Frame(add_frame)
        f_type.pack(fill='x', pady=2)
        Label(f_type, text="Loại:").pack(side='left')
        self.ex_combo_type = ttk.Combobox(f_type, values=["Văn bản", "Mã nguồn (Code)", "File đính kèm"], state="readonly", width=15)
        self.ex_combo_type.current(0)
        self.ex_combo_type.pack(side='left', padx=5)
        self.ex_combo_type.bind("<<ComboboxSelected>>", self.ex_on_type_change)
        
        self.ex_lbl_lang = Label(f_type, text="Ngôn ngữ:")
        self.ex_combo_lang = ttk.Combobox(f_type, values=["python", "javascript", "html", "css", "sql", "java", "cpp", "csharp", "bash", "json"], width=10)
        self.ex_combo_lang.current(0)
        
        self.ex_text_content = Text(add_frame, height=5)
        self.ex_text_content.pack(fill='x', padx=5, pady=2)
        
        self.ex_btn_file = Button(add_frame, text="Chọn File (RAR, ZIP, PY...)", command=self.ex_select_attachment)
        self.ex_selected_file = ""
        self.ex_lbl_file = Label(add_frame, text="", fg="green")
        
        Button(add_frame, text="➕ Thêm Block Này", command=self.ex_add_block, bg="#0078d4", fg="white").pack(pady=5)
        Button(add_frame, text="🖊 Mở Trình Soạn Nâng Cao (Trình duyệt)", command=self.ex_open_advanced_editor, bg="#f39c12", fg="white", font=("Arial", 10, "bold")).pack(pady=(0, 5))
        
        # Preview Frame
        preview_frame = ttk.LabelFrame(right_frame, text="Các Block Đã Thêm (Preview)")
        preview_frame.pack(fill='both', expand=True, padx=5, pady=5)
        
        self.ex_text_preview = Text(preview_frame, state='disabled', bg="#f0f0f0")
        self.ex_text_preview.pack(fill='both', expand=True, padx=5, pady=5)
        
        bottom_frame = Frame(right_frame)
        bottom_frame.pack(fill='x', pady=5)
        Button(bottom_frame, text="Xóa Block Cuối", command=self.ex_remove_last_block).pack(side='left', padx=5)
        Button(bottom_frame, text="Xóa Tất Cả", command=self.ex_clear_blocks, fg="red").pack(side='left', padx=5)
        Button(bottom_frame, text="🔄 Tải lại", command=lambda: (self.ex_reload_from_json(), self.ex_refresh_preview()),
               bg="#5c2d91", fg="white", font=("Arial", 9)).pack(side='left', padx=5)
        
        Button(bottom_frame, text="Lưu & Nhúng HTML", command=self.ex_save_html, bg="#2ea043", fg="white", font=("Arial", 10, "bold")).pack(side='right', padx=5)
        self.ex_check_complete_var = BooleanVar()
        Checkbutton(bottom_frame, text="Xác nhận hoàn thành", variable=self.ex_check_complete_var, font=("Arial", 10, "bold"), fg="#2ea043").pack(side='right', padx=10)
        
        self.ex_update_ui_state()

    def ex_select_dir(self):
        folder = filedialog.askdirectory(title="Chọn thư mục chứa các file day_x.html")
        if folder:
            self.ex_current_dir = folder
            self.ex_lbl_dir.config(text=folder)
            
            # Load exercises_data.json if exists
            json_path = os.path.join(self.ex_current_dir, "exercises_data.json")
            if os.path.exists(json_path):
                try:
                    with open(json_path, "r", encoding="utf-8") as f:
                        self.ex_blocks_data = json.load(f)
                except Exception:
                    self.ex_blocks_data = {}
            else:
                self.ex_blocks_data = {}
                
            self.ex_refresh_listbox()
            # Chạy scan trong background thread để không block UI
            import threading
            threading.Thread(target=self.ex_scan_archival_to_json, daemon=True).start()

    def ex_scan_archival_to_json(self):
        """Quét thư mục exercise/ và day_X.html để bổ sung vào exercises_data.json.
        Chạy trong background thread — không được gọi trực tiếp UI từ đây."""
        if not self.ex_current_dir:
            return
        changed = False
        # Snapshot để tránh race condition nếu user đổi thư mục trong lúc scan
        current_dir = self.ex_current_dir

        # --- Scan 1: Archival files trong thư mục exercise/ (file nhỏ, đọc nhanh) ---
        exercise_dir = os.path.join(current_dir, "exercise")
        if os.path.exists(exercise_dir):
            for fname in os.listdir(exercise_dir):
                if not fname.endswith(" exercise.html"):
                    continue
                day_base = fname.replace(" exercise.html", "")
                day_key = day_base + ".html"
                if self.ex_blocks_data.get(day_key):
                    continue
                archival_path = os.path.join(exercise_dir, fname)
                try:
                    with open(archival_path, "r", encoding="utf-8") as f:
                        file_content = f.read()
                    html = self._extract_ql_content(file_content)
                    if html:
                        self.ex_blocks_data[day_key] = [{"type": "wysiwyg", "html": html}]
                        changed = True
                except Exception as e:
                    print(f"[Scan] Lỗi đọc {fname}: {e}")

        # --- Scan 2: Direct-embedded trong day_X.html ---
        # Tối ưu: đọc chunk 4KB đầu file để kiểm tra marker trước khi đọc full
        MARKER = "<!-- EXERCISE START -->"
        try:
            for fname in os.listdir(current_dir):
                if not (fname.startswith("day_") and fname.endswith(".html")):
                    continue
                if self.ex_blocks_data.get(fname):
                    continue
                html_path = os.path.join(current_dir, fname)
                try:
                    # Bước 1: Đọc nhanh 4KB đầu file — kiểm tra có exercise không
                    with open(html_path, "r", encoding="utf-8", errors="ignore") as f:
                        head = f.read(4096)
                    if MARKER not in head:
                        # Kiểm tra cuối file (marker có thể nằm gần </body>)
                        file_size = os.path.getsize(html_path)
                        if file_size > 8192:
                            with open(html_path, "rb") as fb:
                                fb.seek(max(0, file_size - 4096))
                                tail = fb.read().decode("utf-8", errors="ignore")
                            if MARKER not in tail:
                                continue  # Không có exercise, bỏ qua
                        else:
                            continue
                    # Bước 2: Đọc full file để extract nội dung
                    with open(html_path, "r", encoding="utf-8", errors="ignore") as f:
                        file_content = f.read()
                    html = self._extract_ql_content(file_content)
                    if html:
                        self.ex_blocks_data[fname] = [{"type": "wysiwyg", "html": html}]
                        changed = True
                except Exception:
                    pass
        except Exception:
            pass

        if changed:
            json_path = os.path.join(current_dir, "exercises_data.json")
            try:
                with open(json_path, "w", encoding="utf-8") as f:
                    json.dump(self.ex_blocks_data, f, ensure_ascii=False, indent=2)
            except Exception:
                pass
            # Cập nhật UI an toàn từ background thread
            self.after(0, self.ex_refresh_listbox)

    def _extract_ql_content(self, content):
        """Trích xuất nội dung bên trong div.ql-editor từ file exercise HTML."""
        start_marker = "<!-- EXERCISE START -->"
        end_marker = "<!-- EXERCISE END -->"
        if start_marker not in content or end_marker not in content:
            return ""
        start_idx = content.find(start_marker) + len(start_marker)
        end_idx = content.find(end_marker)
        ex_html = content[start_idx:end_idx]

        marker = '<div class="ql-editor">'
        if marker not in ex_html:
            # Thử class cũ
            if '<div class="exercise-body ql-editor"' in ex_html:
                body_start = ex_html.find('<div class="exercise-body ql-editor"')
                body_start = ex_html.find('>', body_start) + 1
                body_end = ex_html.rfind('</div>')
                body_end = ex_html.rfind('</div>', 0, body_end)
                return ex_html[body_start:body_end].strip()
            return ""

        body_start = ex_html.find(marker) + len(marker)
        # Depth tracking để tìm đúng </div> đóng tương ứng
        depth = 1
        pos = body_start
        body_end = len(ex_html)
        while pos < len(ex_html):
            next_open = ex_html.find('<div', pos)
            next_close = ex_html.find('</div>', pos)
            if next_close == -1:
                break
            if next_open != -1 and next_open < next_close:
                depth += 1
                pos = next_open + 4
            else:
                depth -= 1
                if depth == 0:
                    body_end = next_close
                    break
                pos = next_close + 6
        return ex_html[body_start:body_end].strip()

    def ex_refresh_listbox(self):
        self.ex_listbox.delete(0, END)
        if not self.ex_current_dir:
            return
            
        files = [f for f in os.listdir(self.ex_current_dir) if f.startswith("day_") and f.endswith(".html")]
        # Sort by day number
        try:
            files.sort(key=lambda x: int(x.split("_")[1].split(".")[0]))
        except:
            files.sort()
            
        for f in files:
            # Check if has blocks
            has_data = len(self.ex_blocks_data.get(f, [])) > 0
            mark = "✅ " if has_data else "❌ "
            self.ex_listbox.insert(END, mark + f)

    def ex_on_day_select(self, event):
        sel = self.ex_listbox.curselection()
        if not sel:
            return
        item = self.ex_listbox.get(sel[0])
        self.ex_current_file = item[2:] # Bỏ 2 ký tự icon
        self.ex_lbl_current.config(text=f"Đang soạn bài tập cho: {self.ex_current_file}")
        # Reload từ JSON để phản ánh thay đổi từ Web Editor
        self.ex_reload_from_json()
        self.ex_refresh_preview()

    def ex_reload_from_json(self):
        """Đọc lại exercises_data.json từ đĩa. Gọi sau khi Web Editor có thể đã cập nhật."""
        if not self.ex_current_dir:
            return
        json_path = os.path.join(self.ex_current_dir, "exercises_data.json")
        if os.path.exists(json_path):
            try:
                with open(json_path, "r", encoding="utf-8") as f:
                    self.ex_blocks_data = json.load(f)
            except Exception:
                pass
        self.ex_refresh_listbox()

    def ex_on_day_double_click(self, event):
        if not self.ex_current_file or not self.ex_current_dir:
            return
        file_path = os.path.join(self.ex_current_dir, self.ex_current_file)
        if os.path.exists(file_path):
            webbrowser.open(f"file://{os.path.abspath(file_path)}")

    def ex_on_type_change(self, event):
        self.ex_update_ui_state()
        
    def ex_update_ui_state(self):
        b_type = self.ex_combo_type.get()
        if b_type == "Văn bản":
            self.ex_lbl_lang.pack_forget()
            self.ex_combo_lang.pack_forget()
            self.ex_btn_file.pack_forget()
            self.ex_lbl_file.pack_forget()
            self.ex_text_content.pack(fill='x', padx=5, pady=2)
        elif b_type == "Mã nguồn (Code)":
            self.ex_lbl_lang.pack(side='left', padx=(10,2))
            self.ex_combo_lang.pack(side='left')
            self.ex_btn_file.pack_forget()
            self.ex_lbl_file.pack_forget()
            self.ex_text_content.pack(fill='x', padx=5, pady=2)
        elif b_type == "File đính kèm":
            self.ex_lbl_lang.pack_forget()
            self.ex_combo_lang.pack_forget()
            self.ex_text_content.pack_forget()
            self.ex_btn_file.pack(pady=5)
            self.ex_lbl_file.pack()

    def ex_select_attachment(self):
        fp = filedialog.askopenfilename()
        if fp:
            self.ex_selected_file = fp
            self.ex_lbl_file.config(text=os.path.basename(fp))

    def ex_add_block(self):
        if not self.ex_current_file:
            messagebox.showwarning("Lỗi", "Vui lòng chọn một Ngày (day_x.html) ở danh sách bên trái trước!")
            return
            
        b_type_str = self.ex_combo_type.get()
        block = {}
        if b_type_str == "Văn bản":
            content = self.ex_text_content.get("1.0", END).strip()
            if not content: return
            block = {"type": "text", "content": content}
            self.ex_text_content.delete("1.0", END)
            
        elif b_type_str == "Mã nguồn (Code)":
            content = self.ex_text_content.get("1.0", END).rstrip() # Giữ khoảng trắng đầu dòng
            if not content: return
            block = {"type": "code", "language": self.ex_combo_lang.get(), "content": content}
            self.ex_text_content.delete("1.0", END)
            
        elif b_type_str == "File đính kèm":
            if not self.ex_selected_file: return
            filename = os.path.basename(self.ex_selected_file)
            block = {"type": "file", "filepath": self.ex_selected_file, "filename": filename}
            self.ex_selected_file = ""
            self.ex_lbl_file.config(text="")
            
        if self.ex_current_file not in self.ex_blocks_data:
            self.ex_blocks_data[self.ex_current_file] = []
            
        self.ex_blocks_data[self.ex_current_file].append(block)
        self.ex_persist_data()
        self.ex_refresh_preview()
        self.ex_refresh_listbox() # Cập nhật icon ✅

    def ex_remove_last_block(self):
        if self.ex_current_file in self.ex_blocks_data and self.ex_blocks_data[self.ex_current_file]:
            block = self.ex_blocks_data[self.ex_current_file].pop()
            if block.get("type") == "file":
                filepath = os.path.join(self.ex_current_dir, "attachments", block.get("filename", ""))
                if os.path.exists(filepath):
                    try:
                        os.remove(filepath)
                    except:
                        pass
            self.ex_persist_data()
            self.ex_refresh_preview()
            self.ex_refresh_listbox()

    def ex_clear_blocks(self):
        if messagebox.askyesno("Xác nhận", "Xóa toàn bộ block và gỡ bài tập khỏi HTML?"):
            # Xóa bài tập khỏi file HTML và index.html
            if self.ex_current_dir and self.ex_current_file:
                target_html = os.path.join(self.ex_current_dir, self.ex_current_file)
                remove_exercise_from_html(target_html, self.ex_current_dir)
                
            blocks = self.ex_blocks_data.get(self.ex_current_file, [])
            for block in blocks:
                if block.get("type") == "file":
                    filepath = os.path.join(self.ex_current_dir, "attachments", block.get("filename", ""))
                    if os.path.exists(filepath):
                        try:
                            os.remove(filepath)
                        except:
                            pass
            self.ex_blocks_data[self.ex_current_file] = []
            self.ex_persist_data()
            self.ex_refresh_preview()
            self.ex_refresh_listbox()

    def ex_refresh_preview(self):
        self.ex_text_preview.config(state='normal')
        self.ex_text_preview.delete("1.0", END)
        
        blocks = self.ex_blocks_data.get(self.ex_current_file, [])
        if not blocks:
            self.ex_text_preview.insert(END, "(Chưa có block nào)")
        else:
            for idx, b in enumerate(blocks):
                self.ex_text_preview.insert(END, f"--- BLOCK {idx+1} [{b['type'].upper()}] ---\n")
                if b['type'] == 'text':
                    self.ex_text_preview.insert(END, b['content'] + "\n\n")
                elif b['type'] == 'code':
                    self.ex_text_preview.insert(END, f"Ngôn ngữ: {b['language']}\n")
                    # Chỉ hiện 3 dòng đầu preview
                    lines = b['content'].split('\n')
                    preview_lines = "\n".join(lines[:3]) + ("\n..." if len(lines) > 3 else "")
                    self.ex_text_preview.insert(END, preview_lines + "\n\n")
                elif b['type'] == 'file':
                    self.ex_text_preview.insert(END, f"File: {b['filename']}\n\n")
                elif b['type'] == 'wysiwyg':
                    # Block được tạo từ Web Editor (Quill)
                    import re as _re
                    plain = _re.sub(r'<[^>]+>', '', b.get('html', ''))
                    plain = plain.strip()
                    preview_lines = "\n".join(plain.splitlines()[:5])
                    if len(plain.splitlines()) > 5:
                        preview_lines += "\n..."
                    self.ex_text_preview.insert(END, "[Nội dung từ Trình Soạn Thảo Nâng Cao]\n")
                    self.ex_text_preview.insert(END, preview_lines + "\n\n")
                    
        self.ex_text_preview.config(state='disabled')

    def ex_persist_data(self):
        # Lưu vào json tạm để không mất
        if self.ex_current_dir:
            json_path = os.path.join(self.ex_current_dir, "exercises_data.json")
            with open(json_path, "w", encoding="utf-8") as f:
                json.dump(self.ex_blocks_data, f, ensure_ascii=False, indent=2)

    def ex_save_html(self, silent=False):
        if not self.ex_current_file:
            return
            
        blocks = self.ex_blocks_data.get(self.ex_current_file, [])
        if not blocks:
            messagebox.showinfo("Báo cáo", "Ngày này không có bài tập nào.")
            return
            
        target_html = os.path.join(self.ex_current_dir, self.ex_current_file)
        is_completed = self.ex_check_complete_var.get()
        mode_val = "archival" if self.ex_combo_mode.current() == 1 else "direct"
        
        success, msg = save_exercise_to_html(target_html, blocks, self.ex_current_dir, is_completed, mode=mode_val)
        if success:
            if not silent:
                messagebox.showinfo("Thành công", f"Đã lưu {len(blocks)} khối vào {self.ex_current_file} thành công!")
        else:
            if not silent:
                messagebox.showerror("Lỗi", msg)

    def ex_open_advanced_editor(self):
        if not self.ex_current_file:
            messagebox.showwarning("Lỗi", "Vui lòng chọn một Ngày (day_x.html) ở danh sách bên trái trước!")
            return
        if not self.ex_current_dir:
            return
            
        # TỰ ĐỘNG LƯU BLOCKS NẾU CÓ ĐỂ WEB EDITOR ĐỌC ĐƯỢC
        blocks = getattr(self, 'ex_blocks_data', {}).get(self.ex_current_file, [])
        if blocks:
            self.ex_save_html(silent=True)

        # --- Tự động phát hiện mode đúng từ file thực tế trên đĩa ---
        day_base = os.path.splitext(self.ex_current_file)[0]
        archival_path = os.path.join(self.ex_current_dir, "exercise", f"{day_base} exercise.html")
        direct_path = os.path.join(self.ex_current_dir, self.ex_current_file)

        EXERCISE_MARKER = "<!-- EXERCISE START -->"
        detected_mode = None

        if os.path.exists(archival_path):
            # Archival file tồn tại → bài tập được lưu ở đây
            detected_mode = "archival"
        elif os.path.exists(direct_path):
            # Kiểm tra day_X.html có nhúng exercise không (đọc head+tail để tiết kiệm)
            try:
                with open(direct_path, 'r', encoding='utf-8', errors='ignore') as f:
                    head = f.read(4096)
                has_marker = EXERCISE_MARKER in head
                if not has_marker:
                    fsize = os.path.getsize(direct_path)
                    if fsize > 8192:
                        with open(direct_path, 'rb') as fb:
                            fb.seek(max(0, fsize - 4096))
                            tail = fb.read().decode('utf-8', errors='ignore')
                        has_marker = EXERCISE_MARKER in tail
                if has_marker:
                    detected_mode = "direct"
            except Exception:
                pass

        # Nếu không tìm thấy bài tập nào → dùng mode từ combo box (tạo mới)
        mode_val = detected_mode if detected_mode else (
            "archival" if self.ex_combo_mode.current() == 1 else "direct"
        )
        
        import urllib.parse
        encoded_dir = urllib.parse.quote(self.ex_current_dir)
        encoded_day = urllib.parse.quote(self.ex_current_file)
        
        import time
        v = int(time.time())
        url = f"http://127.0.0.1:5678/editor?day={encoded_day}&target_dir={encoded_dir}&mode={mode_val}&v={v}"
        webbrowser.open(url)

    # --- TAB 4: CONFIG INDEX ---
    def setup_tab_config_index(self):
        self.ci_current_dir = ""
        self.ci_watching = False
        self.ci_known_files = set()

        # Header
        Label(self.tab_config_index, text="⚙️ Config Index — Tái tạo Điều Hướng HTML",
              font=("Arial", 14, "bold")).pack(pady=(15, 5))
        Label(self.tab_config_index,
              text="Chọn thư mục chứa các file day_X.html để inject thanh điều hướng (← →) vào từng trang.",
              fg="gray", wraplength=600).pack(pady=(0, 10))

        # Chọn thư mục
        f1 = Frame(self.tab_config_index)
        f1.pack(fill='x', padx=20, pady=5)
        self.ci_dir_var = StringVar()
        Entry(f1, textvariable=self.ci_dir_var, state='readonly', width=60).pack(side='left', fill='x', expand=True)
        Button(f1, text="Chọn Thư Mục", command=self.ci_select_dir, bg="#0078d4", fg="white").pack(side='right', padx=5)

        # Thống kê
        self.ci_lbl_stats = Label(self.tab_config_index, text="", fg="#0078d4", font=("Arial", 10))
        self.ci_lbl_stats.pack(pady=3)

        # Listbox danh sách file
        lf = ttk.LabelFrame(self.tab_config_index, text="Danh sách file phát hiện")
        lf.pack(fill='both', expand=True, padx=20, pady=5)

        scroll_ci = Scrollbar(lf)
        scroll_ci.pack(side='right', fill='y')
        self.ci_listbox = Listbox(lf, yscrollcommand=scroll_ci.set, font=("Consolas", 9))
        self.ci_listbox.pack(side='left', fill='both', expand=True)
        scroll_ci.config(command=self.ci_listbox.yview)

        # Nút hành động
        btn_frame = Frame(self.tab_config_index)
        btn_frame.pack(fill='x', padx=20, pady=8)
        Button(btn_frame, text="🔄 Tái tạo index.html",
               command=self.ci_rebuild_index, bg="#5c2d91", fg="white",
               font=("Arial", 10, "bold"), padx=10).pack(side='left', padx=5)
        Button(btn_frame, text="🔗 Inject Navigation vào tất cả Day files",
               command=self.ci_inject_nav, bg="#2ea043", fg="white",
               font=("Arial", 10, "bold"), padx=10).pack(side='left', padx=5)
        Button(btn_frame, text="🚀 Tất Cả (Index + Nav)",
               command=self.ci_do_all, bg="#c4a000", fg="white",
               font=("Arial", 10, "bold"), padx=10).pack(side='left', padx=5)

        # Auto-Watch
        watch_frame = Frame(self.tab_config_index)
        watch_frame.pack(fill='x', padx=20, pady=(0, 5))
        self.ci_watch_btn = Button(
            watch_frame,
            text="👁️ Bật Auto-Watch (Tự động inject khi có file mới)",
            command=self.ci_toggle_watch,
            bg="#555", fg="white", font=("Arial", 10, "bold"), padx=10
        )
        self.ci_watch_btn.pack(side='left', padx=5)
        self.ci_watch_lbl = Label(watch_frame, text="● Đang tắt", fg="#999", font=("Arial", 10))
        self.ci_watch_lbl.pack(side='left', padx=8)

        # Log
        log_lf = ttk.LabelFrame(self.tab_config_index, text="Log")
        log_lf.pack(fill='x', padx=20, pady=(0, 10))
        self.ci_log = Text(log_lf, height=8, state='disabled', bg="#1e1e2e", fg="#a0f0a0",
                           font=("Consolas", 9))
        self.ci_log.pack(fill='both', expand=True, padx=5, pady=5)

    def ci_select_dir(self):
        folder = filedialog.askdirectory(title="Chọn thư mục chứa các file day_X.html")
        if not folder:
            return
        self.ci_current_dir = folder
        self.ci_dir_var.set(folder)
        self.ci_refresh_list()

    def ci_refresh_list(self):
        self.ci_listbox.delete(0, END)
        folder = self.ci_current_dir
        if not folder:
            return
        day_files = get_day_files(folder)
        if not day_files:
            self.ci_lbl_stats.config(text="❌ Không tìm thấy file day_X.html nào!", fg="red")
            return

        total = day_files[-1][0]
        found_days = {d for d, _ in day_files}
        missing = [d for d in range(1, total + 1) if d not in found_days]

        self.ci_lbl_stats.config(
            text=f"✅ {len(day_files)} file tìm thấy | Day 1 → Day {total} | Thiếu: {len(missing)} file",
            fg="#2ea043" if not missing else "#c4a000"
        )

        for day_num, fname in day_files:
            self.ci_listbox.insert(END, f"  Day {day_num:>4}  →  {fname}")

        if missing:
            self.ci_listbox.insert(END, "")
            self.ci_listbox.insert(END, f"  ⚠️  File bị thiếu: Day {', '.join(map(str, missing[:15]))}{'...' if len(missing) > 15 else ''}")

    def ci_log_msg(self, msg):
        self.ci_log.config(state='normal')
        self.ci_log.insert(END, msg + "\n")
        self.ci_log.see(END)
        self.ci_log.config(state='disabled')

    def ci_rebuild_index(self):
        if not self.ci_current_dir:
            messagebox.showwarning("Chưa chọn thư mục", "Vui lòng chọn thư mục trước!")
            return
        def run():
            rebuild_index(self.ci_current_dir, self.ci_log_msg)
        threading.Thread(target=run, daemon=True).start()

    def ci_inject_nav(self):
        if not self.ci_current_dir:
            messagebox.showwarning("Chưa chọn thư mục", "Vui lòng chọn thư mục trước!")
            return
        def run():
            self.ci_log_msg("--- Bắt đầu Inject Navigation ---")
            result = inject_all(self.ci_current_dir, self.ci_log_msg)
            self.ci_log_msg(f"--- Hoàn tất: {result['success']} thành công / {result['failed']} thất bại ---")
        threading.Thread(target=run, daemon=True).start()

    def ci_toggle_watch(self):
        if not self.ci_current_dir:
            messagebox.showwarning("Chưa chọn thư mục", "Vui lòng chọn thư mục trước!")
            return
        self.ci_watching = not self.ci_watching
        if self.ci_watching:
            # Init known files
            self.ci_known_files = {f for _, f in get_day_files(self.ci_current_dir)}
            self.ci_watch_btn.config(bg="#c0392b", text="⏹ Tắt Auto-Watch")
            self.ci_watch_lbl.config(text="● Đang theo dõi...", fg="#2ecc71")
            self.ci_log_msg("[Watch] Bat dau theo doi thu muc: " + self.ci_current_dir)
            self.ci_watch_poll()
        else:
            self.ci_watch_btn.config(bg="#555", text="👁️ Bật Auto-Watch (Tự động inject khi có file mới)")
            self.ci_watch_lbl.config(text="● Đang tắt", fg="#999")
            self.ci_log_msg("[Watch] Dung theo doi.")

    def ci_watch_poll(self):
        if not self.ci_watching:
            return
        current_files = {f for _, f in get_day_files(self.ci_current_dir)}
        new_files = current_files - self.ci_known_files
        if new_files:
            self.ci_log_msg(f"[Watch] Phat hien {len(new_files)} file moi: {', '.join(sorted(new_files))}")
            self.ci_known_files = current_files
            def run():
                inject_all(self.ci_current_dir, self.ci_log_msg)
                rebuild_index(self.ci_current_dir, self.ci_log_msg)
                self.ci_refresh_list()
            threading.Thread(target=run, daemon=True).start()
        # Poll lai sau 3 giay
        self.root.after(3000, self.ci_watch_poll)

    def ci_do_all(self):
        if not self.ci_current_dir:
            messagebox.showwarning("Chưa chọn thư mục", "Vui lòng chọn thư mục trước!")
            return
        def run():
            self.ci_log_msg("=== Bat dau: Tai tao Index + Inject Navigation ===")
            rebuild_index(self.ci_current_dir, self.ci_log_msg)
            result = inject_all(self.ci_current_dir, self.ci_log_msg)
            self.ci_log_msg(f"=== Hoan tat! {result['success']} file da duoc cap nhat ===")
        threading.Thread(target=run, daemon=True).start()


if __name__ == "__main__":
    root = Tk()
    app = AskCplApp(root)
    root.mainloop()
