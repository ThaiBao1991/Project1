import re
import time

day = 'day_1.html'
escaped_day = re.escape(day)
chunk = ' ' * 500
pattern = r'^(?:\s*<span class="ex-status" data-day="' + escaped_day + r'".*?</span>)?(?:\s*<a href="exercise/[^"]+" class="ex-archival-link" data-day="' + escaped_day + r'".*?</a>)?'

start = time.time()
re.match(pattern, chunk, flags=re.DOTALL)
print(f'Time: {time.time() - start}')
