"""
patch_expanded_prompts.py
-------------------------
Script tự động cập nhật các Prompt và bổ sung thời gian dự kiến vào roadmap_expanded.md.
Các cập nhật bao gồm:
  1. Thêm dòng "⏱ **Dự kiến thời gian học:** X phút" dựa trên số trang PDF.
  2. Bổ sung yêu cầu chi tiết vào Prompt.
"""

import os
import re

ROADMAP_PATH = os.path.join(os.path.dirname(__file__), "roadmap_expanded.md")

def patch_roadmap():
    if not os.path.exists(ROADMAP_PATH):
        print(f"[Error] Khong tim thay file: {ROADMAP_PATH}")
        return

    with open(ROADMAP_PATH, 'r', encoding='utf-8') as f:
        content = f.read()

    # Tách file theo '\n## Day '
    day_blocks = content.split('\n## Day ')
    
    header = day_blocks[0]
    days = day_blocks[1:]
    
    patched_days = []
    
    for block in days:
        # Tính toán thời gian học từ số trang PDF
        page_match = re.search(r'<!--\s*pages:\s*(\d+)-(\d+)\s*-->', block)
        duration_str = ""
        if page_match:
            p_start = int(page_match.group(1))
            p_end = int(page_match.group(2))
            num_pages = p_end - p_start + 1
            duration_min = num_pages * 8  # 8 phút mỗi trang
            duration_str = f"⏱ **Dự kiến thời gian học:** {duration_min} phút (dựa trên {num_pages} trang PDF)"
        else:
            duration_str = f"⏱ **Dự kiến thời gian học:** 30 phút"
            
        # Thêm dòng thời gian dự kiến vào bên dưới hàng info file gốc nếu chưa có
        if "Dự kiến thời gian học:" not in block:
            file_goc_match = re.search(r'(\*[^\n]*File g[oố]c[^\n]*\n)', block, re.IGNORECASE)
            if file_goc_match:
                block = block.replace(file_goc_match.group(1), file_goc_match.group(1) + duration_str + "\n")
            else:
                lines = block.split('\n')
                lines.insert(1, duration_str)
                block = '\n'.join(lines)

        # Patch Prompt block
        prompt_match = re.search(r'\*\*Prompt:\*\*(.*?)(?=>\s*Ghi ch[uú] cho Gemini)', block, re.DOTALL)
        if prompt_match:
            original_prompt = prompt_match.group(1).strip()
            
            # Nếu chưa được cập nhật theo style mới thì cập nhật
            if "Yêu cầu cách trả lời:" not in original_prompt:
                patched_prompt = (
                    f"{original_prompt}\n\n"
                    "**YÊU CẦU CHI TIẾT VỀ CÁCH TRẢ LỜI:**\n"
                    "- Đóng vai trò là một người bạn đồng hành kiêm chuyên gia giàu kinh nghiệm hướng dẫn chi tiết cho người chưa biết gì dễ dàng nắm vững.\n"
                    "- Hãy giải thích cặn kẽ các khái niệm nền tảng, cơ chế hoạt động, và sơ đồ luồng (nếu có) trong tài liệu.\n"
                    "- Trình bày **HƯỚNG DẪN CÁCH LÀM / CÁCH THỰC HIỆN TỪNG BƯỚC** thật chi tiết, rõ ràng cho các tác vụ được nhắc đến để có thể làm theo trực quan.\n"
                    "- Bổ sung thêm hướng dẫn cụ thể về bài tập thực hành, bao gồm các bước kiểm tra (verify) kết quả sau khi thực hiện."
                )
                
                block = block.replace(original_prompt, patched_prompt)
        
        patched_days.append(block)

    # Ghép lại file
    new_content = header + '\n## Day ' + '\n## Day '.join(patched_days)
        
    with open(ROADMAP_PATH, 'w', encoding='utf-8') as f:
        f.write(new_content)
        
    print(f"[OK] Da cap nhat thanh cong lo trinh: {ROADMAP_PATH}")

if __name__ == "__main__":
    patch_roadmap()
