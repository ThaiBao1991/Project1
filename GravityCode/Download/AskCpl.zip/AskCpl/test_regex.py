import re
import time

index_content = """
    <a class="day-item" href="day_1.html">
        <div class="day-title">Day 1: Giới thiệu Power Query</div>
        <div class="day-summary">Tìm hiểu về Power Query trong Excel và Power BI</div>
    </a>
""" * 100

escaped_day = re.escape('day_1.html')
pattern = r'(<a [^>]*href="' + escaped_day + r'"[^>]*>.*?</a>)(?:\s*<span class="ex-status" data-day="' + escaped_day + r'".*?</span>)?(?:\s*<a href="exercise/[^"]+" class="ex-archival-link" data-day="' + escaped_day + r'".*?</a>)?'

print("Starting sub WITHOUT DOTALL...")
t0 = time.time()
res1 = re.sub(pattern, r'\1' + "STATUS", index_content)
print(f"Done in {time.time()-t0:.4f}s. Matched: {res1 != index_content}")

print("Starting sub WITH DOTALL...")
t0 = time.time()
res2 = re.sub(pattern, r'\1' + "STATUS", index_content, flags=re.DOTALL)
print(f"Done in {time.time()-t0:.4f}s. Matched: {res2 != index_content}")
