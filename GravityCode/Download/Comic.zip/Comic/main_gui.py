import os
import threading
import tkinter as tk
from tkinter import filedialog
from PIL import Image
import customtkinter as ctk

from downloader import ComicDownloader

class ComicApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        
        self.title("Comic Downloader & Reader Maxizezum")
        self.geometry("1000x700")
        self.after(0, lambda: self.state('zoomed'))

        self.downloader = ComicDownloader("config.json")
        self.settings_file = "settings.json"
        self.settings = self.load_settings()
        
        # Tabs
        self.tabview = ctk.CTkTabview(self)
        self.tabview.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.tab_download = self.tabview.add("Tải Truyện")
        self.tab_reader = self.tabview.add("Đọc Truyện")
        
        self.setup_download_tab()
        self.setup_reader_tab()
        
    def load_settings(self):
        import json
        try:
            with open(self.settings_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except:
            return {"last_download_dir": "", "last_read_dir": ""}
            
    def save_settings(self):
        import json
        with open(self.settings_file, "w", encoding="utf-8") as f:
            json.dump(self.settings, f, ensure_ascii=False, indent=2)
        
    def setup_download_tab(self):
        # Chọn Web
        frame_top = ctk.CTkFrame(self.tab_download)
        frame_top.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkLabel(frame_top, text="Chọn Website:").pack(side="left", padx=5)
        self.combo_domain = ctk.CTkOptionMenu(frame_top, values=list(self.downloader.configs.keys()))
        self.combo_domain.pack(side="left", padx=5)
        
        # Server Selection
        ctk.CTkLabel(frame_top, text="Chọn Server:").pack(side="left", padx=(20, 5))
        self.combo_server = ctk.CTkOptionMenu(frame_top, values=["1", "2", "3", "4"], width=80)
        self.combo_server.pack(side="left", padx=5)
        
        # Nhập URL
        frame_url = ctk.CTkFrame(self.tab_download)
        frame_url.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkLabel(frame_url, text="Link Truyện:").pack(side="left", padx=5)
        self.entry_url = ctk.CTkEntry(frame_url, width=400)
        self.entry_url.pack(side="left", padx=5, fill="x", expand=True)
        
        btn_fetch = ctk.CTkButton(frame_url, text="Lấy Tên Truyện", command=self.on_fetch_info, width=120)
        btn_fetch.pack(side="left", padx=5)
        
        # Nơi lưu trữ
        frame_save = ctk.CTkFrame(self.tab_download)
        frame_save.pack(fill="x", padx=10, pady=5)
        
        ctk.CTkLabel(frame_save, text="Thư mục lưu:").pack(side="left", padx=5)
        self.entry_dest = ctk.CTkEntry(frame_save, width=400)
        self.entry_dest.pack(side="left", padx=5, fill="x", expand=True)
        
        btn_browse = ctk.CTkButton(frame_save, text="Browse", command=self.on_browse, width=80)
        btn_browse.pack(side="left", padx=5)
        
        # Tùy chọn Resume
        self.var_resume = ctk.BooleanVar(value=True)
        chk_resume = ctk.CTkCheckBox(frame_save, text="Tiếp tục tải (Resume bằng JSON)", variable=self.var_resume)
        chk_resume.pack(side="left", padx=20)
        
        # Nút Start
        self.btn_start = ctk.CTkButton(self.tab_download, text="BẮT ĐẦU TẢI", height=40, font=("Arial", 16, "bold"), command=self.on_start)
        self.btn_start.pack(fill="x", padx=10, pady=10)
        
        # Console Log
        self.textbox_log = ctk.CTkTextbox(self.tab_download, state="disabled")
        self.textbox_log.pack(fill="both", expand=True, padx=10, pady=10)
        
    def log(self, msg):
        def append_log():
            self.textbox_log.configure(state="normal")
            self.textbox_log.insert("end", msg + "\n")
            self.textbox_log.see("end")
            self.textbox_log.configure(state="disabled")
        self.after(0, append_log)
        
    def on_fetch_info(self):
        url = self.entry_url.get().strip()
        if not url:
            self.log("[!] Vui lòng nhập link truyện.")
            return
        self.log("[*] Đang lấy thông tin tên truyện...")
        threading.Thread(target=self._thread_fetch, args=(url,), daemon=True).start()
        
    def _thread_fetch(self, url):
        title, err = self.downloader.get_comic_info(url)
        if err:
            self.log(err)
            return
        
        def update_ui():
            self.entry_dest.delete(0, "end")
            parent_dir = self.settings.get("last_download_dir", os.getcwd())
            if not parent_dir or not os.path.exists(parent_dir):
                parent_dir = os.getcwd()
            default_path = os.path.join(parent_dir, title)
            self.entry_dest.insert(0, default_path)
            self.log(f"[+] Tên truyện: {title}\n[+] Thư mục dự kiến: {default_path}")
        self.after(0, update_ui)
        
    def on_browse(self):
        initial_dir = self.settings.get("last_download_dir", os.getcwd())
        if not initial_dir or not os.path.exists(initial_dir): initial_dir = os.getcwd()
        
        folder = filedialog.askdirectory(title="Chọn thư mục lưu truyện", initialdir=initial_dir)
        if folder:
            self.entry_dest.delete(0, "end")
            self.entry_dest.insert(0, folder)
            self.settings["last_download_dir"] = os.path.dirname(folder)
            self.save_settings()
            
    def on_start(self):
        url = self.entry_url.get().strip()
        dest = self.entry_dest.get().strip()
        resume = self.var_resume.get()
        server_id = int(self.combo_server.get())
        
        if not url or not dest:
            self.log("[!] Link và Thư mục lưu không được để trống.")
            return
            
        self.settings["last_download_dir"] = os.path.dirname(dest)
        self.save_settings()
            
        self.btn_start.configure(state="disabled", text="ĐANG TẢI...")
        self.log(f"\n{'='*50}\nBắt đầu tải truyện!\n{'='*50}")
        
        threading.Thread(target=self._thread_download, args=(url, dest, resume, server_id), daemon=True).start()
        
    def _thread_download(self, url, dest, resume, server_id):
        self.downloader.process_comic(url, dest, resume, server_id=server_id, log_callback=self.log)
        self.after(0, lambda: self.btn_start.configure(state="normal", text="BẮT ĐẦU TẢI"))
        
    # ================= READER TAB =================
    def setup_reader_tab(self):
        self.chapters = []
        self.current_chapter_idx = -1
        self.current_page_idx = -1
        self.current_ctk_image = None
        self.zoom_mode = ctk.StringVar(value="Fit Width")
        
        # Toolbar trên cùng
        frame_top = ctk.CTkFrame(self.tab_reader)
        frame_top.pack(fill="x", padx=5, pady=5)
        
        btn_open = ctk.CTkButton(frame_top, text="Mở Thư Mục Truyện", command=self.on_open_comic)
        btn_open.pack(side="left", padx=5)
        
        self.lbl_reader_status = ctk.CTkLabel(frame_top, text="Chưa mở truyện", font=("Arial", 14, "bold"))
        self.lbl_reader_status.pack(side="left", padx=20)
        
        # Cụm Zoom
        ctk.CTkLabel(frame_top, text="Chế độ Zoom:").pack(side="left", padx=(20, 5))
        zoom_options = ["Fit Width", "Fit Height", "50%", "75%", "100%", "150%", "200%"]
        opt_zoom = ctk.CTkOptionMenu(frame_top, values=zoom_options, variable=self.zoom_mode, command=self.on_zoom_change)
        opt_zoom.pack(side="left", padx=5)
        
        # Body
        frame_body = ctk.CTkFrame(self.tab_reader)
        frame_body.pack(fill="both", expand=True, padx=5, pady=5)
        
        # Mục lục bên trái
        self.frame_toc = ctk.CTkScrollableFrame(frame_body, width=250)
        self.frame_toc.pack(side="left", fill="y", padx=5, pady=5)
        
        # Khu vực cuộn xem ảnh bên phải (Canvas để dễ điều khiển scroll)
        # Sử dụng ScrollableFrame để dễ code trên CustomTkinter
        self.frame_image_container = ctk.CTkScrollableFrame(frame_body)
        self.frame_image_container.pack(side="right", fill="both", expand=True, padx=5, pady=5)
        
        # Label chứa ảnh nằm bên trong khung cuộn
        self.lbl_image = ctk.CTkLabel(self.frame_image_container, text="")
        self.lbl_image.pack(expand=True, pady=10) # pady để lề xíu cho đẹp
        
        # Phím tắt
        self.bind("<Left>", self.on_prev_page)
        self.bind("<Right>", self.on_next_page)
        self.bind("<Up>", self.scroll_up)
        self.bind("<Down>", self.scroll_down)

        # Hỗ trợ lăn chuột cho toàn bộ tab reader (Windows)
        self.tab_reader.bind("<MouseWheel>", self.on_mouse_wheel)

        # Bắt sự kiện resize của container để vẽ lại "Fit Width"
        self.frame_image_container.bind("<Configure>", self.on_resize)
        
    def scroll_up(self, event=None):
        canvas = self.frame_image_container._parent_canvas
        top, bottom = canvas.yview()
        # Tính khoảng cách 10% chiều cao đang hiển thị
        delta = (bottom - top) * 0.1
        canvas.yview_moveto(max(0.0, top - delta))
        
    def scroll_down(self, event=None):
        canvas = self.frame_image_container._parent_canvas
        top, bottom = canvas.yview()
        delta = (bottom - top) * 0.1
        # Tránh cuộn quá đà
        if bottom < 1.0:
            canvas.yview_moveto(min(1.0 - (bottom - top), top + delta))
            
    def on_mouse_wheel(self, event):
        # Lăn chuột cũng cuộn mượt mà thay vì nhảy nấc quá lớn
        canvas = self.frame_image_container._parent_canvas
        if event.delta > 0:
            self.scroll_up()
        else:
            self.scroll_down()

    def on_zoom_change(self, value):
        self.display_image()

    def on_open_comic(self):
        initial_dir = self.settings.get("last_read_dir", os.getcwd())
        if not initial_dir or not os.path.exists(initial_dir): initial_dir = os.getcwd()
        
        folder = filedialog.askdirectory(title="Chọn thư mục chứa truyện đã tải", initialdir=initial_dir)
        if not folder:
            return
            
        self.settings["last_read_dir"] = os.path.dirname(folder) # lưu thư mục cha để lần sau mở ra chọn danh sách truyện
        self.save_settings()
            
        self.chapters = []
        subdirs = [os.path.join(folder, d) for d in os.listdir(folder) if os.path.isdir(os.path.join(folder, d))]
        subdirs.sort()
        
        for d in subdirs:
            chap_name = os.path.basename(d)
            images = [os.path.join(d, f) for f in os.listdir(d) if f.lower().endswith(('.jpg', '.png', '.jpeg', '.webp', '.gif'))]
            images.sort()
            if images:
                self.chapters.append((chap_name, images))
                
        if not self.chapters:
            self.lbl_reader_status.configure(text="Không tìm thấy ảnh truyện trong thư mục.")
            return
            
        self.lbl_reader_status.configure(text=f"Truyện: {os.path.basename(folder)}")
        self.build_toc()
        
        self.current_chapter_idx = 0
        self.current_page_idx = 0
        self.show_current_page()
        
    def build_toc(self):
        for widget in self.frame_toc.winfo_children():
            widget.destroy()
            
        for idx, (chap_name, _) in enumerate(self.chapters):
            btn = ctk.CTkButton(
                self.frame_toc, text=chap_name, anchor="w", fg_color="transparent", 
                text_color=("black", "white"), hover_color=("gray70", "gray30"),
                command=lambda i=idx: self.jump_to_chapter(i)
            )
            btn.pack(fill="x", pady=2)
            
    def jump_to_chapter(self, idx):
        self.current_chapter_idx = idx
        self.current_page_idx = 0
        self.show_current_page()
        
    def on_prev_page(self, event=None):
        if self.current_chapter_idx < 0: return
        
        if self.current_page_idx > 0:
            self.current_page_idx -= 1
        else:
            if self.current_chapter_idx > 0:
                self.current_chapter_idx -= 1
                self.current_page_idx = len(self.chapters[self.current_chapter_idx][1]) - 1
        self.show_current_page()
        
    def on_next_page(self, event=None):
        if self.current_chapter_idx < 0: return
        
        total_pages = len(self.chapters[self.current_chapter_idx][1])
        if self.current_page_idx < total_pages - 1:
            self.current_page_idx += 1
        else:
            if self.current_chapter_idx < len(self.chapters) - 1:
                self.current_chapter_idx += 1
                self.current_page_idx = 0
        self.show_current_page()
        
    def show_current_page(self):
        if self.current_chapter_idx < 0 or self.current_chapter_idx >= len(self.chapters):
            return
            
        chap_name, images = self.chapters[self.current_chapter_idx]
        img_path = images[self.current_page_idx]
        
        self.lbl_reader_status.configure(text=f"{chap_name} - Trang {self.current_page_idx + 1}/{len(images)}")
        
        try:
            self.current_pil_image = Image.open(img_path)
            # Tự động cuộn Scrollbar lên đầu trang
            self.frame_image_container._parent_canvas.yview_moveto(0)
            self.display_image()
        except Exception as e:
            self.lbl_image.configure(text=f"Lỗi hiển thị ảnh: {e}", image="")
            
    def display_image(self):
        if not hasattr(self, 'current_pil_image') or not self.current_pil_image:
            return
            
        mode = self.zoom_mode.get()
        img_w, img_h = self.current_pil_image.size
        
        new_w, new_h = img_w, img_h
        
        if mode == "Fit Width":
            # Lấy chiều rộng của khung cuộn, trừ đi padding/scrollbar size
            container_w = self.frame_image_container.winfo_width() - 30 
            if container_w > 10:
                ratio = container_w / img_w
                new_w = container_w
                new_h = int(img_h * ratio)
        elif mode == "Fit Height":
            # Nếu người dùng muốn coi trọn ảnh 1 màn hình
            container_h = self.frame_image_container.winfo_height() - 30
            if container_h > 10:
                ratio = container_h / img_h
                new_h = container_h
                new_w = int(img_w * ratio)
        else:
            # Zoom theo %
            try:
                percent = int(mode.replace('%', ''))
                ratio = percent / 100.0
                new_w = int(img_w * ratio)
                new_h = int(img_h * ratio)
            except:
                pass
                
        # Giới hạn kích thước tối thiểu để không bị lỗi
        new_w = max(10, new_w)
        new_h = max(10, new_h)
        
        self.current_ctk_image = ctk.CTkImage(light_image=self.current_pil_image, dark_image=self.current_pil_image, size=(new_w, new_h))
        self.lbl_image.configure(image=self.current_ctk_image, text="")
        
        # Cập nhật lại khung cuộn (Scrollregion) ngay lập tức sau khi thay đổi kích thước ảnh
        self.lbl_image.update_idletasks()
        canvas = self.frame_image_container._parent_canvas
        canvas.configure(scrollregion=canvas.bbox("all"))

    def on_resize(self, event):
        # Chỉ update lại nếu đang ở chế độ Fit Width hoặc Fit Height
        if self.zoom_mode.get() in ["Fit Width", "Fit Height"]:
            if hasattr(self, '_resize_timer'):
                self.after_cancel(self._resize_timer)
            self._resize_timer = self.after(200, self.display_image)

if __name__ == "__main__":
    ctk.set_appearance_mode("System")
    ctk.set_default_color_theme("blue")
    app = ComicApp()
    app.mainloop()
