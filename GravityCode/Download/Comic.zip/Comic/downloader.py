import os
import json
import re
from urllib.parse import urljoin, urlparse
import requests
import urllib3
from bs4 import BeautifulSoup

# Tắt cảnh báo SSL khi dùng verify=False (bypass ISP)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class ComicDownloader:
    def __init__(self, config_path="config.json"):
        self.config_path = config_path
        self.configs = self.load_configs()
        self.log_callback = None
        self._doh_cache = {}  # Cache DNS đã giải: {domain: ip}
        self.session_cookies = {}
        self.selenium_ua = None
        self.driver = None
        self._page_cache = {}  # Cache HTML: {url: html} - tái sử dụng HTML giữa get_comic_info và process_comic

    def load_configs(self):
        if not os.path.exists(self.config_path):
            raise FileNotFoundError(f"Config file not found at {self.config_path}")
        with open(self.config_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    def log(self, msg):
        if self.log_callback:
            self.log_callback(msg)
        else:
            print(msg)

    def get_domain(self, url):
        domain = urlparse(url).netloc
        if domain.startswith("www."):
            domain = domain[4:]
        return domain

    def sanitize_filename(self, filename):
        filename = filename.strip().split('\n')[0]
        return re.sub(r'[\\/*?:"<>|\n\r\t]', "", filename).strip()

    def _get_html_with_selenium(self, url):
        self.log(f"[*] Đang dùng trình duyệt ngầm để lấy HTML: {url} ...")
        try:
            import undetected_chromedriver as uc
            import time
            
            # Kiểm tra xem trình duyệt ngầm có bị crash/đóng thủ công không
            if self.driver:
                try:
                    self.driver.title
                except:
                    self.log("[!] Trình duyệt ngầm đã bị lỗi hoặc bị đóng, đang khởi tạo lại...")
                    self.driver = None

            if self.driver is None:
                self.log("[*] Đang khởi tạo Chrome ẩn lần đầu tiên...")
                options = uc.ChromeOptions()
                # Cloudflare chặn cực gắt chế độ headless, nên ta dùng mẹo kéo cửa sổ ra khỏi màn hình
                options.add_argument('--window-position=-2000,0') 
                options.add_argument('--log-level=3')
                
                self.driver = uc.Chrome(options=options)
                self.driver.set_page_load_timeout(60)
                
                self.log("[*] Làm nóng mạng: Chờ 5s để Chrome tự kích hoạt Secure DNS...")
                self.driver.get("https://www.google.com")
                time.sleep(5)
            
            # THỬ LẠI 3 LẦN NẾU BỊ CONNECTION_REFUSED
            for attempt in range(3):
                try:
                    self.driver.get(url)
                    break
                except Exception as e:
                    if "CONNECTION_REFUSED" in str(e) and attempt < 2:
                        self.log(f"[*] Bị từ chối kết nối (Lần {attempt+1}), đang thử lại...")
                        time.sleep(3)
                    else:
                        raise e
            
            # Chờ thông minh: Poll mỗi 2s cho đến khi Cloudflare pass (tối đa 40s)
            # CHỈ check title - vì trang đã load xong vẫn còn cloudflare script trong source
            cf_wait = 0
            while cf_wait < 40:
                try:
                    title = self.driver.title
                except:
                    title = ""
                if "Just a moment" not in title and "Verifying" not in title:
                    if cf_wait > 0:
                        self.log("[+] Cloudflare đã xác minh xong!")
                    break
                if cf_wait == 0:
                    self.log("[*] Đang chờ Cloudflare duyệt tự động (tối đa 40s)...")
                time.sleep(2)
                cf_wait += 2
            if cf_wait >= 40:
                self.log("[!] Cloudflare không pass sau 40s. Thử lấy HTML hiện tại...")
                
            html = self.driver.page_source
            
            # Chỉ lấy cookie 1 lần đầu
            if not self.session_cookies:
                cookies = self.driver.get_cookies()
                self.session_cookies = {c['name']: c['value'] for c in cookies}
                self.selenium_ua = self.driver.execute_script("return navigator.userAgent;")
                
            return html
        except Exception as e:
            self.log(f"[!] Lỗi khi chạy Selenium: {e}")
            return None

    def _resolve_via_doh(self, domain):
        """Giải DNS qua Cloudflare DoH (1.1.1.1) để vượt chặn nhà mạng."""
        if domain in self._doh_cache:
            return self._doh_cache[domain]
        try:
            doh_url = f"https://cloudflare-dns.com/dns-query?name={domain}&type=A"
            res = requests.get(doh_url, headers={"Accept": "application/dns-json"}, timeout=10)
            data = res.json()
            for answer in data.get("Answer", []):
                if answer.get("type") == 1:  # A record
                    ip = answer.get("data")
                    self._doh_cache[domain] = ip
                    return ip
        except:
            pass
        return None

    def _safe_get(self, url, headers, **kwargs):
        """HTTP GET tự động fallback qua DoH nếu bị nhà mạng chặn. Thêm curl_cffi giả lập Chrome để qua Cloudflare."""
        
        # Gắn Cookie và User-Agent thật nếu đã vượt qua Cloudflare bằng Selenium
        if self.selenium_ua:
            headers['User-Agent'] = self.selenium_ua
        if self.session_cookies and 'cookies' not in kwargs:
            kwargs['cookies'] = self.session_cookies

        # --- BƯỚC 1: Dùng curl_cffi để vượt Cloudflare ---
        try:
            from curl_cffi import requests as c_req
            # curl_cffi hỗ trợ hầu hết kwargs của requests
            try:
                self.log(f"[*] Đang thử dùng curl_cffi giả lập Chrome để vượt Cloudflare...")
                return c_req.get(url, headers=headers, impersonate="chrome", **kwargs)
            except Exception as e:
                # Lỗi kết nối (bị nhà mạng chặn DNS/DPI) -> Chuyển qua bước 2
                self.log(f"[!] curl_cffi thất bại: {e}")
                pass
        except ImportError:
            # Chưa cài curl_cffi -> Chuyển qua bước 2
            self.log("[!] CẢNH BÁO: Bạn chưa cài thư viện curl_cffi! Tool không thể vượt Cloudflare. Hãy chạy 'pip install curl_cffi'.")
            pass

        # --- BƯỚC 2: Dùng requests thuần với DoH Bypass (nếu bị ISP chặn) ---
        try:
            return requests.get(url, headers=headers, **kwargs)
        except requests.exceptions.ConnectionError as original_err:
            # Kết nối bị chặn -> thử giải DNS qua DoH + socket patch
            parsed = urlparse(url)
            domain = parsed.netloc
            bare_domain = domain.replace("www.", "") if domain.startswith("www.") else domain
            ip = self._resolve_via_doh(bare_domain)
            if not ip:
                ip = self._resolve_via_doh(domain)
            if ip:
                self.log(f"[*] Vượt chặn ISP (DNS): {domain} -> {ip}")
                import socket
                original_getaddrinfo = socket.getaddrinfo
                def patched_getaddrinfo(host, port, *args, **kw):
                    if host == domain:
                        return original_getaddrinfo(ip, port, *args, **kw)
                    return original_getaddrinfo(host, port, *args, **kw)
                try:
                    socket.getaddrinfo = patched_getaddrinfo
                    # Thử lại bằng requests thuần (đã patch IP)
                    return requests.get(url, headers=headers, **kwargs)
                except Exception:
                    # DoH bypass cũng thất bại -> ISP chặn ở tầng TLS/SNI (DPI)
                    self.log(f"[!] Nhà mạng chặn {domain} ở tầng TLS (Deep Packet Inspection).")
                    self.log(f"[!] Vui lòng BẬT ứng dụng 1.1.1.1 WARP (miễn phí) rồi thử lại.")
                    self.log(f"[!] Tải WARP tại: https://1.1.1.1")
                    raise
                finally:
                    socket.getaddrinfo = original_getaddrinfo
            raise original_err

    def get_comic_info(self, comic_url):
        # Hàm mới để UI gọi lấy tên truyện trước khi tải
        domain = self.get_domain(comic_url)
        if domain not in self.configs:
            return None, "Domain chưa được hỗ trợ trong config.json."
        
        site_config = self.configs[domain]
        headers = site_config.get("headers", {"User-Agent": "Mozilla/5.0"})
        
        try:
            res = self._safe_get(comic_url, headers=headers, timeout=60)
            res.raise_for_status()
            res.encoding = 'utf-8'
            html = res.text
            if "Just a moment" in html or "cloudflare" in html.lower() or "Attention Required!" in html:
                raise Exception("Trang trả về màn hình chờ Cloudflare.")
        except Exception as e:
            self.log(f"[!] {e}")
            html = self._get_html_with_selenium(comic_url)
            if not html:
                return None, f"Lỗi truy cập web: {e}"
            
        soup = BeautifulSoup(html, 'html.parser')
        comic_title = "Unknown_Comic"
        for sel in site_config.get("comic_title_selector", "").split(","):
            title_tag = soup.select_one(sel.strip())
            if title_tag:
                comic_title = self.sanitize_filename(title_tag.text)
                break
        
        # Lưu HTML vào cache để process_comic tái sử dụng, không cần tải lại
        self._page_cache[comic_url] = html
        return comic_title, ""

    def load_progress(self, comic_dir):
        progress_path = os.path.join(comic_dir, "progress.json")
        if os.path.exists(progress_path):
            try:
                with open(progress_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        return {"downloaded_chapters": []}

    def save_progress(self, comic_dir, progress_data):
        progress_path = os.path.join(comic_dir, "progress.json")
        with open(progress_path, 'w', encoding='utf-8') as f:
            json.dump(progress_data, f, ensure_ascii=False, indent=4)

    def download_image(self, img_url, save_path, headers):
        try:
            # Nếu URL ảnh đi qua proxy bên thứ 3 (duckduckgo, pixhost...),
            # phải bỏ Referer header vì proxy từ chối request có Referer lạ.
            dl_headers = dict(headers)
            img_domain = urlparse(img_url).netloc.lower()
            if any(proxy in img_domain for proxy in ['duckduckgo', 'pixhost', 'imgur']):
                dl_headers.pop('Referer', None)
                dl_headers.pop('referer', None)
            
            response = self._safe_get(img_url, headers=dl_headers, stream=True, timeout=30)
            if response.status_code == 200:
                with open(save_path, 'wb') as f:
                    for chunk in response.iter_content(1024):
                        f.write(chunk)
                return True
        except:
            pass
        return False

    def process_comic(self, comic_url, dest_dir=None, resume=False, server_id=1, log_callback=None):
        self.log_callback = log_callback
        
        # Tải lại file config.json mỗi lần chạy để luôn cập nhật selector mới nhất
        self.configs = self.load_configs()
        
        domain = self.get_domain(comic_url)
        if domain not in self.configs:
            self.log(f"[-] Chưa có cấu hình cho domain: {domain}")
            return

        site_config = self.configs[domain]
        headers = site_config.get("headers", {"User-Agent": "Mozilla/5.0"})

        self.log(f"[*] Đang lấy thông tin truyện từ: {comic_url}")
        
        # ƯU TIÊN dùng lại HTML đã cache từ get_comic_info (tránh tải lại cung URL)
        if comic_url in self._page_cache:
            self.log("[*] Sử dụng lại HTML đã lấy sẵn (cache). Không cần tải lại.")
            html = self._page_cache.pop(comic_url)  # pop để tự giải phóng bộ nhớ
        else:
            try:
                res = self._safe_get(comic_url, headers=headers, timeout=60)
                res.raise_for_status()
                res.encoding = 'utf-8'
                html = res.text
                if "Just a moment" in html or "cloudflare" in html.lower() or "Attention Required!" in html:
                    raise Exception("Trang trả về màn hình chờ Cloudflare.")
            except Exception as e:
                self.log(f"[!] {e}")
                html = self._get_html_with_selenium(comic_url)
                if not html:
                    self.log("[!] Lỗi khi truy cập trang chính và giả lập trình duyệt thất bại.")
                    return

        soup = BeautifulSoup(html, 'html.parser')
        
        comic_title = "Unknown_Comic"
        for sel in site_config.get("comic_title_selector", "").split(","):
            title_tag = soup.select_one(sel.strip())
            if title_tag:
                comic_title = self.sanitize_filename(title_tag.text)
                break
        
        comic_dir = dest_dir if dest_dir else os.path.join(os.getcwd(), comic_title)
        os.makedirs(comic_dir, exist_ok=True)
        
        progress_data = self.load_progress(comic_dir) if resume else {"downloaded_chapters": []}

        chapter_links = []
        if domain == "truyenmmhayr.com":
            script_tag = soup.find("script", id="script-chapter")
            if script_tag and "data-id" in script_tag.attrs:
                topic_id = script_tag["data-id"]
                api_url = f"https://{domain}/api/get-topic?id={topic_id}"
                try:
                    api_res = self._safe_get(api_url, headers=headers, timeout=15)
                    api_res.raise_for_status()
                    api_data = api_res.json()
                    chapters_data = api_data.get("topic", {}).get("chapters", [])
                    for item in chapters_data:
                        name = item.get("name", "")
                        chap_id = item.get("id", "")
                        link_part = chap_id.replace("-chapter-", "/chapter-")
                        full_link = f"https://{domain}/truyen/{link_part}"
                        chapter_links.append((name, full_link))
                except Exception as e:
                    self.log(f"[!] Lỗi khi lấy danh sách chương qua API: {e}")
        else:
            for tag in soup.select(site_config.get("chapter_list_selector", "")):
                link = tag.get(site_config.get("chapter_link_attr", "href"))
                title = tag.text.strip()
                if link:
                    full_link = urljoin(comic_url, link)
                    chapter_links.append((title, full_link))
        
        chapter_links.reverse()
        
        # Fallback: Nếu không tìm thấy bằng selector cấu hình, tự động rà quét các link có chứa tên truyện (slug)
        if not chapter_links:
            self.log("[*] Selector cấu hình không tìm thấy chương. Đang thử rà quét toàn bộ link (Fallback)...")
            try:
                comic_slug = comic_url.rstrip('/').split('/')[-1].replace('.html', '')
                for tag in soup.find_all('a', href=True):
                    link = tag['href']
                    # Link phải chứa slug của truyện, chứa từ khóa báo hiệu chương, và không phải là link trang chủ truyện
                    if link != comic_url and comic_slug in link:
                        lw_link = link.lower()
                        if 'chap' in lw_link or '-c' in lw_link or 'oneshot' in lw_link or 'chuong' in lw_link:
                            full_link = urljoin(comic_url, link)
                            if full_link.startswith('http') and domain in full_link:
                                title = tag.text.strip() or "Unknown Chapter"
                                # Tránh trùng lặp
                                if not any(c_url == full_link for _, c_url in chapter_links):
                                    chapter_links.append((title, full_link))
            except Exception as e:
                self.log(f"[!] Lỗi khi rà quét link dự phòng: {e}")

        if not chapter_links:
            self.log("[-] Không tìm thấy danh sách chương (cả 2 phương án).")
            return
            
        self.log(f"[*] Tìm thấy {len(chapter_links)} chương. Bắt đầu tải...")

        for idx, (chap_title, chap_url) in enumerate(chapter_links, 1):
            chap_title_clean = self.sanitize_filename(chap_title)
            chap_dir_name = f"Chuong {idx:03d} - {chap_title_clean}" if "chuong" not in chap_title_clean.lower() else chap_title_clean
            
            if resume and chap_dir_name in progress_data["downloaded_chapters"]:
                self.log(f"[-] Đã tải (Skip): {chap_dir_name}")
                continue
                
            chap_dir = os.path.join(comic_dir, chap_dir_name)
            os.makedirs(chap_dir, exist_ok=True)

            self.log(f"\n[+] Đang xử lý: {chap_dir_name}")
            
            try:
                c_res = self._safe_get(chap_url, headers=headers, timeout=60)
                c_res.raise_for_status()
                c_res.encoding = 'utf-8'
                c_html = c_res.text
            except Exception as e:
                self.log(f"[!] Lỗi requests chương {chap_dir_name}: {e}. Đang chuyển qua Selenium...")
                c_html = self._get_html_with_selenium(chap_url)
                if not c_html:
                    self.log(f"[!] Không thể tải HTML chương {chap_dir_name} bằng Selenium. Bỏ qua.")
                    continue
            
            used_selenium_for_chapter = False

            c_soup = BeautifulSoup(c_html, 'html.parser')
            
            img_urls = []
            server_extracted = False
            
            # Xử lý Server Selection (Đặc thù cho hentaivnx dùng biến cdn1, cdn2, cdn3)
            if server_id > 1:
                match = re.search(fr'var cdn{server_id}\s*=\s*\'(.*?)\';', c_html)  # Sửa: dùng c_html thay vì c_res.text
                if match:
                    try:
                        # Extract the JSON array string
                        cdn_json_str = match.group(1).replace("\\/", "/")
                        cdn_urls = json.loads(cdn_json_str)
                        for u in cdn_urls:
                            u = u.split("-----")[0] # Fix width format
                            img_urls.append(u)
                        server_extracted = True
                        self.log(f"[*] Lấy {len(img_urls)} ảnh từ Server {server_id}.")
                    except Exception as e:
                        self.log(f"[!] Lỗi giải mã dữ liệu Server {server_id}: {e}")
                else:
                    self.log(f"[!] Không tìm thấy dữ liệu Server {server_id}, tự động về mặc định.")

            if not server_extracted:
                # KIỂM TRA IMAGE REGEX (Dành cho web giấu link trong JS/JSON payloads)
                regex_pattern = site_config.get("image_regex")
                if regex_pattern:
                    import re
                    matches = re.findall(regex_pattern, c_html)
                    if matches:
                        img_urls.extend(list(dict.fromkeys(matches)))
                        server_extracted = True
                        self.log(f"[*] Tìm thấy {len(img_urls)} ảnh bằng Regex cấu hình (Bypass Lazy-load).")

            if not server_extracted:
                img_tags = []
                for sel in site_config.get("image_list_selector", "").split(","):
                    img_tags.extend(c_soup.select(sel.strip()))
                    if img_tags:
                        break
                
                if not img_tags:
                    if not used_selenium_for_chapter:
                        # PHƯƠNG ÁN 2: Thử lại bằng Selenium khi không tìm thấy ảnh
                        self.log(f"[-] Không tìm thấy ảnh bằng requests. Thử Selenium...")
                        c_html_sel = self._get_html_with_selenium(chap_url)
                        if c_html_sel:
                            c_soup = BeautifulSoup(c_html_sel, 'html.parser')
                            for sel in site_config.get("image_list_selector", "").split(","):
                                img_tags.extend(c_soup.select(sel.strip()))
                                if img_tags:
                                    break
                            used_selenium_for_chapter = True
                    
                    if not img_tags:
                        self.log(f"[-] Không tìm thấy ảnh trong chương này (cả 2 phương án).")
                        # Đánh dấu đã tải để không bị kẹt ở chương lỗi nếu chạy resume
                        progress_data["downloaded_chapters"].append(chap_dir_name)
                        self.save_progress(comic_dir, progress_data)
                        continue

                for img in img_tags:
                    src = None
                    for attr in site_config.get("image_src_attrs", ["src"]):
                        if img.has_attr(attr) and img[attr].strip():
                            src = img[attr].strip()
                            break
                    if src:
                        img_urls.append(urljoin(chap_url, src))

            success_count = 0
            for i, i_url in enumerate(img_urls, 1):
                ext = i_url.split('.')[-1].split('?')[0]
                if ext.lower() not in ['jpg', 'jpeg', 'png', 'webp', 'gif']:
                    ext = 'jpg'
                
                img_filename = f"{i:03d}.{ext}"
                save_path = os.path.join(chap_dir, img_filename)
                
                if os.path.exists(save_path):
                    success_count += 1
                    continue
                
                if self.download_image(i_url, save_path, headers):
                    success_count += 1
                
                # Cập nhật tiến độ % lên GUI log (ví dụ: Tải ảnh: 5/20)
                if i % 5 == 0 or i == len(img_urls):
                    self.log(f"    -> Tải ảnh: {success_count}/{len(img_urls)}")

            self.log(f"[*] Hoàn tất tải {success_count}/{len(img_urls)} ảnh cho {chap_title_clean}.")
            
            # Cập nhật JSON
            if chap_dir_name not in progress_data["downloaded_chapters"]:
                progress_data["downloaded_chapters"].append(chap_dir_name)
                self.save_progress(comic_dir, progress_data)
        
        self.log("\n[=========== HOÀN TẤT ===========]")
