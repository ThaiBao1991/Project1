# Project Log: Ứng dụng Tải và Đọc Truyện Tranh (Comic Downloader & Reader)

File này dùng để theo dõi quá trình phát triển, các quyết định quan trọng và các lỗi đã khắc phục của dự án.

## Mục tiêu
Phát triển một ứng dụng Desktop (sử dụng thư viện `customtkinter`) chuyên dụng để tải truyện tranh từ nhiều nguồn web khác nhau và tích hợp trình đọc truyện tối ưu (Reader) trực tiếp trên máy tính.

---

## Nhật ký công việc

### Giai đoạn 1 — Khởi tạo core Downloader bằng Python
- Viết script `downloader.py` thuần túy bằng Python sử dụng `requests` và `BeautifulSoup` để cào dữ liệu truyện tranh từ trang `teletruyen.com`.
- Tạo cơ chế bóc tách thông tin truyện:
  - Tên truyện, danh sách chương, các link ảnh.
- Áp dụng kỹ thuật `Threading` kết hợp với `ThreadPoolExecutor` để tải song song nhiều ảnh cùng lúc, giúp tăng tốc độ tải lên gấp 10 lần so với tải tuần tự.
- Xử lý các lỗi SSL hoặc kết nối mạng khi tải, đảm bảo không bị crash giữa chừng.

### Giai đoạn 2 — Giao diện GUI Desktop siêu đẹp (CustomTkinter)
- Chuyển đổi từ công cụ chạy Terminal (CLI) sang ứng dụng Desktop hoàn chỉnh (`main_gui.py`) sử dụng thư viện `customtkinter` để giao diện trông hiện đại (Dark Mode, bo góc, bóng đổ).
- Ứng dụng được chia làm 2 Tab chính:
  - **Tab 1: Tải Truyện**: Chứa các cấu hình nguồn web, ô nhập URL, đường dẫn lưu, Console Log (để theo dõi quá trình tải) và chức năng Tự động lấy tên truyện.
  - **Tab 2: Đọc Truyện**: Chứa chức năng chọn thư mục truyện, danh sách mục lục (Table of Contents), và trình xem ảnh.
- Tính năng Console Log hiển thị tiến trình tải ngay trên màn hình app mà không cần mở Terminal.

### Giai đoạn 3 — Lưu tiến trình (Resume) qua `progress.json`
- **Vấn đề**: Truyện thường có rất nhiều chương, nếu tải bị lỗi mạng hoặc muốn tải thêm chương mới thì phần mềm sẽ tải lại từ đầu, gây mất thời gian và dung lượng.
- **Giải pháp**: Xây dựng cơ chế Auto-Resume.
  - Khi tải xong bất kỳ chương nào, ghi tên chương đó vào file `progress.json` nằm ngay trong thư mục lưu truyện.
  - Khi tải lại, nếu chọn checkbox "Tiếp tục tải (Resume)", phần mềm sẽ đọc `progress.json`, bỏ qua các chương đã có và chỉ tải những chương mới được cập nhật trên web.

### Giai đoạn 4 — Xây dựng tính năng Reader (Đọc truyện) mượt mà
- Áp dụng `CTkScrollableFrame` để cuộn xem ảnh theo chiều dọc y như các web đọc truyện online thực thụ.
- Bổ sung phím tắt: Bấm phím **Mũi tên Trái/Phải** để nhảy qua lại giữa các tập/chương, phần mềm tự động quét cấu trúc thư mục để load tập tiếp theo/trước đó.
- Bổ sung tính năng **Zoom** (Phóng to / Thu nhỏ): 
  - Tính năng "Fit Width" (tự động co giãn ảnh cho vừa khít với chiều ngang màn hình).
  - Thanh công cụ điều chỉnh % phóng to (50%, 100%, 150%, 200%).
  - Hỗ trợ cuộn chuột lăn trang cực kỳ mượt mà để lướt từ ảnh này sang ảnh khác.
- Sửa lỗi khi sang chương mới ảnh không tự nhảy lên đầu trang (Auto scroll to top).

### Giai đoạn 5 — Sửa lỗi Encoding (Lỗi font Tiếng Việt)
- **Vấn đề**: Tên truyện tải về bị lỗi hiển thị các ký tự lạ (VD: `GiÃ¡o SÆ°...`).
- **Giải pháp**: Lỗi xảy ra do thư viện `requests` tự đoán sai bảng mã khi web không khai báo rõ ràng. Khắc phục bằng cách ép cứng `res.encoding = 'utf-8'` trước khi parse HTML, giúp lấy chính xác tên truyện Tiếng Việt có dấu.

### Giai đoạn 6 — Bypass kỹ thuật Lazy-load của TruyenMMHay (Cào qua API)
- **Vấn đề**: Trang `truyenmmhayr.com` áp dụng Lazy-load (phân trang), chỉ hiển thị khoảng 20-30 chương mới nhất, nếu chỉ parse HTML thô thì không thể lấy được những chương cũ hơn trừ khi bấm nút "Xem Thêm". Hơn nữa, danh sách chương bị xếp ngược (từ mới đến cũ).
- **Giải pháp**:
  - Viết luồng xử lý riêng cho `truyenmmhayr.com` trong file `downloader.py`.
  - Quét tìm đoạn script chứa mã ID ẩn của truyện (`dataset-id`).
  - Gửi HTTP Request thẳng vào API nội bộ của trang web (`/api/get-topic?id=...`) để lấy ra một file JSON chứa trọn bộ **100% tất cả các chương** ngay lập tức mà không cần click.
  - Tự động gọi hàm `.reverse()` để đảo ngược mảng chương, đảm bảo luôn tải từ Chương 1 đến Chương mới nhất và đánh số thư mục theo thứ tự tăng dần (`Chuong 001`, `Chuong 002`...).

### Giai đoạn 7 — Sửa lỗi tải ảnh Loading Spinner do Lazy-load
- **Vấn đề**: Nhiều ảnh tải về hiển thị lỗi hoặc ra hình tròn "Đang xoay" (Loading Spinner).
- **Nguyên nhân**: Trang web dùng Lazy-load ảnh nên thẻ `src` chính chứa ảnh Spinner, còn link ảnh thật bị giấu trong thẻ `data-src`. Cấu hình `image_src_attrs` cũ ưu tiên `src` trước nên đã quét nhầm ảnh Spinner.
- **Giải pháp**: Sửa đổi mảng ưu tiên trong `config.json` thành `["data-src", "data-original", "src"]`. Qua đó, phần mềm sẽ ưu tiên tìm các thuộc tính chứa link ảnh gốc trước rồi mới fallback về `src`.

### Giai đoạn 8 — Mở rộng cấu hình (Thêm các nguồn truyện mới)
- Bổ sung cấu hình cào dữ liệu cho `hentaivnx.com` và `lxmanga.org` vào `config.json` với các bộ nhận diện CSS chuẩn xác:
  - Tên truyện: `h1.title-detail`, `h1.title`, `h1`
  - Chương: `.list-chapter li a`, `.chapter-list a`, `a[href*='/chapter-']`, `a[href*='-c']`
  - Ảnh: `.page-chapter img`, `.reading-detail img`, `img.lozad`
- Đảm bảo cơ chế tự động tìm `data-src` để chặn lỗi tải ảnh Loading áp dụng cho tất cả các nguồn truyện mới.

### Giai đoạn 9 — Tính năng Chọn Server tải ảnh (Server Selection)
- **Vấn đề**: Trang `hentaivnx.com` cung cấp tối đa 4 Server lưu ảnh (Server 1-4). Mặc định Server 1 đôi khi bị mất link / die ảnh, khiến tải về bị lỗi hoặc thiếu ảnh.
- **Phát hiện kỹ thuật**: Trong mã nguồn HTML của mỗi chương, trang web giấu danh sách link ảnh của từng Server dưới dạng biến Javascript (`var cdn1 = '[...]'`, `var cdn2 = '[...]'`...).
- **Giải pháp**:
  - Thêm Dropdown "Chọn Server: 1 / 2 / 3 / 4" trên giao diện GUI (`main_gui.py`).
  - Khi người dùng chọn Server > 1, `downloader.py` sẽ dùng Regex (`re.search`) để trích xuất biến `var cdn{N}` từ mã Javascript ẩn, giải mã JSON array thành danh sách URL ảnh sạch rồi dùng chúng để tải.
  - Nếu trang web không có dữ liệu Server phụ (các trang khác ngoài hentaivnx), Tool tự động fallback về cách tải thẻ `<img>` mặc định.

### Giai đoạn 10 — Tự động vượt chặn nhà mạng (DoH Bypass + DPI Detection)
- **Vấn đề**: Nhiều trang truyện 18+ bị nhà mạng Việt Nam (Viettel, VNPT, FPT) chặn ở 2 tầng:
  1. **Chặn DNS**: Nhà mạng trả về IP sai khi giải tên miền → Tool không kết nối được.
  2. **Chặn TLS/SNI (DPI)**: Nhà mạng đọc trường SNI trong gói TLS ClientHello, thấy tên miền bị cấm là cắt kết nối ngay.
- **Giải pháp**:
  - Xây dựng hàm `_resolve_via_doh()` — giải DNS qua Cloudflare DoH API (`cloudflare-dns.com/dns-query`) để lấy IP thật, cache kết quả để không gọi lại.
  - Xây dựng hàm `_safe_get()` — wrapper thay thế toàn bộ `requests.get()`, tự động:
    1. Thử kết nối bình thường trước.
    2. Nếu thất bại (`ConnectionError`), giải DNS qua DoH rồi dùng `socket.getaddrinfo` patching để ép IP đúng.
    3. Nếu vẫn thất bại (DPI chặn TLS), hiển thị thông báo rõ ràng hướng dẫn người dùng bật ứng dụng **1.1.1.1 WARP** (miễn phí).
  - Cài thêm thư viện `curl_cffi` để sử dụng trong tương lai nếu cần giả lập TLS fingerprint.

### Giai đoạn 11 — Vượt Cloudflare Turnstile & Chặn DNS cục bộ (Tối thượng)
- **Vấn đề 1**: Tool gặp lỗi `ERR_CONNECTION_REFUSED` do nhà mạng đánh độc DNS cục bộ (trả về IP ảo `::1` hoặc `127.0.0.1`), làm thư viện `requests` và `curl_cffi` tê liệt hoàn toàn khi cố truy cập các trang bị cấm như `lxmanga.org`.
- **Vấn đề 2**: Kể cả khi mở Chrome bằng Selenium, Cloudflare vẫn phát hiện ra Bot và giam trình duyệt ở vòng lặp "Just a moment..." vô tận.
- **Giải pháp Toàn Diện**:
  1. Thay thế Selenium tiêu chuẩn bằng thư viện **`undetected_chromedriver` (uc)** chuyên "Hắc Khách" Cloudflare, tự động vô hiệu hóa các biến `cdc_` và xóa dấu vết Webdriver. Đặt chế độ `--headless=new` để trình duyệt tự động chạy ngầm, không làm phiền người dùng.
  2. **Chiến thuật "Làm nóng" (Warm-up)**: Mở trang `google.com` và chờ 5 giây trước khi vào trang đích. Bước này ép Chrome khởi động cơ chế Secure DNS ngầm để vượt qua sự kiểm duyệt DNS của nhà mạng, triệt tiêu lỗi `ERR_CONNECTION_REFUSED`.
  3. **Tái sử dụng Driver (Persistent Driver)**: Để tránh tình trạng mỗi chương lại mở một trình duyệt mới cực kỳ mất thời gian, `ComicDownloader` giữ lại một biến `self.driver`. Trình duyệt ngầm chỉ khởi tạo 1 lần và được dùng để cào toàn bộ danh sách HTML của tất cả các chương. Hỗ trợ try-catch fallback hoàn chỉnh cho `process_comic`.

### Giai đoạn 12 — Tối ưu Vượt Cloudflare & Chiến thuật Cào Vét (Universal Fallback)
- **Vấn đề 1**: Chờ Cloudflare bằng thời gian cứng `time.sleep(15)` rất thiếu ổn định. Đôi khi qua sớm, đôi khi qua trễ. Nếu kiểm tra `cloudflare` trong `page_source` thì bị dính lỗi lặp vô tận vì nhiều trang web nhúng sẵn script Cloudflare CDN vào ruột HTML.
- **Giải pháp 1**: Áp dụng Polling thông minh (đợi tối đa 40s). Thay vì đọc `page_source`, mã nguồn sẽ kiểm tra `driver.title` định kỳ mỗi 2s. Khi title thoát khỏi chữ `"Just a moment"` hoặc `"Verifying"`, chứng tỏ đã xác minh xong, lập tức lấy HTML để tiết kiệm thời gian.
- **Vấn đề 2**: Các trang web hay đổi giao diện, class HTML, hoặc dùng framework (Next.js) tạo CSS động khiến bộ Selector tĩnh trong `config.json` thất bại, trả về 0 chương.
- **Giải pháp 2**: Cài cắm **Universal Fallback Selector**. Nếu Selector chính quy thất bại, tool sẽ tự động quét TẤT CẢ các thẻ `<a>` trên toàn trang. Nó tìm các link chứa `tên-truyện-slug` (để tránh lấy nhầm truyện khác) VÀ chứa từ khóa chỉ định như `chap`, `-c`, `oneshot`, hoặc `chuong`. Kỹ thuật cào vét này đảm bảo không bao giờ bỏ sót chương kể cả khi website đổi cấu trúc giao diện.

### Giai đoạn 13 — Tối ưu hóa Trải nghiệm Người Dùng (Lưu thiết lập)
- **Vấn đề**: Mỗi lần lấy truyện mới hoặc qua Tab Đọc, người dùng phải Browse chọn lại thư mục cực kỳ mất thời gian.
- **Giải pháp**: Xây dựng hệ thống lưu settings đơn giản (`settings.json`).
  - Ghi nhớ `last_download_dir` (Thư mục gốc tải truyện, VD: `D:\Comics`) để lần sau tự động gợi ý đường dẫn lưu `D:\Comics\Tên-Truyện`.
  - Ghi nhớ `last_read_dir` để lần sau mở Tab Đọc sẽ trỏ thẳng vào thư mục gốc chứa các đầu truyện đã tải.

---

## Cấu trúc file hiện tại
- `config.json`: File thiết lập các quy tắc bóc tách (CSS selectors). Hỗ trợ các trang: teletruyen, truyenmmhayr, hentaivnx, lxmanga, vinahentai.club.
- `settings.json`: File lưu trữ tự động các thiết lập cá nhân hóa (Thư mục lưu cuối cùng, v.v).
- `downloader.py`: Chứa class `ComicDownloader` đảm nhiệm toàn bộ core Logic cào data, đa luồng tải ảnh, Resume JSON, fix API ngầm.
- `main_gui.py`: Trái tim của giao diện, điều phối Tab Tải, Tab Đọc, xử lý UI Events.
- `requirements.txt`: Các thư viện phụ thuộc (`customtkinter`, `Pillow`, `requests`, `beautifulsoup4`, `undetected-chromedriver`).
- `ProjectLog.md`: Lịch sử cập nhật của dự án.
