import sys
from downloader import ComicDownloader

if sys.stdout.encoding != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8')

def main():
    print("="*50)
    print(" "*10 + "COMIC DOWNLOADER TOOL")
    print("="*50)
    
    downloader = ComicDownloader("config.json")
    
    if len(sys.argv) > 1:
        comic_url = sys.argv[1]
    else:
        comic_url = input("Nhập link truyện cần tải (ví dụ: https://teletruyen.com/...): ").strip()
        
    if not comic_url:
        print("Link không hợp lệ. Đang thoát...")
        return
        
    downloader.process_comic(comic_url)

if __name__ == "__main__":
    main()
