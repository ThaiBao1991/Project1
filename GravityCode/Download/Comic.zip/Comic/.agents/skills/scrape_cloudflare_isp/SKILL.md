---
name: scrape_cloudflare_isp
description: Kỹ năng cào dữ liệu từ các trang web bị chặn bởi ISP (đánh độc DNS) và có sử dụng Cloudflare Bot Management.
---

# Web Scraping: Vượt Cloudflare & ISP DNS Blocking

Khi cào dữ liệu từ các trang web (đặc biệt là truyện tranh, phim ảnh, 18+), bạn sẽ thường xuyên gặp 2 lớp bảo vệ song song:
1. **Lớp 1 (Nhà mạng ISP):** Đánh độc DNS, trả về `127.0.0.1` hoặc `::1`, gây ra lỗi `ERR_CONNECTION_REFUSED` (hoặc timeout) khi gửi HTTP Request.
2. **Lớp 2 (Cloudflare):** Hệ thống Bot Management giam trình duyệt bot ở màn hình "Just a moment..." mãi mãi (Turnstile loop).

Để giải quyết vấn đề này, hãy áp dụng chiến thuật **"Mượn sức Trình Duyệt Ngầm" (Undetected Chromedriver Persistent)**:

## 1. Thiết lập thư viện
Luôn luôn sử dụng `undetected-chromedriver` (uc) thay vì Selenium nguyên bản để qua mặt Cloudflare.
Cài đặt: `pip install undetected-chromedriver`

## 2. Chiến thuật Code Mẫu

```python
import undetected_chromedriver as uc
import time
import requests

class Scraper:
    def __init__(self):
        self.driver = None

    def get_driver(self):
        if self.driver is None:
            options = uc.ChromeOptions()
            options.add_argument('--headless=new')  # Chạy ẩn 100% không phiền người dùng
            options.add_argument('--log-level=3')   # Tắt log rác
            
            # Khởi tạo trình duyệt
            self.driver = uc.Chrome(options=options)
            self.driver.set_page_load_timeout(60)
            
            # CHIẾN THUẬT WARM-UP (LÀM NÓNG) CỰC KỲ QUAN TRỌNG:
            # Mở một trang HTTPS uy tín (như google) và chờ 5 giây để Chrome tự động kích hoạt
            # cơ chế Secure DNS (DoH) ngầm. Điều này giúp bỏ qua hoàn toàn file Hosts cục bộ
            # và DNS của nhà mạng, triệt tiêu lỗi ERR_CONNECTION_REFUSED.
            self.driver.get("https://www.google.com")
            time.sleep(5)
            
        return self.driver

    def get_html(self, url):
        # 1. Thử requests bình thường trước (Nhanh nhất)
        try:
            res = requests.get(url, timeout=10)
            res.raise_for_status()
            return res.text
        except Exception as e:
            # 2. Nếu thất bại do chặn mạng hoặc Cloudflare (403), fallback qua Selenium
            pass
            
        driver = self.get_driver()
        for attempt in range(3):
            try:
                driver.get(url)
                break
            except Exception as e:
                if "CONNECTION_REFUSED" in str(e) and attempt < 2:
                    time.sleep(3)
                else:
                    raise e
                    
        # CHỜ CLOUDFLARE THÔNG MINH (Polling qua title)
        # Trang web thường nhúng script Cloudflare tĩnh, nên check 'page_source' sẽ dễ bị sai (chạy lặp vô tận)
        # Thay vào đó hãy check 'driver.title'. Cloudflare thường set title là 'Just a moment...' hoặc 'Verifying...'
        cf_wait = 0
        while cf_wait < 40:
            try:
                title = driver.title
            except:
                title = ""
            if "Just a moment" not in title and "Verifying" not in title:
                break
            time.sleep(2)
            cf_wait += 2
            
        html = driver.page_source
        
        # CHIẾN THUẬT FALLBACK LINK CHƯƠNG (Cào vét)
        # Đôi khi CSS Selector cấu hình trong config không hoạt động (do web đổi cấu trúc hoặc lazy-render),
        # Hãy luôn thiết kế một vòng lặp phụ: cào tất cả <a> tags, lọc những link chứa 'tên_truyện_không_dấu' (slug)
        # và chứa các từ khóa báo hiệu (chap, chuong, oneshot, -c) để tự động nhặt link chương mà không cần Selector.
        
        return html
```

## 3. Lưu ý quan trọng
- **Tái sử dụng Driver:** Luôn lưu `self.driver` thành thuộc tính của Class để tái sử dụng cho các trang sau. Đừng khởi tạo và đóng `driver.quit()` cho mỗi URL, việc đó sẽ làm Cloudflare nghi ngờ và tốc độ cào cực kỳ chậm.
- **Tải ảnh tĩnh (Images) và Bẫy Lazy-load:**
  - **Trường hợp 1 (Lazy-load truyền thống):** Ảnh giấu link thật trong các thuộc tính như `data-src`, `data-original`. Khi tạo `config.json`, BẮT BUỘC thiết lập mảng: `"image_src_attrs": ["data-src", "data-original", "src"]`. Code sẽ tự động lùi ưu tiên để lấy đúng link ảnh gốc.
  - **Trường hợp 2 (Lazy-load cấp cao bằng React/Next.js):** Các trang web hiện đại (VD: Vinahentai) nhúng link ảnh vào một chuỗi JSON bên trong thẻ `<script>` và chỉ render vài ảnh đầu, các ảnh sau là base64 rỗng. Thay vì dùng Selenium cuộn trang rất chậm, hãy khai báo thêm thuộc tính `"image_regex": "..."` trong `config.json`. Tool sẽ quét thẳng mã nguồn thô (raw HTML) để móc toàn bộ mảng link ảnh ra chỉ trong 0.01 giây!
