# General Rules

- **KI First**: Always review Knowledge Items (KI) first when starting a new conversation or task.
- **ProjectLog.md**: Always read `ProjectLog.md` before starting to understand the current context. ALWAYS update `ProjectLog.md` after making significant changes to reflect the new state.
- **Strict Plan Before Code**: Always propose an implementation plan before execution. You MUST wait for the user's explicit approval (e.g., "ok") BEFORE writing or modifying any code.
- **Self-Correction, Verification & Proactive Fixing**: After writing code, you MUST review, check, and fix any immediate errors (e.g., run tests, build, or analyze output). Furthermore, you must also proactively identify and fix any potential errors or edge cases that might occur. Do not mark the task as complete until all errors are resolved and verified.

## ⚠️ Checklist Bắt Buộc Trước Khi Code (Pre-Code Checklist)
Trước **bất kỳ** thao tác chỉnh sửa file hay viết code nào, tôi PHẢI tự hỏi:
- [ ] Tôi đã đề xuất phương án rõ ràng và chờ người dùng nói "ok" chưa?
- [ ] Tôi đã đọc file liên quan để hiểu ngữ cảnh hiện tại chưa?
- [ ] Tôi đã xác định chính xác những file nào sẽ bị thay đổi chưa?
- [ ] Sau khi sửa, tôi có kế hoạch tự verify kết quả không?

> ⛔ KHÔNG được bắt đầu gõ code, sửa file, hay chạy lệnh sửa đổi nếu chưa qua checklist này.
