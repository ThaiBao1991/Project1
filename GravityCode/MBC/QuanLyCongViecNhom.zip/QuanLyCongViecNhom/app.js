/**
 * MBC Quản Lý Công Việc & Hiệu Suất Nhóm
 * Core JavaScript Logic - Phiên bản 2.6
 * - Hỗ trợ xem Toàn cảnh: Theo Ngày, Theo Tuần, Theo Tháng (cả năm & năm sau)
 * - Mũi tên Gantt Excel liền mạch, không đứt đoạn
 * - Cấu hình tiêu đề báo cáo Excel linh hoạt
 * - Phân cấp Công việc chính & Công việc con (Parent Task & Subtasks)
 * - Chọn nhanh công việc chưa hoàn thành để cập nhật tiến độ
 */

// ================= UTILITY FUNCTIONS (PHẢI KHÁI BÁO ĐẦU) =================

/**
 * Hiển thị thông báo toast ở góc màn hình.
 * @param {string} msg - Nội dung thông báo
 * @param {'success'|'warning'|'error'|'info'} type - Loại toast
 * @param {number} duration - Thời gian hiển thị (ms), mặc định 3500
 */
function showToast(msg, type = 'info', duration = 3500) {
  // Tạo container nếu chưa có
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.style.cssText = 'position:fixed;bottom:1.25rem;right:1.25rem;z-index:9999;display:flex;flex-direction:column;gap:0.5rem;pointer-events:none;';
    document.body.appendChild(container);
  }

  const colors = {
    success: { bg: '#d1fae5', border: '#6ee7b7', text: '#065f46', icon: '✅' },
    warning: { bg: '#fef9c3', border: '#fde047', text: '#713f12', icon: '⚠️' },
    error:   { bg: '#fee2e2', border: '#fca5a5', text: '#7f1d1d', icon: '❌' },
    info:    { bg: '#e0f2fe', border: '#7dd3fc', text: '#0c4a6e', icon: 'ℹ️' },
  };
  const c = colors[type] || colors.info;

  const toast = document.createElement('div');
  toast.style.cssText = [
    `background:${c.bg}`,
    `border:1.5px solid ${c.border}`,
    `color:${c.text}`,
    'padding:0.6rem 0.9rem',
    'border-radius:0.75rem',
    'font-size:0.75rem',
    'font-weight:600',
    'max-width:360px',
    'white-space:pre-line',
    'box-shadow:0 4px 16px rgba(0,0,0,0.13)',
    'pointer-events:all',
    'cursor:pointer',
    'opacity:1',
    'transition:opacity 0.3s ease',
  ].join(';');
  toast.textContent = `${c.icon}  ${msg}`;
  toast.title = 'Click để đóng';
  toast.onclick = () => removeToast(toast);
  container.appendChild(toast);

  setTimeout(() => removeToast(toast), duration);
}

function removeToast(el) {
  if (!el) return;
  el.style.opacity = '0';
  setTimeout(() => { if (el.parentNode) el.parentNode.removeChild(el); }, 320);
}

/**
 * Format đối tượng Date thành chuỗi 'YYYY-MM-DD'
 * @param {Date} d
 * @returns {string}
 */
function formatDateIso(d) {
  if (!d || !(d instanceof Date) || isNaN(d)) return '';
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

// ================= CONSTANTS & STATE =================

const STORAGE_KEY = 'MBC_WORK_MANAGEMENT_DATA_V2';
const DB_VERSION  = '3.7'; // Bump này khi muốn xóa cache LocalStorage & nạp lại từ database.js

let appData = {
  version: '3.7',
  currentUser: {
    id: 'admin',
    name: 'Quản trị viên (Admin)',
    role: 'admin',
    dept: 'Ban Quản Trị'
  },
  employees: [],
  tasks: [],
  holidays: [],
  projects: []
};

// View State
let viewState = {
  timeScale: 'DAY', // 'DAY', 'WEEK', 'MONTH'
  windowMode: '10', // '10', '15', 'month'
  startOffsetDate: '2026-10-01',
  filterEmp: 'ALL',
  filterMonth: '2026-10',
  filterStartDate: '',
  filterEndDate: '',
  filterYear: '2026',
  filterStatus: 'CHUA_HOAN_THANH', // Mặc định là các việc có chữ Hoàn thành sẽ không hiện ra
  filterPriority: 'ALL',
  filterSortBy: 'EMP_START',
  filterMainTask: 'ALL',
  filterKeyword: '',
  groupByParent: false
};

// ================= HÀM HỖ TRỢ XÁC ĐỊNH KHOẢNG NĂM & CÔNG VIỆC CHÍNH =================
function getTasksYearSpan() {
  // Ưu tiên khoảng lọc tự do nếu người dùng đã chọn
  if (viewState.filterStartDate && viewState.filterEndDate) {
    const fs = parseDate(viewState.filterStartDate);
    const fe = parseDate(viewState.filterEndDate);
    if (fs && fe) {
      return { minYear: fs.getFullYear(), maxYear: fe.getFullYear() };
    }
  }

  let minY = 9999;
  let maxY = 2026;
  const tasks = appData && Array.isArray(appData.tasks) ? appData.tasks : [];
  // Chỉ xét tasks theo bộ lọc nhân viên đang active
  const src = viewState.filterEmp !== 'ALL' ? tasks.filter(t => t.empId === viewState.filterEmp) : tasks;
  src.forEach(t => {
    const s = parseDate(t.startDate);
    const e = parseDate(t.actualEndDate || t.planEndDate);
    if (s) {
      minY = Math.min(minY, s.getFullYear());
      maxY = Math.max(maxY, s.getFullYear());
    }
    if (e) {
      minY = Math.min(minY, e.getFullYear());
      maxY = Math.max(maxY, e.getFullYear());
    }
  });
  if (minY === 9999) minY = 2026;
  return { minYear: minY, maxYear: Math.max(maxY, minY) };
}

/**
 * Tính khoảng tháng thực tế của danh sách task (dùng cho MONTH view).
 * Trả về { startYear, startMonth, endYear, endMonth } — chỉ trải đúng từ
 * tháng bắt đầu sớm nhất → tháng kết thúc muộn nhất trong tập task.
 */
function getTasksMonthSpan(taskList) {
  const now = new Date();
  let minDate = null;
  let maxDate = null;

  const source = (taskList && taskList.length > 0) ? taskList : (appData.tasks || []);
  source.forEach(t => {
    const s = parseDate(t.startDate);
    const e = parseDate(t.actualEndDate || t.planEndDate);
    if (s && (!minDate || s < minDate)) minDate = s;
    if (e && (!maxDate || e > maxDate)) maxDate = e;
  });

  if (!minDate) minDate = new Date(now.getFullYear(), now.getMonth(), 1);
  if (!maxDate) maxDate = new Date(now.getFullYear(), 11, 31);

  return {
    startYear:  minDate.getFullYear(),
    startMonth: minDate.getMonth() + 1,
    endYear:    maxDate.getFullYear(),
    endMonth:   maxDate.getMonth() + 1
  };
}

/**
 * Sinh mã công việc theo chuẩn CV-YYYY-XXXX.
 * Tự động tìm số thứ tự lớn nhất trong năm year để tăng dần tuần tự.
 */
function generateNextTaskId(year) {
  const y = year || new Date().getFullYear();
  const prefix = `CV-${y}-`;
  let maxNum = 0;
  (appData.tasks || []).forEach(t => {
    if (t.id && t.id.startsWith(prefix)) {
      const num = parseInt(t.id.slice(prefix.length), 10);
      if (!isNaN(num) && num > maxNum) maxNum = num;
    }
    if (t.mainTaskId && t.mainTaskId.startsWith(prefix)) {
      const num = parseInt(t.mainTaskId.slice(prefix.length), 10);
      if (!isNaN(num) && num > maxNum) maxNum = num;
    }
  });
  return `${prefix}${String(maxNum + 1).padStart(4, '0')}`;
}

/**
 * Hiển thị thời gian dự kiến linh hoạt theo đơn vị (giờ, ngày, tuần, tháng)
 */
function formatPlanDuration(task) {
  if (!task) return '1 ngày';
  if (task.planDuration && task.planUnit) {
    return `${task.planDuration} ${task.planUnit}`;
  }
  if (task.planDays) {
    return `${task.planDays} ngày`;
  }
  return '1 ngày';
}

function getMainTaskProgress(mainTaskId) {
  if (!mainTaskId || !appData || !Array.isArray(appData.tasks)) return null;
  const subtasks = appData.tasks.filter(t => t.mainTaskId === mainTaskId);
  if (subtasks.length === 0) return null;
  const completedCount = subtasks.filter(t => isTaskCompleted(t)).length;
  const totalCount = subtasks.length;
  const isAllCompleted = totalCount > 0 && completedCount === totalCount;
  return {
    mainTaskId,
    completedCount,
    totalCount,
    isAllCompleted,
    percent: Math.round((completedCount / totalCount) * 100)
  };
}

// ================= HÀM XỬ LÝ NGÀY THÁNG =================
/**
 * Chuẩn hóa linh hoạt ngày tháng từ:
 * - Excel Serial Date Number (ví dụ: 46037 -> 2026-01-15)
 * - Định dạng Việt Nam DD/MM/YYYY (ví dụ: 15/01/2026 -> 2026-01-15)
 * - Định dạng chuẩn ISO YYYY-MM-DD
 * - Đối tượng Date của Javascript
 */
function parseFlexibleDate(val) {
  if (val === null || val === undefined || val === '') return '';
  if (val instanceof Date && !isNaN(val)) {
    return formatDate(val);
  }
  const str = String(val).trim();
  // Kiểm tra nếu là số Serial của Excel (ví dụ: 46037)
  const num = Number(str);
  if (!isNaN(num) && num > 10000 && num < 90000 && !str.includes('-') && !str.includes('/')) {
    const utcDays = Math.round(num) - 25569;
    const d = new Date(utcDays * 86400 * 1000);
    const year = d.getUTCFullYear();
    const month = String(d.getUTCMonth() + 1).padStart(2, '0');
    const day = String(d.getUTCDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }
  // Kiểm tra nếu dạng DD/MM/YYYY
  if (str.includes('/')) {
    const p = str.split('/');
    if (p.length === 3) {
      const d = p[0].padStart(2, '0');
      const m = p[1].padStart(2, '0');
      const y = p[2].length === 2 ? '20' + p[2] : p[2];
      return `${y}-${m}-${d}`;
    }
  }
  // Kiểm tra nếu dạng YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(str)) {
    return str;
  }
  return str;
}

function parseDate(dStr) {
  if (!dStr) return null;
  if (dStr instanceof Date && !isNaN(dStr)) return dStr;
  const flex = parseFlexibleDate(dStr);
  if (flex && flex.includes('-')) {
    const parts = flex.split('-');
    if (parts.length === 3) {
      return new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
    }
  }
  return null;
}

function formatDate(d) {
  if (!d) return '';
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function formatVnDate(dStr) {
  if (!dStr) return '';
  const flex = parseFlexibleDate(dStr);
  if (flex && flex.includes('-')) {
    const p = flex.split('-');
    if (p.length === 3) {
      return `${p[2]}/${p[1]}/${p[0]}`;
    }
  }
  return dStr;
}

/**
 * Tự động rà soát và vá các trường ngày bị lưu sai dạng Serial Excel (như 46037)
 */
function autoFixCorruptedDates() {
  if (!appData || !Array.isArray(appData.tasks)) return;
  let changed = false;
  appData.tasks.forEach(t => {
    ['startDate', 'planEndDate', 'actualEndDate', 'lastStatusUpdate'].forEach(f => {
      if (t[f]) {
        const fixed = parseFlexibleDate(t[f]);
        if (fixed && fixed !== t[f] && /^\d{4}-\d{2}-\d{2}$/.test(fixed)) {
          t[f] = fixed;
          changed = true;
        }
      }
    });
  });
  if (changed) {
    saveDataToStorage();
  }
}

function addDays(d, n) {
  const res = new Date(d);
  res.setDate(res.getDate() + n);
  return res;
}

function dateDiffInDays(d1, d2) {
  const dt1 = new Date(d1.getFullYear(), d1.getMonth(), d1.getDate());
  const dt2 = new Date(d2.getFullYear(), d2.getMonth(), d2.getDate());
  const diffTime = dt2 - dt1;
  return Math.round(diffTime / (1000 * 60 * 60 * 24));
}

// Kiểm tra ngày có thuộc Lịch nghỉ đặc biệt / Ngày lễ không
function getHolidayInfo(d) {
  if (!d || !appData || !Array.isArray(appData.holidays)) return null;
  const dStr = formatDate(d);
  return appData.holidays.find(h => h.date === dStr) || null;
}

// Lấy ngày hiện tại chuẩn hệ thống
function getSystemToday() {
  const realNow = new Date();
  return (realNow.getFullYear() === 2026)
    ? new Date(realNow.getFullYear(), realNow.getMonth(), realNow.getDate())
    : new Date(2026, 9, 7);
}

/**
 * Xác định trạng thái thực tế chuẩn xác của công việc (Chuẩn hóa toàn diện):
 * 1. 'Tạm dừng': nếu task ở trạng thái Tạm dừng / Dừng dự án
 * 2. 'Hoàn thành' hoặc 'Hoàn thành trễ':
 *    - Nếu task.status là 'Hoàn thành':
 *      + Nếu có actualEndDate > planEndDate: 'Hoàn thành trễ'
 *      + Ngược lại: luôn là 'Hoàn thành' (đúng hạn theo kỳ hạn kế hoạch)
 *    - Nếu có ngày hoàn thành thực tế (actualEndDate):
 *      + actualEndDate <= planEndDate: 'Hoàn thành'
 *      + actualEndDate > planEndDate:  'Hoàn thành trễ'
 * 3. Nếu chưa hoàn thành (Đang thực hiện):
 *    - Nếu today > planEndDate: 'Đang làm (Trễ hạn)' (vẫn là đang thực hiện nhưng cảnh báo trễ tiến độ)
 *    - Nếu today <= planEndDate: 'Đang làm'
 */
function getTaskEffectiveStatus(task, refToday = null) {
  if (!task) return 'Đang làm';
  const raw = (task.status || '').trim();
  if (raw === 'Tạm dừng' || raw === 'Tam dung' || raw === 'Dừng dự án' || raw === 'Dung du an') {
    return 'Tạm dừng';
  }

  // Kiểm tra ngày hoàn thành thực tế
  const actualStr = task.actualEndDate ? String(task.actualEndDate).trim() : '';
  const aEnd = (actualStr && actualStr !== 'Chưa hoàn thành') ? parseDate(actualStr) : null;
  const pEnd = parseDate(task.planEndDate);

  // 1. Trường hợp người dùng hoặc dữ liệu đã ghi nhận là "Hoàn thành"
  if (raw === 'Hoàn thành' || raw === 'Hoan thanh') {
    if (aEnd && pEnd && aEnd > pEnd) {
      return 'Hoàn thành trễ';
    }
    return 'Hoàn thành';
  }

  // 2. Trường hợp có ngày hoàn thành thực tế hợp lệ
  if (aEnd) {
    if (pEnd && aEnd > pEnd) {
      return 'Hoàn thành trễ';
    }
    return 'Hoàn thành';
  }

  // 3. Trường hợp công việc đang thực hiện
  const today = refToday || getSystemToday();
  if (pEnd && today > pEnd) {
    return 'Đang làm (Trễ hạn)';
  }
  return 'Đang làm';
}

function isTaskCompleted(task) {
  const st = getTaskEffectiveStatus(task);
  return st === 'Hoàn thành' || st === 'Hoàn thành trễ';
}

function isTaskOverdue(task, refToday = null) {
  if (isTaskCompleted(task)) return false;
  const raw = (task.status || '').trim();
  if (raw === 'Tạm dừng' || raw === 'Tam dung' || raw === 'Dừng dự án') return false;
  const pEnd = parseDate(task.planEndDate);
  const today = refToday || getSystemToday();
  return !!(pEnd && today > pEnd);
}

// Hàm lọc nhanh theo nguồn yêu cầu (Tổng Giám đốc, Giám đốc, Trưởng phòng, Cải tiến, v.v.)
function filterByPriority(priorityVal) {
  if (!priorityVal) return;
  const sel = document.getElementById('filterPriority');
  if (viewState.filterPriority === priorityVal) {
    viewState.filterPriority = 'ALL';
    showToast('Đã hủy lọc theo nguồn yêu cầu (Xem tất cả)', 'info');
  } else {
    viewState.filterPriority = priorityVal;
    showToast(`Đang lọc nguồn yêu cầu: ${priorityVal}`, 'info');
  }
  if (sel) sel.value = viewState.filterPriority;
  applyFilters();
}

// Huy hiệu màu sắc theo nguồn yêu cầu (Tổng Giám đốc, Giám đốc, Trưởng phòng, Đối ứng, Cải tiến, Khác)
// Cho phép click để lọc nhanh theo nguồn yêu cầu tương ứng
function getSourceBadge(source) {
  if (!source) return '';
  const s = source.trim();
  if (s.includes('Tổng Giám đốc') || s.includes('Tong Giam doc') || s.includes('TGĐ') || s.includes('TGD')) {
    return '<button type="button" onclick="filterByPriority(\'Tổng Giám đốc\')" class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-black bg-rose-900 text-amber-300 border border-amber-400 shadow-sm hover:brightness-110 cursor-pointer transition select-none" title="Nhấn để lọc các việc có chỉ đạo từ: Tổng Giám đốc"><i class="fa-solid fa-crown text-[8px] text-amber-400"></i> TGĐ</button>';
  } else if (s.includes('Giám đốc') || s.includes('Giam doc')) {
    return '<button type="button" onclick="filterByPriority(\'Giám đốc\')" class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-purple-100 text-purple-800 border border-purple-300 shadow-sm hover:bg-purple-200 cursor-pointer transition select-none" title="Nhấn để lọc các việc theo yêu cầu: Giám đốc"><i class="fa-solid fa-crown text-[8px] text-purple-600"></i> Giám đốc</button>';
  } else if (s.includes('Trưởng phòng') || s.includes('Truong phong')) {
    return '<button type="button" onclick="filterByPriority(\'Trưởng phòng\')" class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-blue-100 text-blue-800 border border-blue-300 shadow-sm hover:bg-blue-200 cursor-pointer transition select-none" title="Nhấn để lọc các việc theo yêu cầu: Trưởng phòng"><i class="fa-solid fa-user-tie text-[8px] text-blue-600"></i> Trưởng phòng</button>';
  } else if (s.includes('Đối ứng')) {
    return '<button type="button" onclick="filterByPriority(\'Đối ứng\')" class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-100 text-amber-800 border border-amber-300 shadow-sm hover:bg-amber-200 cursor-pointer transition select-none" title="Nhấn để lọc các việc: Đối ứng sự cố"><i class="fa-solid fa-bolt text-[8px] text-amber-600"></i> Đối ứng</button>';
  } else if (s.includes('Cải thiện') || s.includes('Cải tiến')) {
    return '<button type="button" onclick="filterByPriority(\'Cải tiến\')" class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-sm hover:bg-emerald-200 cursor-pointer transition select-none" title="Nhấn để lọc các việc: Cải tiến / Cải thiện nội bộ"><i class="fa-solid fa-arrow-trend-up text-[8px] text-emerald-600"></i> Cải tiến</button>';
  } else if (s.includes('Chiến lược')) {
    return '<button type="button" onclick="filterByPriority(\'Chiến lược\')" class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-rose-100 text-rose-800 border border-rose-300 shadow-sm hover:bg-rose-200 cursor-pointer transition select-none" title="Nhấn để lọc các việc: Dự án chiến lược"><i class="fa-solid fa-chess text-[8px] text-rose-600"></i> Chiến lược</button>';
  } else {
    const escaped = s.replace(/'/g, "\\'");
    return `<button type="button" onclick="filterByPriority('${escaped}')" class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-medium bg-slate-100 text-slate-700 border border-slate-300 hover:bg-slate-200 cursor-pointer transition select-none" title="Nhấn để lọc theo: ${s}">${s}</button>`;
  }
}

// ================= LƯU TRỮ LOCALSTORAGE & NẠP DỮ LIỆU BAN ĐẦU =================
// ================= LƯU TRỮ LOCALSTORAGE & NẠP DỮ LIỆU BAN ĐẦU =================
async function loadInitialData() {
  // LỚP 1: Đọc LocalStorage hiện tại của trình duyệt/profile này
  let localData = null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.employees) && Array.isArray(parsed.tasks)) {
        localData = parsed;
      }
    }
  } catch (err) {
    console.warn('[MBC Data] Lỗi đọc LocalStorage:', err);
  }

  // LỚP 2: Đọc CSDL tập trung từ Python Helper (/api/data) trên ổ đĩa
  let diskData = null;
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2000);
    const res = await fetch('http://127.0.0.1:38271/api/data', { signal: controller.signal });
    clearTimeout(timeoutId);
    if (res.ok) {
      const json = await res.json();
      if (json && json.exists !== false && Array.isArray(json.tasks) && Array.isArray(json.employees)) {
        diskData = json;
      }
    }
  } catch(e) {
    console.log('[MBC Data] Chưa kết nối được Python Helper API /api/data:', e);
  }

  // SO SÁNH & ĐỒNG BỘ BẢO TOÀN DỮ LIỆU (KHÔNG BAO GIỜ LÀM MẤT DỮ LIỆU CỦA USER):
  if (localData && (!diskData || localData.employees.length > diskData.employees.length || localData.tasks.length > diskData.tasks.length)) {
    // Profile hiện tại (gms00-09) có dữ liệu thực tế lớn hơn -> đồng bộ ngay lên file database.json
    appData = localData;
    _syncDataToLocalDisk(appData);
    console.log(`[MBC Data] Ưu tiên dữ liệu từ Profile (${appData.employees.length} NV, ${appData.tasks.length} CV) và đã ghi vào database.json`);
  } else if (diskData && diskData.tasks && diskData.tasks.length > 0) {
    // File database.json trên máy có dữ liệu đầy đủ dùng chung -> nạp cho profile này
    appData = diskData;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(appData));
    console.log(`[MBC Data] Nạp thành công CSDL dùng chung từ ổ đĩa: ${appData.tasks.length} CV, ${appData.employees.length} NV`);
  } else if (localData && localData.tasks && localData.tasks.length > 0) {
    appData = localData;
    _syncDataToLocalDisk(appData);
  } else if (typeof window !== 'undefined' && window.MBC_DEFAULT_DATABASE && Array.isArray(window.MBC_DEFAULT_DATABASE.tasks)) {
    appData = JSON.parse(JSON.stringify(window.MBC_DEFAULT_DATABASE));
    _syncDataToLocalDisk(appData);
  }

  if (!appData.holidays || !Array.isArray(appData.holidays) || appData.holidays.length === 0) {
    if (window.MBC_DEFAULT_DATABASE && Array.isArray(window.MBC_DEFAULT_DATABASE.holidays)) {
      appData.holidays = JSON.parse(JSON.stringify(window.MBC_DEFAULT_DATABASE.holidays));
    }
  }

  autoFixCorruptedDates();
  normalizeTaskStatuses();
}

function normalizeTaskStatuses() {
  if (!appData || !Array.isArray(appData.tasks)) return;
  appData.tasks.forEach(t => {
    if (!t.status) return;
    const s = t.status.trim();
    if (s === 'Dang lam') t.status = 'Đang làm';
    else if (s === 'Tam dung' || s === 'Dung du an') t.status = 'Tạm dừng';
    else if (s === 'Hoan thanh') t.status = 'Hoàn thành';
    else if (s === 'Hoan thanh tre') t.status = 'Hoàn thành trễ';
  });
}

function saveDataToStorage() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(appData));
    renderFilterMainTasksSelect();
  } catch (err) {
    console.error('Lỗi lưu LocalStorage:', err);
  }
  // Đồng bộ thẳng vào file database.json trên ổ đĩa máy tính
  _syncDataToLocalDisk(appData);
}

function _syncDataToLocalDisk(data) {
  if (!data || !Array.isArray(data.tasks)) return;
  fetch('http://127.0.0.1:38271/api/data', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  })
  .then(res => res.json())
  .then(resData => {
    if (resData && resData.success) {
      console.log(`[MBC Data] Đã lưu thành công vào database.json (${resData.taskCount} CV, ${resData.empCount} NV) lúc ${resData.savedAt}`);
    }
  })
  .catch(err => {
    console.warn('[MBC Data] File helper không ghi được database.json:', err);
  });
}

// ================= ADMIN MENU (Quản Trị CSDL Dropdown) =================
function toggleAdminMenu() {
  const dd = document.getElementById('adminMenuDropdown');
  if (!dd) return;
  dd.classList.toggle('hidden');
  // Đóng menu user nếu đang mở
  const ud = document.getElementById('userDropdown');
  if (ud && !ud.classList.contains('hidden')) ud.classList.add('hidden');
}

function closeAdminMenu() {
  const dd = document.getElementById('adminMenuDropdown');
  if (dd) dd.classList.add('hidden');
}

// Đóng menu khi click ra ngoài
document.addEventListener('click', function(e) {
  const wrapper = document.getElementById('adminMenuWrapper');
  if (wrapper && !wrapper.contains(e.target)) {
    closeAdminMenu();
  }
});

// Kiểm tra trạng thái Helper và cập nhật chấm màu header
function updateHelperStatusUI(isOnline) {
  const dot = document.getElementById('helperStatusDot');
  const dotMenu = document.getElementById('helperStatusDotMenu');
  const label = document.getElementById('helperStatusLabel');
  if (dot) dot.style.backgroundColor = isOnline ? '#22c55e' : '#94a3b8';
  if (dotMenu) dotMenu.style.backgroundColor = isOnline ? '#22c55e' : '#94a3b8';
  if (label) {
    label.textContent = isOnline
      ? '🟢 File Helper đang chạy — Mở file trực tiếp'
      : '⚪ File Helper chưa bật — Cần chạy Chay_Ung_Dung_MBC.vbs';
    label.style.color = isOnline ? '#16a34a' : '#94a3b8';
  }
}

function checkHelperStatus() {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 1500);
  fetch('http://127.0.0.1:38271/ping', { signal: ctrl.signal })
    .then(r => r.json())
    .then(d => { clearTimeout(t); updateHelperStatusUI(!!(d && d.pong)); })
    .catch(() => { clearTimeout(t); updateHelperStatusUI(false); });
}

// Kiểm tra ngay khi trang tải và mỗi 15 giây
setTimeout(checkHelperStatus, 800);
setInterval(checkHelperStatus, 15000);


// ================= TÍNH TOÁN ĐIỂM HIỆU SUẤT (PERFORMANCE POINTS) =================
function calculateTaskScoreImpact(task) {
  const planDays = Math.max(1, parseInt(task.planDays) || 1);
  const planEnd = parseDate(task.planEndDate);
  if (!planEnd) return { delta: 0, reason: 'Chưa đủ dữ liệu' };

  const isCompleted = task.status === 'Hoàn thành' || task.status === 'Hoàn thành trễ';
  let actualEnd = null;

  if (isCompleted) {
    actualEnd = parseDate(task.actualEndDate) || planEnd;
  } else {
    const today = new Date(2026, 9, 5);
    if (today > planEnd) {
      actualEnd = today;
    } else {
      return { delta: 0, reason: 'Đang làm trong hạn' };
    }
  }

  const delayDays = dateDiffInDays(planEnd, actualEnd);

  if (delayDays <= 0) {
    if (isCompleted) {
      return { delta: +3, reason: 'Hoàn thành đúng hạn (+3đ)' };
    } else {
      return { delta: 0, reason: 'Đang làm trong hạn' };
    }
  }

  if (delayDays >= 30) {
    const months = Math.floor(delayDays / 30);
    const penalty = -(months * 9);
    return { delta: penalty, reason: `Trễ ${delayDays} ngày (> ${months} tháng): ${penalty}đ` };
  } else {
    const ratio = delayDays / planDays;
    if (ratio <= 0.5) {
      return { delta: -1, reason: `Trễ ${delayDays} ngày (<= 50% dự kiến): -1đ` };
    } else if (ratio <= 1.0) {
      return { delta: -2, reason: `Trễ ${delayDays} ngày (<= 100% dự kiến): -2đ` };
    } else {
      return { delta: -3, reason: `Trễ ${delayDays} ngày (> 100% dự kiến): -3đ` };
    }
  }
}

function calculateEmployeeMonthlyScores(empId, year) {
  const monthlyScores = {};
  for (let m = 1; m <= 12; m++) {
    monthlyScores[m] = 100;
  }

  const empTasks = appData.tasks.filter(t => t.empId === empId);

  empTasks.forEach(task => {
    if (!task.startDate) return;
    const d = parseDate(task.startDate);
    if (d && d.getFullYear() === year) {
      const m = d.getMonth() + 1;
      const impact = calculateTaskScoreImpact(task);
      monthlyScores[m] += impact.delta;
    }
  });

  return monthlyScores;
}

// ================= PHÂN QUYỀN VÀ TÀI KHOẢN (AUTH & ROLES) =================
function renderUserDropdown() {
  const container = document.getElementById('userListDropdown');
  if (!container) return;

  let html = `
    <button onclick="switchUser('admin')" class="w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-100 transition ${appData.currentUser.role === 'admin' ? 'bg-sky-50 font-bold text-sky-800' : 'text-slate-700'}">
      <div class="flex items-center gap-2">
        <span class="w-6 h-6 rounded-full bg-brand-700 text-white flex items-center justify-center text-[10px] font-bold">AD</span>
        <div>
          <div class="font-bold">Quản trị viên (Admin)</div>
          <div class="text-[10px] text-slate-400">Toàn quyền hệ thống</div>
        </div>
      </div>
      ${appData.currentUser.role === 'admin' ? '<i class="fa-solid fa-check text-sky-600"></i>' : ''}
    </button>
    <div class="my-1 border-t border-slate-100"></div>
  `;

  appData.employees.forEach(emp => {
    const isCurrent = appData.currentUser.role === 'employee' && appData.currentUser.id === emp.id;
    const initials = emp.name.split(' ').map(n => n[0]).slice(-2).join('').toUpperCase();
    html += `
      <button onclick="switchUser('${emp.id}')" class="w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-100 transition ${isCurrent ? 'bg-sky-50 font-bold text-sky-800' : 'text-slate-700'}">
        <div class="flex items-center gap-2">
          <span class="w-6 h-6 rounded-full bg-slate-600 text-white flex items-center justify-center text-[10px] font-bold">${initials}</span>
          <div>
            <div class="font-medium">${emp.name} <span class="text-[10px] text-slate-400">(${emp.id})</span></div>
            <div class="text-[10px] text-slate-400">${emp.dept || 'Nhân viên'}</div>
          </div>
        </div>
        ${isCurrent ? '<i class="fa-solid fa-check text-sky-600"></i>' : ''}
      </button>
    `;
  });

  container.innerHTML = html;
}

function switchUser(userId) {
  if (userId === 'admin') {
    appData.currentUser = {
      id: 'admin',
      name: 'Quản trị viên (Admin)',
      role: 'admin',
      dept: 'Ban Quản Trị'
    };
  } else {
    const emp = appData.employees.find(e => e.id === userId);
    if (emp) {
      appData.currentUser = {
        id: emp.id,
        name: emp.name,
        role: 'employee',
        dept: emp.dept
      };
      viewState.filterEmp = emp.id;
      document.getElementById('filterEmployee').value = emp.id;
    }
  }

  saveDataToStorage();
  updateAuthUI();
  closeUserDropdown();
  applyFilters();
}

function updateAuthUI() {
  const user = appData.currentUser;
  const avatarEl = document.getElementById('currentUserAvatar');
  const nameEl = document.getElementById('currentUserName');
  const roleEl = document.getElementById('currentUserRole');
  const btnAddTask = document.getElementById('btnAddTask');
  const btnManageEmp = document.getElementById('btnManageEmp');

  if (user.role === 'admin') {
    if (avatarEl) { avatarEl.innerText = 'AD'; avatarEl.className = 'w-7 h-7 rounded-full bg-brand-700 text-white flex items-center justify-center font-bold text-xs'; }
    if (nameEl) nameEl.innerText = user.name;
    if (roleEl) { roleEl.innerText = 'Admin - Toàn quyền'; roleEl.className = 'text-[10px] text-emerald-600 font-semibold uppercase tracking-wider'; }
    if (btnAddTask) btnAddTask.style.display = 'inline-flex';
    if (btnManageEmp) btnManageEmp.style.display = 'inline-flex';
  } else {
    const initials = user.name.split(' ').map(n => n[0]).slice(-2).join('').toUpperCase();
    if (avatarEl) { avatarEl.innerText = initials; avatarEl.className = 'w-7 h-7 rounded-full bg-slate-600 text-white flex items-center justify-center font-bold text-xs'; }
    if (nameEl) nameEl.innerText = `${user.name} (${user.id})`;
    if (roleEl) { roleEl.innerText = `Nhân viên - ${user.dept}`; roleEl.className = 'text-[10px] text-sky-600 font-semibold uppercase tracking-wider'; }
    if (btnAddTask) btnAddTask.style.display = 'none';
    if (btnManageEmp) btnManageEmp.style.display = 'none';
  }
}

function toggleUserDropdown() {
  const el = document.getElementById('userDropdown');
  el.classList.toggle('hidden');
  renderUserDropdown();
}

function closeUserDropdown() {
  const el = document.getElementById('userDropdown');
  if (el) el.classList.add('hidden');
}

// ================= BỐ TRÍ & SẮP XẾP CÔNG VIỆC THEO NHIỀU TIÊU CHÍ =================
function groupAndSortTasks(taskList) {
  if (!taskList || taskList.length === 0) return [];

  const sortBy = viewState.filterSortBy || (document.getElementById('filterSortBy') ? document.getElementById('filterSortBy').value : 'EMP_START');

  // 1. Thứ tự mã việc (Mã CV tăng dần)
  if (sortBy === 'TASK_ID') {
    return [...taskList].sort((a, b) => (a.id || '').localeCompare(b.id || '', undefined, { numeric: true, sensitivity: 'base' }));
  }

  // 2. Ngày bắt đầu (Sớm nhất trước)
  if (sortBy === 'START_DATE') {
    return [...taskList].sort((a, b) => {
      const da = parseDate(a.startDate) || new Date(0);
      const db = parseDate(b.startDate) || new Date(0);
      if (da.getTime() !== db.getTime()) return da.getTime() - db.getTime();
      return (a.id || '').localeCompare(b.id || '');
    });
  }

  // 3. Hạn hoàn thành / Deadline (Deadline gấp nhất lên trước)
  if (sortBy === 'DEADLINE') {
    return [...taskList].sort((a, b) => {
      const da = parseDate(a.planEndDate) || new Date(9999, 0, 1);
      const db = parseDate(b.planEndDate) || new Date(9999, 0, 1);
      if (da.getTime() !== db.getTime()) return da.getTime() - db.getTime();
      return (a.id || '').localeCompare(b.id || '');
    });
  }

  // 4. Mức độ ưu tiên (Giám đốc ➔ Trưởng phòng ➔ Đối ứng ➔ Cải tiến ➔ Chiến lược ➔ Khác)
  if (sortBy === 'PRIORITY') {
    const getPriorityWeight = (src) => {
      if (!src) return 99;
      const s = src.toLowerCase();
      if (s.includes('tổng giám đốc') || s.includes('tgđ') || s.includes('tgd')) return 0;
      if (s.includes('giám đốc')) return 1;
      if (s.includes('trưởng phòng')) return 2;
      if (s.includes('đối ứng')) return 3;
      if (s.includes('cải tiến') || s.includes('cải thiện')) return 4;
      if (s.includes('chiến lược')) return 5;
      return 6;
    };
    return [...taskList].sort((a, b) => {
      const wa = getPriorityWeight(a.taskSource);
      const wb = getPriorityWeight(b.taskSource);
      if (wa !== wb) return wa - wb;
      const da = parseDate(a.startDate) || new Date(0);
      const db = parseDate(b.startDate) || new Date(0);
      return da.getTime() - db.getTime();
    });
  }

  // 5. Quá hạn / Cần cập nhật tình trạng lên đầu
  if (sortBy === 'OVERDUE') {
    const systemToday = new Date(2026, 9, 7);
    const getOverdueScore = (task) => {
      const isCompleted = task.status === 'Hoàn thành' || task.status === 'Hoàn thành trễ' || !!task.actualEndDate;
      const isPaused = task.status === 'Tạm dừng' || task.status === 'Dừng dự án';
      if (isCompleted) return 100;
      if (isPaused) return 80;
      const pEnd = parseDate(task.planEndDate);
      const isOverdue = pEnd && systemToday > pEnd;
      const lastUpdate = parseDate(task.lastStatusUpdate || task.startDate);
      const daysSinceUpdate = lastUpdate ? Math.floor((systemToday - lastUpdate) / (1000 * 60 * 60 * 24)) : 3;
      const needUpdate = daysSinceUpdate >= 3;
      if (isOverdue && needUpdate) return 1;
      if (isOverdue) return 2;
      if (needUpdate) return 3;
      return 10;
    };
    return [...taskList].sort((a, b) => {
      const sa = getOverdueScore(a);
      const sb = getOverdueScore(b);
      if (sa !== sb) return sa - sb;
      const da = parseDate(a.planEndDate) || new Date(9999, 0, 1);
      const db = parseDate(b.planEndDate) || new Date(9999, 0, 1);
      return da.getTime() - db.getTime();
    });
  }

  // 6. MẶC ĐỊNH (EMP_START): Gom nhóm tổng thể theo Người (empId), trong mỗi người sắp xếp theo Ngày nhận việc (startDate) tăng dần
  const empOrder = [];
  const empMap = new Map();

  // Khởi tạo thứ tự nhân sự theo appData.employees để giữ thứ tự chuẩn ban đầu
  if (appData && Array.isArray(appData.employees)) {
    appData.employees.forEach(emp => {
      empMap.set(emp.id, []);
      empOrder.push(emp.id);
    });
  }

  // Phân loại task vào từng người
  taskList.forEach(task => {
    const empKey = task.empId || 'UNASSIGNED';
    if (!empMap.has(empKey)) {
      empMap.set(empKey, []);
      empOrder.push(empKey);
    }
    empMap.get(empKey).push(task);
  });

  const sortedTasks = [];
  empOrder.forEach(empId => {
    const tasks = empMap.get(empId) || [];
    if (tasks.length === 0) return;
    // Với mỗi người: sắp xếp theo Ngày nhận việc (startDate) tăng dần, sau đó theo ID
    tasks.sort((a, b) => {
      const da = parseDate(a.startDate) || new Date(0);
      const db = parseDate(b.startDate) || new Date(0);
      if (da.getTime() !== db.getTime()) return da.getTime() - db.getTime();
      return (a.id || '').localeCompare(b.id || '');
    });
    sortedTasks.push(...tasks);
  });

  return sortedTasks;
}

// Tự động thu phóng Timeline vừa vặn ngày đầu đến đúng hạn cuối công việc (Không thừa, không kẹt 365 ngày)
function fitTimelineToTaskDates() {
  const currentTasks = appData.tasks.filter(t => {
    if (appData.currentUser.role === 'employee' && t.empId !== appData.currentUser.id) return false;
    if (viewState.filterEmp !== 'ALL' && t.empId !== viewState.filterEmp) return false;
    if (viewState.filterMainTask && viewState.filterMainTask !== 'ALL') {
      if (viewState.filterMainTask === '__NO_PROJECT__') {
        if (t.mainTaskId && t.mainTaskId.trim()) return false;
      } else {
        const mId = viewState.filterMainTask.toLowerCase();
        const taskMain = (t.mainTaskId || '').toLowerCase();
        const taskTitle = (t.mainTaskTitle || t.title || '').toLowerCase();
        if (taskMain !== mId && taskTitle !== mId && (t.id || '').toLowerCase() !== mId) return false;
      }
    }
    return true;
  });

  if (currentTasks.length === 0) {
    alert('Không có công việc nào để tính toán khung thời gian!');
    return;
  }

  let minStart = null;
  let maxEnd = null;

  currentTasks.forEach(t => {
    const s = parseDate(t.startDate);
    const e = parseDate(t.actualEndDate || t.planEndDate);
    if (s && (!minStart || s < minStart)) minStart = s;
    if (e && (!maxEnd || e > maxEnd)) maxEnd = e;
  });

  if (!minStart || !maxEnd) {
    alert('Các công việc chưa có đủ ngày bắt đầu và kết thúc!');
    return;
  }

  const sStr = formatDateIso(minStart);
  const eStr = formatDateIso(maxEnd);

  viewState.filterStartDate = sStr;
  viewState.filterEndDate = eStr;

  const inputStart = document.getElementById('filterStartDate');
  const inputEnd = document.getElementById('filterEndDate');
  if (inputStart) inputStart.value = sStr;
  if (inputEnd) inputEnd.value = eStr;

  viewState.timeScale = 'DAY';
  updateTimeScaleButtons('DAY');
  applyFilters();
}

// Bật/tắt nhanh trạng thái Tạm dừng cho công việc
function toggleTaskPause(taskId) {
  const task = appData.tasks.find(t => t.id === taskId);
  if (!task) return;
  if (task.status === 'Tạm dừng' || task.status === 'Dừng dự án') {
    task.status = 'Đang làm';
  } else {
    task.status = 'Tạm dừng';
  }
  saveDataToStorage();
  applyFilters();
}

// ================= TIMELINE BUILDER: GIỜ, NGÀY, TUẦN, THÁNG, NĂM =================
function getTimelineColumns(taskList) {
  const cols = [];

  // Tìm ngày bắt đầu sớm nhất trong danh sách công việc hiển thị (để mở rộng gốc timeline nếu có việc tồn đọng từ tháng trước)
  const sourceTasks = Array.isArray(taskList) ? taskList : (appData.tasks || []);
  let minTaskStart = null;
  sourceTasks.forEach(t => {
    const s = parseDate(t.startDate);
    if (s && (!minTaskStart || s < minTaskStart)) {
      minTaskStart = s;
    }
  });

  if (viewState.timeScale === 'HOUR') {
    // Chế độ xem theo Giờ: Các mốc giờ từ 07:00 đến 19:00 trong ngày
    const baseDate = parseDate(viewState.filterStartDate || viewState.startOffsetDate) || new Date(2026, 9, 1);
    const y = baseDate.getFullYear();
    const m = baseDate.getMonth();
    const d = baseDate.getDate();

    for (let h = 7; h <= 19; h++) {
      const hStr = `${String(h).padStart(2, '0')}:00`;
      const sH = new Date(y, m, d, h, 0, 0);
      const eH = new Date(y, m, d, h, 59, 59);
      cols.push({
        type: 'HOUR',
        label: hStr,
        subLabel: `${String(d).padStart(2, '0')}/${String(m + 1).padStart(2, '0')}`,
        startDate: sH,
        endDate: eH,
        isWeekend: baseDate.getDay() === 0 || baseDate.getDay() === 6
      });
    }
  } else if (viewState.timeScale === 'YEAR') {
    // Chế độ xem theo Năm: các năm từ minYear đến maxYear của dữ liệu
    const { minYear, maxYear } = getTasksYearSpan();
    for (let y = minYear; y <= maxYear; y++) {
      cols.push({
        type: 'YEAR',
        year: y,
        label: `Năm ${y}`,
        subLabel: '12 Tháng',
        startDate: new Date(y, 0, 1),
        endDate: new Date(y, 11, 31, 23, 59, 59)
      });
    }
  } else if (viewState.timeScale === 'MONTH') {
    // Chế độ xem theo Tháng: Chỉ hiện từ tháng bắt đầu sớm nhất đến tháng kết thúc muộn nhất của dữ liệu
    // Nếu có lọc theo khoảng ngày tự do thì ưu tiên khoảng đó
    let mStart, mEnd;
    if (viewState.filterStartDate && viewState.filterEndDate) {
      const fs = parseDate(viewState.filterStartDate);
      const fe = parseDate(viewState.filterEndDate);
      mStart = { y: fs.getFullYear(), m: fs.getMonth() + 1 };
      mEnd   = { y: fe.getFullYear(), m: fe.getMonth() + 1 };
    } else {
      // Lọc task hiện tại theo emp nếu đang filter
      let srcTasks = sourceTasks.length > 0 ? sourceTasks : (appData.tasks || []);
      if (viewState.filterEmp !== 'ALL') srcTasks = srcTasks.filter(t => t.empId === viewState.filterEmp);
      const span = getTasksMonthSpan(srcTasks);
      mStart = { y: span.startYear, m: span.startMonth };
      mEnd   = { y: span.endYear,   m: span.endMonth   };
    }

    let cy = mStart.y, cm = mStart.m;
    while (cy < mEnd.y || (cy === mEnd.y && cm <= mEnd.m)) {
      cols.push({
        type: 'MONTH',
        year: cy,
        month: cm,
        label: `T${cm}/${cy.toString().slice(-2)}`,
        subLabel: `${cy}`,
        startDate: new Date(cy, cm - 1, 1),
        endDate: new Date(cy, cm, 0, 23, 59, 59)
      });
      cm++;
      if (cm > 12) { cm = 1; cy++; }
    }
  } else if (viewState.timeScale === 'WEEK') {
    // Chế độ xem theo Tuần:
    let defaultBase = parseDate(viewState.filterMonth ? `${viewState.filterMonth}-01` : viewState.startOffsetDate) || new Date(2026, 9, 1);
    // NGUYÊN TẮC: Nếu trong tháng còn việc chưa xong nhưng ngày bắt đầu từ tháng trước (ví dụ tháng 9),
    // biểu đồ tự động mở rộng từ gốc tháng bắt đầu của việc đó để thấy trọn vẹn cả kế hoạch và thời gian bắt đầu!
    if (minTaskStart && minTaskStart < defaultBase) {
      defaultBase = new Date(minTaskStart.getFullYear(), minTaskStart.getMonth(), 1);
    }
    const baseDate = defaultBase;
    const totalWeeks = 14;

    let currentMonth = null;
    let weekIndexInMonth = 0;

    for (let w = 0; w < totalWeeks; w++) {
      const wStart = addDays(baseDate, w * 7);
      const wEnd = addDays(wStart, 6);

      const m = wStart.getMonth() + 1;
      if (m !== currentMonth) {
        currentMonth = m;
        weekIndexInMonth = 1;
      } else {
        weekIndexInMonth++;
      }

      cols.push({
        type: 'WEEK',
        label: `Tuần ${weekIndexInMonth} (T${m})`,
        monthIndex: m,
        weekInMonth: weekIndexInMonth,
        subLabel: `${wStart.getDate()}/${wStart.getMonth()+1} - ${wEnd.getDate()}/${wEnd.getMonth()+1}/${wEnd.getFullYear().toString().slice(-2)}`,
        startDate: wStart,
        endDate: wEnd
      });
    }
  } else {
    // Chế độ xem theo Ngày (mặc định hoặc khoảng ngày tự do)
    const dayNames = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];

    // Nếu người dùng chọn khoảng ngày tự do Từ ngày -> Đến ngày (Không giới hạn cứng 365 ngày)
    if (viewState.filterStartDate && viewState.filterEndDate) {
      const sDate = parseDate(viewState.filterStartDate);
      const eDate = parseDate(viewState.filterEndDate);
      if (sDate && eDate && sDate <= eDate) {
        const totalDays = dateDiffInDays(sDate, eDate) + 1;
        for (let i = 0; i < totalDays; i++) {
          const d = addDays(sDate, i);
          const isWeekend = d.getDay() === 0 || d.getDay() === 6;
          const hol = getHolidayInfo(d);
          cols.push({
            type: 'DAY',
            date: d,
            label: `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`,
            subLabel: dayNames[d.getDay()],
            yearLabel: d.getFullYear(),
            isWeekend,
            isHoliday: !!hol,
            holidayType: hol ? hol.type : null,
            holidayName: hol ? hol.name : '',
            startDate: d,
            endDate: d
          });
        }
        return cols;
      }
    }

    // Nếu xem theo khung ngày chuẩn (10 ngày, 15 ngày, hoặc cả tháng)
    let defaultBase = parseDate(viewState.filterMonth ? `${viewState.filterMonth}-01` : viewState.startOffsetDate) || new Date(2026, 9, 1);
    if (minTaskStart && minTaskStart < defaultBase) {
      defaultBase = new Date(minTaskStart.getFullYear(), minTaskStart.getMonth(), 1);
    }
    const baseDate = defaultBase;

    let totalDays = 10;
    if (viewState.windowMode === '10') totalDays = 10;
    else if (viewState.windowMode === '15') totalDays = 15;
    else if (viewState.windowMode === 'month') {
      let endMonthDate;
      if (viewState.filterMonth) {
        const [fmY, fmM] = viewState.filterMonth.split('-').map(Number);
        endMonthDate = new Date(fmY, fmM, 0);
      } else {
        const y = baseDate.getFullYear();
        const m = baseDate.getMonth();
        endMonthDate = new Date(y, m + 1, 0);
      }
      totalDays = Math.max(1, dateDiffInDays(baseDate, endMonthDate) + 1);
    }

    for (let i = 0; i < totalDays; i++) {
      const d = addDays(baseDate, i);
      const isWeekend = d.getDay() === 0 || d.getDay() === 6;
      const hol = getHolidayInfo(d);
      cols.push({
        type: 'DAY',
        date: d,
        label: `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}`,
        subLabel: dayNames[d.getDay()],
        yearLabel: d.getFullYear(),
        isWeekend,
        isHoliday: !!hol,
        holidayType: hol ? hol.type : null,
        holidayName: hol ? hol.name : '',
        startDate: d,
        endDate: d
      });
    }
  }

  return cols;
}

// Cập nhật giao diện các nút chọn đơn vị thời gian
function updateTimeScaleButtons(scale) {
  const btnHour = document.getElementById('btnScaleHour');
  const btnDay = document.getElementById('btnScaleDay');
  const btnWeek = document.getElementById('btnScaleWeek');
  const btnMonth = document.getElementById('btnScaleMonth');
  const btnYear = document.getElementById('btnScaleYear');
  const dayWindowControls = document.getElementById('dayWindowControls');

  const normalClass = 'px-2 py-1 rounded font-semibold text-slate-600 hover:bg-white text-xs transition';
  const activeClass = 'px-2.5 py-1 rounded font-bold bg-white text-brand-700 shadow-sm text-xs transition';

  if (btnHour) btnHour.className = normalClass;
  if (btnDay) btnDay.className = normalClass;
  if (btnWeek) btnWeek.className = normalClass;
  if (btnMonth) btnMonth.className = normalClass;
  if (btnYear) btnYear.className = normalClass;

  if (scale === 'HOUR') {
    if (btnHour) btnHour.className = activeClass;
    if (dayWindowControls) dayWindowControls.style.display = 'none';
  } else if (scale === 'DAY') {
    if (btnDay) btnDay.className = activeClass;
    if (dayWindowControls) dayWindowControls.style.display = 'flex';
  } else if (scale === 'WEEK') {
    if (btnWeek) btnWeek.className = activeClass;
    if (dayWindowControls) dayWindowControls.style.display = 'none';
  } else if (scale === 'MONTH') {
    if (btnMonth) btnMonth.className = activeClass;
    if (dayWindowControls) dayWindowControls.style.display = 'none';
  } else if (scale === 'YEAR') {
    if (btnYear) btnYear.className = activeClass;
    if (dayWindowControls) dayWindowControls.style.display = 'none';
  }
}

// Thay đổi chế độ xem (Giờ / Ngày / Tuần / Tháng / Năm)
function setTimeScale(scale) {
  viewState.timeScale = scale;
  updateTimeScaleButtons(scale);
  renderMainTable();
}

// ================= RENDER BẢNG GANTT & TIMELINE =================
function renderMainTable() {
  // Tự động quét và vá các trường ngày nếu bị lưu sai dạng Serial Excel (như 46037)
  autoFixCorruptedDates();

  // Ngày tham chiếu hệ thống (10/2026 hoặc ngày thực tế nếu đang ở 2026)
  const realNow = new Date();
  const systemToday = (realNow.getFullYear() === 2026)
    ? new Date(realNow.getFullYear(), realNow.getMonth(), realNow.getDate())
    : new Date(2026, 9, 8);

  // 1. Lọc danh sách công việc trước để xác định chính xác danh sách và khoảng thời gian cần hiển thị
  let filteredTasks = appData.tasks.filter(task => {
    if (appData.currentUser.role === 'employee') {
      const isLead = task.empId === appData.currentUser.id;
      const isSupport = Array.isArray(task.supportEmpIds) && task.supportEmpIds.includes(appData.currentUser.id);
      if (!isLead && !isSupport) return false;
    }
    if (viewState.filterEmp !== 'ALL') {
      const isLead = task.empId === viewState.filterEmp;
      const isSupport = Array.isArray(task.supportEmpIds) && task.supportEmpIds.includes(viewState.filterEmp);
      if (!isLead && !isSupport) return false;
    }

    // LỌC TÌNH TRẠNG CHUẨN XÁC (Dựa trên hàm xác định trạng thái thực tế)
    const effStatus = getTaskEffectiveStatus(task, systemToday);
    const isCompleted = isTaskCompleted(task);
    const isOverdue = isTaskOverdue(task, systemToday);

    if (viewState.filterStatus === 'CHUA_HOAN_THANH') {
      if (isCompleted) return false;
    } else if (viewState.filterStatus === 'HOAN_THANH_ALL') {
      if (!isCompleted) return false;
    } else if (viewState.filterStatus === 'DANG_LAM') {
      // Đang làm / Đang thực hiện: bao gồm toàn bộ việc đang làm (kể cả việc đang làm trễ hạn), loại việc đã xong và tạm dừng
      if (isCompleted || effStatus === 'Tạm dừng') return false;
    } else if (viewState.filterStatus === 'Tạm dừng') {
      if (effStatus !== 'Tạm dừng') return false;
    } else if (viewState.filterStatus === 'QUA_HAN') {
      // Quá hạn: việc chưa xong và đã vượt quá ngày kết thúc kế hoạch
      if (!isOverdue) return false;
    } else if (viewState.filterStatus === 'Hoàn thành') {
      if (effStatus !== 'Hoàn thành') return false;
    } else if (viewState.filterStatus === 'Hoàn thành trễ') {
      if (effStatus !== 'Hoàn thành trễ') return false;
    } else if (viewState.filterStatus !== 'ALL') {
      if (effStatus !== viewState.filterStatus) return false;
    }

    if (viewState.filterKeyword) {
      const kw = viewState.filterKeyword.toLowerCase().trim();
      const matchTitle = (task.title || '').toLowerCase().includes(kw);
      const matchDetail = (task.detail || '').toLowerCase().includes(kw);
      const matchEmp = (task.empName || '').toLowerCase().includes(kw);
      const matchNote = (task.note || '').toLowerCase().includes(kw);
      const matchMain = (task.mainTaskTitle || '').toLowerCase().includes(kw);
      const matchSupport = (task.supportEmpNames || []).some(n => String(n || '').toLowerCase().includes(kw));
      if (!matchTitle && !matchDetail && !matchEmp && !matchNote && !matchMain && !matchSupport) return false;
    }

    // LỌC THỜI GIAN:
    // Nếu có lọc theo khoảng ngày tự do (Từ ngày -> Đến ngày)
    if (viewState.filterStartDate && viewState.filterEndDate) {
      const rStart = parseDate(viewState.filterStartDate);
      const rEnd = parseDate(viewState.filterEndDate);
      const tStart = parseDate(task.startDate);
      const tEnd = parseDate(task.actualEndDate || task.planEndDate);
      if (rStart && rEnd && tStart && tEnd) {
        if (tStart > rEnd || tEnd < rStart) return false;
      }
    } else if (viewState.filterMonth && (viewState.timeScale === 'DAY' || viewState.timeScale === 'WEEK')) {
      // Khi lọc theo tháng (trong chế độ Ngày hoặc Tuần):
      // Một việc thuộc về tháng này nếu thời gian diễn ra của việc đó có giao nhau với tháng đang xem.
      // Đặc biệt việc chưa xong (đang làm/quá hạn/tạm dừng) vẫn tồn đọng trong tháng đang xem!
      const [fYear, fMonth] = viewState.filterMonth.split('-').map(Number);
      const monthStart = new Date(fYear, fMonth - 1, 1);
      const monthEnd = new Date(fYear, fMonth, 0, 23, 59, 59);
      const tStart = parseDate(task.startDate);

      let tEnd = null;
      if (isCompleted && task.actualEndDate && String(task.actualEndDate).trim() !== 'Chưa hoàn thành') {
        tEnd = parseDate(task.actualEndDate);
      }
      if (!tEnd) {
        if (isCompleted) {
          tEnd = parseDate(task.planEndDate) || tStart;
        } else {
          // Việc chưa hoàn thành: kéo dài đến hôm nay (hoặc planEndDate, mốc nào xa hơn)
          const pEnd = parseDate(task.planEndDate) || tStart;
          tEnd = (pEnd && pEnd > systemToday) ? pEnd : systemToday;
        }
      }

      if (tStart && tEnd) {
        // Giao nhau giữa [tStart, tEnd] và [monthStart, monthEnd]
        if (tStart > monthEnd || tEnd < monthStart) {
          return false;
        }
      }
    }

    // LỌC THEO NGUỒN YÊU CẦU / CHỈ ĐẠO (Đồng bộ linh hoạt cả Cải tiến / Cải thiện, TGĐ, TP, v.v.)
    const priFilter = viewState.filterPriority || (document.getElementById('filterPriority') ? document.getElementById('filterPriority').value : 'ALL');
    if (priFilter && priFilter !== 'ALL') {
      const tSource = (task.taskSource || '').toLowerCase().trim();
      const fPri = priFilter.toLowerCase().trim();
      if (fPri.includes('tổng giám đốc') || fPri.includes('tgđ') || fPri.includes('tgd')) {
        if (!tSource.includes('tổng giám đốc') && !tSource.includes('tgđ') && !tSource.includes('tgd')) return false;
      } else if (fPri === 'giám đốc' || fPri === 'gđ' || fPri === 'gd') {
        if ((!tSource.includes('giám đốc') && !tSource.includes('gđ')) || tSource.includes('tổng giám đốc')) return false;
      } else if (fPri.includes('trưởng phòng') || fPri.includes('tp')) {
        if (!tSource.includes('trưởng phòng') && !tSource.includes('tp')) return false;
      } else if (fPri.includes('đối ứng')) {
        if (!tSource.includes('đối ứng')) return false;
      } else if (fPri.includes('cải tiến') || fPri.includes('cải thiện')) {
        if (!tSource.includes('cải tiến') && !tSource.includes('cải thiện')) return false;
      } else if (fPri.includes('chiến lược')) {
        if (!tSource.includes('chiến lược')) return false;
      } else {
        if (!tSource.includes(fPri)) return false;
      }
    }

    // LỌC THEO DỰ ÁN / CÔNG VIỆC CHÍNH
    if (viewState.filterMainTask && viewState.filterMainTask !== 'ALL') {
      if (viewState.filterMainTask === '__NO_PROJECT__') {
        if (task.mainTaskId && task.mainTaskId.trim()) return false;
      } else {
        const mId = viewState.filterMainTask.toLowerCase();
        const taskMain = (task.mainTaskId || '').toLowerCase();
        const taskTitle = (task.mainTaskTitle || task.title || '').toLowerCase();
        if (taskMain !== mId && taskTitle !== mId && (task.id || '').toLowerCase() !== mId) {
          return false;
        }
      }
    }

    return true;
  });

  // 2. Tạo cột Timeline thích ứng tự động từ danh sách công việc hiển thị (kèm việc tháng trước nếu có)
  const timelineCols = getTimelineColumns(filteredTasks);
  const headerRow = document.getElementById('tableHeaderRow');

  while (headerRow.children.length > 14) {
    headerRow.removeChild(headerRow.lastChild);
  }

  timelineCols.forEach(col => {
    const th = document.createElement('th');
    const isWeekend = col.isWeekend;
    let thClass = isWeekend ? 'col-weekend text-amber-900' : 'bg-slate-100 text-slate-700';

    if (col.isHoliday) {
      if (col.holidayType === 'NATIONAL') {
        thClass = 'col-holiday-national text-red-900 font-bold';
      } else {
        thClass = 'col-holiday-special text-purple-900 font-bold';
      }
      th.title = `Ngày nghỉ: ${col.holidayName}`;
    }

    th.className = `p-1.5 border-r border-slate-300 text-center min-w-[54px] max-w-[70px] font-semibold text-[10px] ${thClass}`;

    if (col.type === 'HOUR') {
      th.className = 'p-1.5 border-r border-slate-300 text-center min-w-[50px] font-semibold text-[10px] bg-slate-100 text-slate-700';
      th.innerHTML = `
        <div class="font-extrabold text-sky-700">${col.label}</div>
        <div class="text-[8px] text-slate-400 font-normal">${col.subLabel}</div>
      `;
    } else if (col.type === 'YEAR') {
      th.className = 'p-1.5 border-r border-slate-300 text-center min-w-[80px] font-semibold text-[11px] bg-slate-100 text-slate-700';
      th.innerHTML = `
        <div class="font-black text-brand-800 text-xs">${col.label}</div>
        <div class="text-[9px] text-slate-400">${col.subLabel}</div>
      `;
    } else if (col.type === 'MONTH') {
      th.className = 'p-1.5 border-r border-slate-300 text-center min-w-[65px] font-semibold text-[11px] bg-slate-100 text-slate-700';
      th.innerHTML = `
        <div class="text-[9px] text-sky-600 font-bold">${col.subLabel}</div>
        <div class="font-extrabold text-slate-800">${col.label}</div>
      `;
    } else if (col.type === 'WEEK') {
      th.className = 'p-1.5 border-r border-slate-300 text-center min-w-[75px] font-semibold text-[10px] bg-slate-100 text-slate-700';
      th.innerHTML = `
        <div class="font-bold text-slate-800">${col.label}</div>
        <div class="text-[8px] text-slate-400 font-normal">${col.subLabel}</div>
      `;
    } else {
      th.innerHTML = `
        <div class="text-[9px] text-slate-400 font-normal">${col.subLabel}</div>
        <div class="font-bold text-slate-800">${col.label}</div>
        <div class="text-[8px] text-slate-400">${col.yearLabel}</div>
      `;
    }
    headerRow.appendChild(th);
  });

  // Cập nhật Banner dự án đang chọn
  const banner = document.getElementById('activeProjectBanner');
  if (banner) {
    if (viewState.filterMainTask && viewState.filterMainTask !== 'ALL') {
      let displayTitle;
      if (viewState.filterMainTask === '__NO_PROJECT__') {
        displayTitle = '🍃 Việc riêng lẻ (Chưa thuộc dự án)';
      } else {
        const mTasks = getUniqueMainTasks();
        const foundM = mTasks.find(m => m.id === viewState.filterMainTask);
        displayTitle = foundM ? `[${foundM.id}] ${foundM.title}` : viewState.filterMainTask;
      }
      const titleEl = document.getElementById('activeProjectTitle');
      const badgeEl = document.getElementById('activeProjectBadge');
      if (titleEl) titleEl.innerText = displayTitle;
      if (badgeEl) badgeEl.innerText = `${filteredTasks.length} công việc`;
      banner.classList.remove('hidden');
    } else {
      banner.classList.add('hidden');
    }
  }

  // GOM NHÓM & SẮP XẾP: Các việc cùng chung công việc chính luôn xếp liền kề nhau
  filteredTasks = groupAndSortTasks(filteredTasks);

  document.getElementById('tableRecordCount').innerText = `Hiển thị: ${filteredTasks.length} công việc`;

  const tbody = document.getElementById('tableBody');
  const emptyState = document.getElementById('emptyState');
  tbody.innerHTML = '';

  if (filteredTasks.length === 0) {
    emptyState.classList.remove('hidden');
    return;
  } else {
    emptyState.classList.add('hidden');
  }

  let prevEmpId = null;

  // Render từng công việc
  filteredTasks.forEach((task, idx) => {
    const isAdmin = appData.currentUser.role === 'admin';
    const isMyTask = appData.currentUser.id === task.empId;
    // Ngày hiệu lực kết thúc cho việc đang làm (lấy ngày lớn nhất giữa systemToday và lastStatusUpdate)
    let taskEffectiveToday = new Date(systemToday);
    if (task.lastStatusUpdate) {
      const lastUp = parseDate(task.lastStatusUpdate);
      if (lastUp && lastUp > taskEffectiveToday) {
        taskEffectiveToday = lastUp;
      }
    }

    const effStatus = getTaskEffectiveStatus(task, taskEffectiveToday);
    const isPaused = effStatus === 'Tạm dừng';
    const isCompleted = effStatus === 'Hoàn thành' || effStatus === 'Hoàn thành trễ';
    const isInProgress = !isCompleted && !isPaused;

    const currentSortBy = viewState.filterSortBy || (document.getElementById('filterSortBy') ? document.getElementById('filterSortBy').value : 'EMP_START');

    // Phân cách nhóm nhân sự (chỉ khi đang sắp xếp theo Người => Thứ tự việc)
    if (currentSortBy === 'EMP_START' && task.empId !== prevEmpId) {
      prevEmpId = task.empId;
      const empTaskCount = filteredTasks.filter(t => t.empId === task.empId).length;
      const trGroup = document.createElement('tr');
      trGroup.className = 'emp-group-header bg-slate-100/90 text-slate-800 border-y border-slate-300 font-bold text-xs select-none';
      trGroup.innerHTML = `
        <td colspan="${14 + timelineCols.length}" class="px-3 py-1.5 text-left sticky-col-left bg-gradient-to-r from-slate-100 via-indigo-50/60 to-transparent">
          <div class="flex items-center gap-2">
            <span class="inline-flex items-center justify-center w-5 h-5 rounded-full bg-indigo-600 text-white text-[10px]"><i class="fa-solid fa-user"></i></span>
            <span class="text-indigo-950 font-bold text-xs">${task.empName || 'Chưa phân công'} (${task.empId})</span>
            <span class="text-[10px] font-normal text-slate-500">• ${empTaskCount} công việc (xếp theo ngày nhận việc)</span>
          </div>
        </td>
      `;
      tbody.appendChild(trGroup);
    }

    // Kiểm tra quá 3 ngày chưa cập nhật tình trạng hoặc quá hạn kế hoạch đối với việc chưa hoàn tất
    let isOverdueUpdate = false;
    let daysSinceUpdate = 0;
    let overdueReason = '';

    if (!isCompleted && !isPaused) {
      const pEnd = parseDate(task.planEndDate);
      const sDate = parseDate(task.startDate);

      if (!task.lastStatusUpdate) {
        // CHƯA CẬP NHẬT LẦN NÀO:
        if (pEnd && taskEffectiveToday > pEnd) {
          // Đã quá ngày kết thúc kế hoạch mà chưa cập nhật gì!
          isOverdueUpdate = true;
          daysSinceUpdate = Math.max(1, Math.floor((taskEffectiveToday - pEnd) / (1000 * 60 * 60 * 24)));
          overdueReason = `Quá hạn KH (${daysSinceUpdate} ngày) & chưa cập nhật lần nào`;
        } else if (sDate && taskEffectiveToday >= sDate) {
          // Đã qua ngày bắt đầu mà chưa cập nhật: nếu quá 3 ngày thì báo
          const diffFromStart = Math.max(0, Math.floor((taskEffectiveToday - sDate) / (1000 * 60 * 60 * 24)));
          if (diffFromStart >= 3) {
            isOverdueUpdate = true;
            daysSinceUpdate = diffFromStart;
            overdueReason = `${diffFromStart} ngày chưa cập nhật tình trạng`;
          }
        } else if (!pEnd && !sDate) {
          isOverdueUpdate = true;
          daysSinceUpdate = 3;
          overdueReason = 'Chưa cập nhật tình trạng';
        }
      } else {
        // ĐÃ TỪNG CẬP NHẬT TRƯỚC ĐÓ:
        const lastUpdateDate = parseDate(task.lastStatusUpdate);
        if (lastUpdateDate) {
          daysSinceUpdate = Math.max(0, Math.floor((taskEffectiveToday - lastUpdateDate) / (1000 * 60 * 60 * 24)));
          if (daysSinceUpdate >= 3) {
            isOverdueUpdate = true;
            overdueReason = `Quá ${daysSinceUpdate} ngày chưa cập nhật`;
          } else if (pEnd && taskEffectiveToday > pEnd && lastUpdateDate < pEnd) {
            // Đã quá hạn kế hoạch nhưng lần cập nhật cuối là từ trước khi hết hạn
            isOverdueUpdate = true;
            const overdueDays = Math.max(1, Math.floor((taskEffectiveToday - pEnd) / (1000 * 60 * 60 * 24)));
            overdueReason = `Quá hạn KH (${overdueDays} ngày) & cần cập nhật lại`;
          }
        } else {
          isOverdueUpdate = true;
          daysSinceUpdate = 3;
          overdueReason = 'Chưa cập nhật tình trạng';
        }
      }
    }

    let statusBadge = '';
    if (effStatus === 'Tạm dừng') {
      statusBadge = '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300">⏸ Tạm dừng</span>';
    } else if (effStatus === 'Hoàn thành') {
      statusBadge = '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">Hoàn Thành</span>';
    } else if (effStatus === 'Hoàn thành trễ') {
      statusBadge = '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-orange-100 text-orange-800 border border-orange-300">Hoàn Thành trễ</span>';
    } else if (effStatus === 'Đang làm (Trễ hạn)') {
      statusBadge = '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900 border border-amber-300 inline-flex items-center gap-1 shadow-sm" title="Công việc đang thực hiện nhưng đã quá hạn dự tính"><i class="fa-solid fa-clock-rotate-left text-rose-500 text-[9px]"></i>Đang thực hiện <span class="text-rose-600 font-extrabold text-[9px]">(Trễ hạn)</span></span>';
    } else if (effStatus === 'Quá hạn') {
      statusBadge = '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-300">Quá hạn</span>';
    } else {
      statusBadge = '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 border border-blue-300">Đang thực hiện</span>';
    }

    // Nguồn yêu cầu & Tiến độ công việc chính
    const sourceBadge = getSourceBadge(task.taskSource);
    const mainProgress = task.mainTaskId ? getMainTaskProgress(task.mainTaskId) : null;
    const mainBadge = task.mainTaskId ? `
      <button type="button" onclick="filterByMainTask('${task.mainTaskId}')" class="px-1.5 py-0.5 text-[9px] font-semibold bg-sky-50 hover:bg-sky-100 text-sky-700 rounded border border-sky-200 mr-1 transition cursor-pointer" title="Nhấn để lọc xem các việc của dự án [${task.mainTaskId}] và tự căn chỉnh biểu đồ">
        <i class="fa-solid fa-diagram-project text-[8px] mr-0.5"></i>${task.mainTaskId}
      </button>
    ` : '';
    let parentStatusBadge = '';
    if (mainProgress) {
      if (mainProgress.isAllCompleted) {
        parentStatusBadge = `<div class="mt-1"><span class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300" title="Toàn bộ ${mainProgress.totalCount} công việc con đã hoàn thành"><i class="fa-solid fa-circle-check text-emerald-600"></i>Dự án Xong (100%)</span></div>`;
      } else {
        parentStatusBadge = `<div class="mt-1"><span class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-semibold bg-sky-100 text-sky-800 border border-sky-300" title="Dự án đang làm: ${mainProgress.completedCount}/${mainProgress.totalCount} việc hoàn thành"><i class="fa-solid fa-spinner fa-spin-pulse text-sky-600"></i>Dự án: ${mainProgress.completedCount}/${mainProgress.totalCount} việc</span></div>`;
      }
    }

    // Hiển thị ngày cập nhật cuối (lastStatusUpdate)
    const hasStatusUpdate = !!(task.lastStatusUpdate && task.lastStatusUpdate.trim());
    const lastUpdateDisplay = hasStatusUpdate ? formatVnDate(task.lastStatusUpdate) : 'Chưa cập nhật';
    const lastUpdateInfo = (!isCompleted && !isPaused) ? `
      <div class="mt-1 flex items-center gap-1" title="${hasStatusUpdate ? `Lần cập nhật gần nhất: ${lastUpdateDisplay}` : 'Chưa từng ghi nhận cập nhật tiến độ'}">
        <i class="fa-regular fa-clock text-slate-400 text-[8px]"></i>
        <span class="text-[9px] ${(!hasStatusUpdate || isOverdueUpdate) ? 'text-rose-600 font-semibold' : 'text-slate-400'}">
          CN cuối: ${lastUpdateDisplay}
        </span>
      </div>
    ` : '';

    // Cảnh báo quá 3 ngày chưa cập nhật hoặc quá hạn kế hoạch
    const overdueWarning = isOverdueUpdate ? `
      <div class="mt-1">
        <span class="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-rose-100 text-rose-700 border border-rose-300 animate-pulse" title="${overdueReason || `Quá ${daysSinceUpdate} ngày chưa cập nhật tình trạng! Cần click 'Cập nhật tình trạng' để ghi nhận.`}">
          <i class="fa-solid fa-triangle-exclamation"></i> Cần Cập Nhật (${daysSinceUpdate > 0 ? `${daysSinceUpdate} ngày` : 'Quá hạn'})
        </span>
      </div>
    ` : '';

    // DÒNG 1: THÔNG TIN GỘP + KẾ HOẠCH
    const tr1 = document.createElement('tr');
    tr1.className = `hover:bg-slate-50/80 transition group ${isOverdueUpdate ? 'row-overdue-update' : ''}`;

    const tdCB = `
      <td rowspan="2" class="p-2 border-r border-b border-slate-300 text-center bg-white sticky-col-left shadow-[1px_0_0_0_#cbd5e1]" style="left: 0;">
        <input type="checkbox" class="gantt-task-cb w-3.5 h-3.5 text-brand-600 rounded border-slate-300 cursor-pointer" data-id="${task.id}" onchange="_onGanttTaskCheckboxChange(this)">
      </td>
    `;
    const tdSTT = `<td rowspan="2" class="p-2 border-r border-b border-slate-300 text-center font-bold text-slate-500 bg-white sticky-col-left shadow-[1px_0_0_0_#cbd5e1]" style="left: 40px;">${idx + 1}</td>`;
    const tdTitle = `
      <td rowspan="2" class="p-2 border-r border-b border-slate-300 bg-white sticky-col-left shadow-[1px_0_0_0_#cbd5e1]" style="left: 80px;">
        <div class="font-bold text-slate-900 leading-snug">
          <button type="button" onclick="filterByMainTask('${task.mainTaskId || task.id}')" class="text-left font-bold text-slate-900 hover:text-sky-700 transition cursor-pointer" title="Nhấn để chỉ xem các việc của dự án này và tự động căn chỉnh biểu đồ">
            ${task.mainTaskTitle || task.title}
          </button>
        </div>
        <div class="text-[10px] text-slate-500 flex flex-wrap items-center gap-1 mt-0.5">
          ${mainBadge}
          <span>${task.id}</span>
          ${sourceBadge}
        </div>
        ${parentStatusBadge}
        ${lastUpdateInfo}
        ${overdueWarning}
        <div class="mt-1.5 flex flex-wrap items-center gap-1.5">
          ${!isCompleted ? `
            <button onclick="openStatusLogModal('${task.id}')" class="px-2 py-0.5 text-[10px] font-bold rounded bg-violet-100 text-violet-700 hover:bg-violet-200 border border-violet-300 transition flex items-center gap-1 shadow-sm" title="Ghi nhật ký / Cập nhật tình trạng công việc">
              <i class="fa-solid fa-clipboard-list"></i> Cập nhật tình trạng
            </button>
          ` : ''}
          ${isAdmin ? `
            <div class="flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition">
              <button onclick="toggleTaskPause('${task.id}')" class="text-amber-600 hover:text-amber-800 text-[10px] font-semibold" title="Tạm dừng hoặc tiếp tục công việc"><i class="fa-solid fa-circle-pause"></i> ${isPaused ? 'Tiếp tục' : 'Dừng'}</button>
              <button onclick="editTask('${task.id}')" class="text-blue-600 hover:text-blue-800 text-[10px]"><i class="fa-solid fa-pen"></i> Sửa</button>
              <button onclick="deleteTask('${task.id}')" class="text-rose-600 hover:text-rose-800 text-[10px]"><i class="fa-solid fa-trash"></i> Xóa</button>
            </div>
          ` : (isMyTask ? `
            <div class="flex items-center gap-1.5">
              <button onclick="toggleTaskPause('${task.id}')" class="text-amber-600 hover:text-amber-800 text-[10px] font-semibold"><i class="fa-solid fa-circle-pause"></i> ${isPaused ? 'Tiếp tục' : 'Dừng'}</button>
              <button onclick="openQuickUpdateModal('${task.id}')" class="text-emerald-600 hover:text-emerald-800 font-semibold text-[10px]"><i class="fa-solid fa-check-to-slot"></i> Cập nhật</button>
            </div>
          ` : '')}
        </div>
      </td>
    `;
    const tdDetail = `<td rowspan="2" class="p-2 border-r border-b border-slate-300 text-slate-700 font-medium">${task.detail || task.title}</td>`;
    let supportBadgesHtml = '';
    const supportList = Array.isArray(task.supportEmpNames) ? task.supportEmpNames : (task.supportEmps ? String(task.supportEmps).split(',').map(s=>s.trim()).filter(Boolean) : []);
    if (supportList.length > 0) {
      supportBadgesHtml = `
        <div class="mt-1 flex flex-wrap items-center gap-1" title="Người phối hợp: ${supportList.join(', ')}">
          <span class="inline-flex items-center gap-1 text-[9px] bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded border border-indigo-200 font-medium">
            <i class="fa-solid fa-users text-[8px] text-indigo-500"></i>
            <span>PH: ${supportList.join(', ')}</span>
          </span>
        </div>
      `;
    }

    const tdEmp = `
      <td rowspan="2" class="p-2 border-r border-b border-slate-300 font-medium text-slate-800">
        <div class="flex items-center gap-1.5">
          <i class="fa-solid fa-user-check text-sky-600 text-[10px]" title="Người phụ trách chính"></i>
          <span class="font-bold text-slate-900">${task.empName}</span>
        </div>
        ${supportBadgesHtml}
      </td>
    `;
    const tdStart = `<td rowspan="2" class="p-2 border-r border-b border-slate-300 text-center font-medium text-slate-700">${formatVnDate(task.startDate)}</td>`;
    const tdPlanDays = `<td rowspan="2" class="p-2 border-r border-b border-slate-300 text-center font-semibold text-slate-800">${formatPlanDuration(task)}</td>`;
    const tdPlanEndDate = `<td rowspan="2" class="p-2 border-r border-b border-slate-300 text-center font-medium text-sky-800 bg-sky-50/20">${formatVnDate(task.planEndDate) || '—'}</td>`;

    // Hiển thị ngày hoàn thành thực tế chuẩn xác: CHỈ hiển thị ngày nếu thật sự có actualEndDate
    const hasActualEnd = !!(task.actualEndDate && String(task.actualEndDate).trim() && String(task.actualEndDate).trim() !== 'Chưa hoàn thành');
    const actualDateDisplay = hasActualEnd 
      ? formatVnDate(task.actualEndDate) 
      : (isPaused ? 'Tạm dừng' : 'Chưa có');
    const tdActualDate = `<td rowspan="2" class="p-2 border-r border-b border-slate-300 text-center font-medium ${hasActualEnd ? 'text-emerald-700 font-bold' : 'text-slate-400'}">${actualDateDisplay}</td>`;

    // Hiện Trạng = ghi chú của lần cập nhật mới nhất
    const latestLogs = Array.isArray(task.statusLogs) ? [...task.statusLogs].sort((a, b) => (b.date || '').localeCompare(a.date || '')) : [];
    const latestLog = latestLogs.length > 0 ? latestLogs[0] : null;
    const latestNoteText = latestLog ? (latestLog.note || '') : '';
    const latestProgressText = latestLog && latestLog.progress !== undefined ? ` (${latestLog.progress}%)` : '';
    const latestDateText = latestLog && latestLog.date ? ` — ${formatVnDate(latestLog.date)}` : '';
    const currentStatusTooltip = latestLog
      ? `${formatVnDate(latestLog.date)}${latestProgressText}: ${latestNoteText}`
      : 'Chưa có cập nhật';
    const currentStatusDisplay = latestNoteText
      ? `<div class="text-[11px] text-slate-600 italic leading-snug line-clamp-2" title="${currentStatusTooltip.replace(/"/g, '&quot;')}">${latestNoteText}<span class="text-[9px] text-slate-400 not-italic ml-0.5 block">${latestProgressText}${latestDateText}</span></div>`
      : `<div class="text-[10px] text-slate-300 italic">—</div>`;
    const tdCurrentStatus = `<td rowspan="2" class="p-2 border-r border-b border-slate-300 min-w-[130px] max-w-[180px] align-top">${currentStatusDisplay}</td>`;

    const tdStatus = `<td rowspan="2" class="p-2 border-r border-b border-slate-300 text-center">${statusBadge}</td>`;
    const tdNote = `<td rowspan="2" class="p-2 border-r border-b border-slate-300 text-slate-500 italic text-[11px]">${task.note || ''}</td>`;


    let linkHtml = '';
    if (task.link && task.link.trim()) {
      const safeLink = task.link.trim();
      linkHtml = `
        <div class="flex items-center justify-center gap-1">
          <button type="button" onclick="openTaskFileLink('${task.id}')" class="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800 hover:bg-sky-200 border border-sky-300 transition cursor-pointer" title="Mở liên kết / Tệp: ${safeLink.replace(/"/g, '&quot;')} (Tự động sao chép đường dẫn)">
            <i class="fa-solid fa-arrow-up-right-from-square text-[9px]"></i> Mở
          </button>
          <button type="button" onclick="openEditTaskLinkModal('${task.id}')" class="text-slate-400 hover:text-sky-600 p-0.5 text-[10px]" title="Chỉnh sửa link">
            <i class="fa-solid fa-pen"></i>
          </button>
        </div>
      `;
    } else {
      linkHtml = `
        <button type="button" onclick="openEditTaskLinkModal('${task.id}')" class="px-1.5 py-0.5 text-[10px] rounded text-slate-400 hover:text-sky-700 hover:bg-sky-50 border border-dashed border-slate-300 transition" title="Thêm liên kết tệp/thư mục">
          <i class="fa-solid fa-plus text-[8px]"></i> Link
        </button>
      `;
    }
    const tdLink = `<td rowspan="2" class="p-2 border-r border-b border-slate-300 text-center">${linkHtml}</td>`;
    const tdLabelPlan = `<td class="p-1.5 border-r border-b border-slate-300 text-center font-semibold text-slate-700 bg-sky-50/50 text-[10px]">Kế hoạch</td>`;

    tr1.innerHTML = tdCB + tdSTT + tdTitle + tdDetail + tdEmp + tdStart + tdPlanDays + tdPlanEndDate + tdActualDate + tdCurrentStatus + tdStatus + tdNote + tdLink + tdLabelPlan;

    const tStart = parseDate(task.startDate);
    const tPlanEnd = parseDate(task.planEndDate);

    // Vẽ thanh Kế hoạch theo các cột
    timelineCols.forEach(col => {
      const td = document.createElement('td');
      let cellBg = 'bg-slate-50/30';
      if (col.isHoliday) {
        cellBg = col.holidayType === 'NATIONAL' ? 'cell-national' : 'cell-special';
      } else if (col.isWeekend) {
        cellBg = 'cell-weekend';
      }
      td.className = `p-0 border-r border-b border-slate-200 text-center relative h-7 min-w-[54px] ${cellBg}`;

      const inRange = tStart && tPlanEnd && col.startDate <= tPlanEnd && col.endDate >= tStart;

      if (inRange) {
        const isStart = col.startDate <= tStart && col.endDate >= tStart;
        const isEnd = col.startDate <= tPlanEnd && col.endDate >= tPlanEnd;

        const sPlanStr = formatVnDate(task.startDate).slice(0, 5);
        const ePlanStr = formatVnDate(task.planEndDate).slice(0, 5);

        let barContent = '';
        if (isStart && isEnd) {
          barContent = `<span class="arrow-date-tag text-[8px] mx-auto">${sPlanStr}→${ePlanStr}</span>`;
        } else if (isStart) {
          barContent = `<span class="arrow-date-tag text-[8px] ml-1 mr-auto">${sPlanStr}</span>`;
        } else if (isEnd) {
          barContent = `<span class="arrow-date-tag text-[8px] mr-1 ml-auto">${ePlanStr}</span>`;
        }

        td.innerHTML = `
          <div class="h-4 my-1.5 timeline-arrow-plan relative flex items-center ${isStart && !isEnd ? 'justify-start' : (isEnd && !isStart ? 'justify-end' : 'justify-center')} text-white text-[9px] font-bold ${isStart ? 'rounded-l-sm ml-1' : ''} ${isEnd ? 'mr-0' : ''}" title="Kế hoạch: ${formatVnDate(task.startDate)} - ${formatVnDate(task.planEndDate)}">
            ${barContent}
            ${isEnd ? `<div class="arrow-head-plan"></div>` : ''}
          </div>
        `;
      }
      tr1.appendChild(td);
    });

    // DÒNG 2: THỰC TÍCH
    const tr2 = document.createElement('tr');
    tr2.className = `hover:bg-slate-50/80 transition group border-b border-slate-300 ${isOverdueUpdate ? 'row-overdue-update' : ''}`;
    const tdLabelActual = `<td class="p-1.5 border-r border-b border-slate-300 text-center font-semibold text-emerald-800 bg-emerald-50/50 text-[10px]">Thực tích</td>`;
    tr2.innerHTML = tdLabelActual;

    let tActualEnd = parseDate(task.actualEndDate);
    if (!tActualEnd && isInProgress) {
      // Đang làm: biểu đồ kéo dài từ startDate đến hôm nay/ngày cập nhật mới nhất
      tActualEnd = taskEffectiveToday;
      if (tStart && tActualEnd < tStart) tActualEnd = tStart;
    } else if (!tActualEnd && isPaused) {
      tActualEnd = taskEffectiveToday;
      if (tStart && tActualEnd < tStart) tActualEnd = tStart;
    }

    timelineCols.forEach(col => {
      const td = document.createElement('td');
      let cellBg = 'bg-emerald-50/10';
      if (col.isHoliday) {
        cellBg = col.holidayType === 'NATIONAL' ? 'cell-national' : 'cell-special';
      } else if (col.isWeekend) {
        cellBg = 'cell-weekend';
      }
      td.className = `p-0 border-r border-b border-slate-300 text-center relative h-7 min-w-[54px] ${cellBg}`;

      const inRange = tStart && tActualEnd && col.startDate <= tActualEnd && col.endDate >= tStart;

      if (inRange) {
        const isStart = col.startDate <= tStart && col.endDate >= tStart;
        const isEnd = col.startDate <= tActualEnd && col.endDate >= tActualEnd;
        const isDelayed = !isPaused && tPlanEnd && col.startDate > tPlanEnd;

        let barClass = 'timeline-arrow-actual';
        let headClass = 'arrow-head-actual';
        let titleTip = `Thực tích: ${formatVnDate(task.startDate)} - ${formatVnDate(task.actualEndDate)}`;

        if (isPaused) {
          barClass = 'timeline-arrow-paused';
          headClass = 'arrow-head-paused';
          titleTip = `Tạm dừng: ${formatVnDate(task.startDate)} - hiện tại`;
        } else if (!task.actualEndDate && isInProgress) {
          // Biểu đồ thực tích khi Đang làm: dải màu cyan/blue kèm animation
          barClass = 'timeline-arrow-in-progress';
          headClass = 'arrow-head-in-progress';
          titleTip = `Đang làm (Tiến độ đến ${formatVnDate(formatDate(tActualEnd))}): ${formatVnDate(task.startDate)} → ${formatVnDate(formatDate(tActualEnd))}`;
        } else if (isDelayed) {
          barClass = 'timeline-arrow-late';
          headClass = 'arrow-head-late';
          titleTip = `Hoàn thành trễ: ${formatVnDate(task.startDate)} - ${formatVnDate(task.actualEndDate)}`;
        }

        const sActualStr = formatVnDate(task.startDate).slice(0, 5);
        const eActualStr = task.actualEndDate
          ? formatVnDate(task.actualEndDate).slice(0, 5)
          : (isPaused ? 'Dừng' : formatVnDate(formatDate(tActualEnd)).slice(0, 5));

        let barContent = '';
        if (isStart && isEnd) {
          barContent = `<span class="arrow-date-tag text-[8px] mx-auto">${sActualStr}→${eActualStr}</span>`;
        } else if (isStart) {
          barContent = `<span class="arrow-date-tag text-[8px] ml-1 mr-auto">${sActualStr}</span>`;
        } else if (isEnd) {
          barContent = `<span class="arrow-date-tag text-[8px] mr-1 ml-auto">${eActualStr}</span>`;
        }

        // Tìm các lần cập nhật trong ngày/cột này
        const logMarkers = (task.statusLogs || []).filter(log => {
          const logDate = parseDate(log.date);
          return logDate && col.startDate <= logDate && col.endDate >= logDate;
        });

        // Biểu tượng ghi chú hiển thị TRỰC TIẾP TRÊN THÂN MŨI TÊN
        let noteIconHtml = '';
        if (logMarkers.length > 0) {
          const lastLog = logMarkers[logMarkers.length - 1];
          const progTxt = lastLog.progress !== undefined ? `${lastLog.progress}%` : '';
          const tooltipContent = logMarkers.map(l => {
            const p = l.progress !== undefined ? ` [${l.progress}%]` : '';
            return `📋 ${formatVnDate(l.date)}${p}: ${l.note || 'Ghi nhận tiến độ'} (${l.author || 'Người dùng'})`;
          }).join('\n');

          noteIconHtml = `
            <div onclick="openStatusLogModal('${task.id}')" 
                 class="absolute left-1/2 -translate-x-1/2 top-1/2 -translate-y-1/2 z-20 flex items-center justify-center cursor-pointer pointer-events-auto"
                 title="${tooltipContent.replace(/"/g, '&quot;')}">
              <span class="inline-flex items-center gap-0.5 px-1 py-0.5 rounded-full bg-amber-400 text-amber-950 text-[8px] font-black shadow border border-white hover:scale-110 hover:bg-amber-300 transition-transform">
                <i class="fa-solid fa-note-sticky text-[8px] text-amber-900"></i>
                ${progTxt ? `<span>${progTxt}</span>` : ''}
              </span>
            </div>
          `;
        }

        td.innerHTML = `
          <div class="h-4 my-1.5 ${barClass} relative flex items-center ${isStart && !isEnd ? 'justify-start' : (isEnd && !isStart ? 'justify-end' : 'justify-center')} text-white text-[9px] font-bold ${isStart ? 'rounded-l-sm ml-1' : ''} ${isEnd ? 'mr-0' : ''}" title="${titleTip}">
            ${barContent}
            ${noteIconHtml}
            ${isEnd ? `<div class="${headClass}"></div>` : ''}
          </div>
        `;
      }
      tr2.appendChild(td);
    });

    tbody.appendChild(tr1);
    tbody.appendChild(tr2);
  });

  updateKPIStats();
  if (typeof _updateGanttBulkDeleteUI === 'function') {
    _updateGanttBulkDeleteUI();
  }
}

// Helper kiểm tra công việc có giao thoa với tháng đang xem hay không
function isTaskInMonth(task, yearMonthStr, today) {
  if (!yearMonthStr) return true;
  const parts = yearMonthStr.split('-');
  const fYear = parseInt(parts[0]);
  const fMonth = parseInt(parts[1]);
  if (!fYear || !fMonth) return true;

  const monthStart = new Date(fYear, fMonth - 1, 1);
  const monthEnd = new Date(fYear, fMonth, 0, 23, 59, 59);
  const tStart = parseDate(task.startDate);
  let tEnd = null;
  if (isTaskCompleted(task) && task.actualEndDate && String(task.actualEndDate).trim() !== 'Chưa hoàn thành') {
    tEnd = parseDate(task.actualEndDate);
  }
  if (!tEnd) {
    if (isTaskCompleted(task)) {
      tEnd = parseDate(task.planEndDate) || tStart;
    } else {
      const pEnd = parseDate(task.planEndDate) || tStart;
      tEnd = (pEnd && pEnd > today) ? pEnd : today;
    }
  }
  if (tStart && tEnd) {
    return !(tStart > monthEnd || tEnd < monthStart);
  }
  return true;
}

// Helper kiểm tra công việc có giao thoa với năm hay không
function isTaskInYear(task, targetYear, today) {
  if (!targetYear) return true;
  const y = parseInt(targetYear);
  if (!y) return true;

  const yStart = new Date(y, 0, 1);
  const yEnd = new Date(y, 11, 31, 23, 59, 59);
  const tStart = parseDate(task.startDate);
  let tEnd = null;
  if (isTaskCompleted(task) && task.actualEndDate && String(task.actualEndDate).trim() !== 'Chưa hoàn thành') {
    tEnd = parseDate(task.actualEndDate);
  }
  if (!tEnd) {
    if (isTaskCompleted(task)) {
      tEnd = parseDate(task.planEndDate) || tStart;
    } else {
      const pEnd = parseDate(task.planEndDate) || tStart;
      tEnd = (pEnd && pEnd > today) ? pEnd : today;
    }
  }
  if (tStart && tEnd) {
    return !(tStart > yEnd || tEnd < yStart);
  }
  return true;
}

// ================= CẬP NHẬT THẺ KPI =================
function updateKPIStats() {
  const scopeEl = document.getElementById('kpiScopeFilter');
  const scope = scopeEl ? scopeEl.value : 'ALL';
  const allTasks = appData.tasks || [];
  const today = getSystemToday();

  // Xác định tháng/năm đang xem
  const activeMonthStr = viewState.filterMonth || (document.getElementById('filterMonth') ? document.getElementById('filterMonth').value : '2026-10');
  const activeYear = activeMonthStr ? parseInt(activeMonthStr.split('-')[0]) : 2026;

  let tasksInScope = allTasks;
  let scopeLabel = `Toàn bộ (${allTasks.length} việc)`;

  if (scope === 'MONTH') {
    const mNum = activeMonthStr ? activeMonthStr.split('-')[1] : '10';
    tasksInScope = allTasks.filter(t => isTaskInMonth(t, activeMonthStr, today));
    scopeLabel = `Tháng ${mNum}/${activeYear} (${tasksInScope.length} việc)`;
  } else if (scope === 'YEAR') {
    tasksInScope = allTasks.filter(t => isTaskInYear(t, activeYear, today));
    scopeLabel = `Cả năm ${activeYear} (${tasksInScope.length} việc)`;
  }

  const scopeSummaryEl = document.getElementById('kpiScopeSummary');
  if (scopeSummaryEl) {
    scopeSummaryEl.innerText = `Phạm vi: ${scopeLabel}`;
  }

  let inProgress = 0;
  let onTime = 0;
  let late = 0;
  let paused = 0;
  let overdue = 0;

  tasksInScope.forEach(t => {
    const st = getTaskEffectiveStatus(t, today);
    if (st === 'Hoàn thành') {
      onTime++;
    } else if (st === 'Hoàn thành trễ') {
      late++;
    } else if (st === 'Tạm dừng') {
      paused++;
    } else {
      // Đang làm hoặc Đang làm (Trễ hạn)
      inProgress++;
      if (st === 'Đang làm (Trễ hạn)' || isTaskOverdue(t, today)) {
        overdue++;
      }
    }
  });

  const total = tasksInScope.length;
  const elTotal = document.getElementById('kpiTotalTasks');
  const elInProgress = document.getElementById('kpiInProgress');
  const elOnTime = document.getElementById('kpiOnTime');
  const elLate = document.getElementById('kpiLate');
  const elPaused = document.getElementById('kpiPaused');
  const elOverdue = document.getElementById('kpiOverdue');

  if (elTotal) elTotal.innerText = total;
  if (elInProgress) elInProgress.innerText = inProgress;
  if (elOnTime) elOnTime.innerText = onTime;
  if (elLate) elLate.innerText = late;
  if (elPaused) elPaused.innerText = paused;
  if (elOverdue) elOverdue.innerText = overdue;

  let totalPoints = 0;
  const empList = appData.employees || [];
  const scoreMonth = activeMonthStr ? parseInt(activeMonthStr.split('-')[1]) : 10;
  empList.forEach(emp => {
    const scores = calculateEmployeeMonthlyScores(emp.id, activeYear);
    totalPoints += scores[scoreMonth] || 100;
  });
  const avg = empList.length > 0 ? Math.round(totalPoints / empList.length) : 100;
  const elAvg = document.getElementById('kpiAvgScore');
  if (elAvg) elAvg.innerText = `${avg} đ`;

  highlightActiveKpiCard();
}

// ================= BẢNG ĐIỂM HIỆU SUẤT TỔNG THỂ =================
function openPerformanceBoardModal() {
  document.getElementById('perfBoardModal').classList.remove('hidden');
  renderPerformanceBoard();
}

function closePerformanceBoardModal() {
  document.getElementById('perfBoardModal').classList.add('hidden');
}

function renderPerformanceBoard() {
  const year = parseInt(document.getElementById('perfYearSelect').value) || 2026;
  const tbody = document.getElementById('perfBoardTableBody');
  tbody.innerHTML = '';

  appData.employees.forEach(emp => {
    const scores = calculateEmployeeMonthlyScores(emp.id, year);
    let yearTotal = 0;
    let cellsHtml = '';

    for (let m = 1; m <= 12; m++) {
      const score = scores[m];
      yearTotal += score;
      let colorClass = 'text-slate-700';
      if (score > 100) colorClass = 'text-emerald-600 font-bold';
      else if (score < 100 && score >= 90) colorClass = 'text-amber-600 font-semibold';
      else if (score < 90) colorClass = 'text-rose-600 font-bold';

      cellsHtml += `<td class="p-2 border-r border-slate-200 ${colorClass}">${score}</td>`;
    }

    let rankBadge = '';
    if (yearTotal >= 1200) {
      rankBadge = '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">Xuất Sắc</span>';
    } else if (yearTotal >= 1150) {
      rankBadge = '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800">Tốt</span>';
    } else if (yearTotal >= 1050) {
      rankBadge = '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">Khá</span>';
    } else {
      rankBadge = '<span class="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800">Cần Cải Thiện</span>';
    }

    const tr = document.createElement('tr');
    tr.className = 'hover:bg-slate-50 transition';
    tr.innerHTML = `
      <td class="p-2.5 border-r border-slate-200 text-left font-bold text-slate-800">
        <div>${emp.name}</div>
        <div class="text-[10px] text-slate-400 font-normal">${emp.id} - ${emp.dept}</div>
      </td>
      ${cellsHtml}
      <td class="p-2 border-r border-slate-200 bg-amber-50/60 font-black text-amber-900 text-sm">${yearTotal}</td>
      <td class="p-2">${rankBadge}</td>
    `;
    tbody.appendChild(tr);
  });
}

// ================= QUẢN LÝ NHÂN SỰ & TỰ ĐỘNG SINH MÃ NV-XXXX =================
function generateNextEmpId() {
  let maxNum = 0;
  (appData.employees || []).forEach(emp => {
    if (!emp.id) return;
    const m = emp.id.match(/^NV[-_]?(\d+)$/i);
    if (m) {
      const num = parseInt(m[1], 10);
      if (num > maxNum) maxNum = num;
    }
  });
  return `NV-${String(maxNum + 1).padStart(4, '0')}`;
}

function openEmployeeModal() {
  document.getElementById('employeeModal').classList.remove('hidden');
  resetEmpForm();
  renderEmployeeTable();
}

function closeEmployeeModal() {
  document.getElementById('employeeModal').classList.add('hidden');
}

function renderEmployeeTable() {
  const tbody = document.getElementById('empTableBody');
  tbody.innerHTML = '';
  document.getElementById('empCountBadge').innerText = `Tổng số: ${appData.employees.length} nhân sự`;

  // Reset checkbox header
  const selectAllCb = document.getElementById('empSelectAll');
  if (selectAllCb) selectAllCb.checked = false;
  _updateEmpBulkDeleteBtn();

  appData.employees.forEach(emp => {
    const empTasks = appData.tasks.filter(t => t.empId === emp.id);
    const scores = calculateEmployeeMonthlyScores(emp.id, 2026);
    const currentMonthScore = scores[10] || 100;

    const tr = document.createElement('tr');
    tr.className = 'hover:bg-slate-50 transition';
    tr.innerHTML = `
      <td class="p-2 text-center">
        <input type="checkbox" class="emp-cb w-3.5 h-3.5 cursor-pointer accent-rose-500" data-id="${emp.id}" onchange="_onEmpCheckboxChange()">
      </td>
      <td class="p-3 text-center font-bold text-indigo-700">${emp.id}</td>
      <td class="p-3 font-bold text-slate-800">${emp.name}</td>
      <td class="p-3 text-slate-600">${emp.dept || '-'}</td>
      <td class="p-3 text-center font-semibold text-slate-700">${empTasks.length} CV</td>
      <td class="p-3 text-center font-bold ${currentMonthScore >= 100 ? 'text-emerald-600' : 'text-rose-600'}">${currentMonthScore} đ</td>
      <td class="p-3 text-center space-x-2">
        <button onclick="viewEmployeeTasks('${emp.id}')" class="px-2 py-1 text-[11px] font-medium rounded bg-sky-50 text-sky-700 hover:bg-sky-100 transition"><i class="fa-solid fa-eye"></i> Việc</button>
        <button onclick="editEmployee('${emp.id}')" class="px-2 py-1 text-[11px] font-medium rounded bg-indigo-50 text-indigo-700 hover:bg-indigo-100 transition"><i class="fa-solid fa-pen"></i></button>
        <button onclick="deleteEmployee('${emp.id}')" class="px-2 py-1 text-[11px] font-medium rounded bg-rose-50 text-rose-700 hover:bg-rose-100 transition"><i class="fa-solid fa-trash"></i></button>
      </td>
    `;
    tbody.appendChild(tr);
  });

  populateEmployeeSelects();
}

function populateEmployeeSelects() {
  const filterSelect = document.getElementById('filterEmployee');
  const taskEmpSelect = document.getElementById('taskEmpId');
  const empDatalist = document.getElementById('employeeDatalist');
  const empSearchInput = document.getElementById('filterEmployeeSearch');

  const curFilterVal = filterSelect ? filterSelect.value : 'ALL';
  const curTaskEmpVal = taskEmpSelect ? taskEmpSelect.value : '';

  if (filterSelect) filterSelect.innerHTML = '<option value="ALL">-- Tất cả nhân sự --</option>';
  if (taskEmpSelect) taskEmpSelect.innerHTML = '';
  if (empDatalist) empDatalist.innerHTML = '<option value="-- Tất cả nhân sự --"></option>';

  appData.employees.forEach(emp => {
    if (filterSelect) {
      const opt1 = document.createElement('option');
      opt1.value = emp.id;
      opt1.textContent = `${emp.name} (${emp.id} - ${emp.dept})`;
      filterSelect.appendChild(opt1);
    }

    if (empDatalist) {
      const dOpt = document.createElement('option');
      dOpt.value = `${emp.name} (${emp.id})`;
      empDatalist.appendChild(dOpt);
    }

    if (taskEmpSelect) {
      const opt2 = document.createElement('option');
      opt2.value = emp.id;
      opt2.textContent = `${emp.name} (${emp.dept})`;
      taskEmpSelect.appendChild(opt2);
    }
  });

  if (filterSelect) filterSelect.value = curFilterVal;
  if (taskEmpSelect && curTaskEmpVal) taskEmpSelect.value = curTaskEmpVal;

  if (empSearchInput) {
    if (!curFilterVal || curFilterVal === 'ALL') {
      empSearchInput.value = '';
    } else {
      const match = appData.employees.find(e => e.id === curFilterVal);
      if (match) empSearchInput.value = `${match.name} (${match.id})`;
    }
  }
}

function handleEmployeeSearchInputChange(val) {
  const v = (val || '').trim().toLowerCase();
  const select = document.getElementById('filterEmployee');
  if (!v || v === '-- tất cả nhân sự --' || v === 'all') {
    if (select) select.value = 'ALL';
    viewState.filterEmp = 'ALL';
    const input = document.getElementById('filterEmployeeSearch');
    if (input) input.value = '';
    applyFilters();
    return;
  }
  const match = (appData.employees || []).find(e => 
    e.id.toLowerCase() === v ||
    e.name.toLowerCase() === v ||
    `${e.name} (${e.id})`.toLowerCase() === v ||
    `${e.id} - ${e.name}`.toLowerCase() === v ||
    e.name.toLowerCase().includes(v) ||
    e.id.toLowerCase().includes(v)
  );
  if (match) {
    if (select) select.value = match.id;
    viewState.filterEmp = match.id;
    const input = document.getElementById('filterEmployeeSearch');
    if (input) input.value = `${match.name} (${match.id})`;
    applyFilters();
  }
}

function handleEmployeeSearchInputLive(val) {
  if (!val || !val.trim()) {
    const select = document.getElementById('filterEmployee');
    if (select && select.value !== 'ALL') {
      select.value = 'ALL';
      viewState.filterEmp = 'ALL';
      applyFilters();
    }
  }
}

function clearEmployeeFilterInput() {
  const input = document.getElementById('filterEmployeeSearch');
  if (input) input.value = '';
  const select = document.getElementById('filterEmployee');
  if (select) select.value = 'ALL';
  viewState.filterEmp = 'ALL';
  applyFilters();
}

function handleSaveEmployee(e) {
  e.preventDefault();
  const editId = document.getElementById('empEditId').value;
  let code = document.getElementById('empCode').value.trim().toUpperCase();
  const name = document.getElementById('empName').value.trim();
  const dept = document.getElementById('empDept').value.trim();

  if (!code) code = generateNextEmpId();
  if (!name) return;

  if (editId) {
    const emp = appData.employees.find(x => x.id === editId);
    if (emp) {
      emp.id = code;
      emp.name = name;
      emp.dept = dept;
      appData.tasks.forEach(t => {
        if (t.empId === editId) {
          t.empId = code;
          t.empName = name;
        }
      });
    }
  } else {
    if (appData.employees.some(x => x.id === code)) {
      alert(`Mã nhân viên "${code}" đã tồn tại! Hệ thống sẽ tự động gán mã mới.`);
      code = generateNextEmpId();
    }
    appData.employees.push({ id: code, name, dept });
  }

  saveDataToStorage();
  resetEmpForm();
  renderEmployeeTable();
  renderUserDropdown();
  applyFilters();
}

function editEmployee(id) {
  const emp = (appData.employees || []).find(x => x.id === id);
  if (!emp) {
    showToast('⚠️ Không tìm thấy thông tin nhân viên', 'warning');
    return;
  }
  document.getElementById('editEmpOriginalId').value = emp.id;
  document.getElementById('editEmpCode').value = emp.id;
  document.getElementById('editEmpName').value = emp.name;
  document.getElementById('editEmpDept').value = emp.dept || '';

  const modal = document.getElementById('editEmployeeModal');
  if (modal) {
    modal.classList.remove('hidden');
    setTimeout(() => {
      const nameInput = document.getElementById('editEmpName');
      if (nameInput) nameInput.focus();
    }, 100);
  }
}

function closeEditEmployeeModal() {
  const modal = document.getElementById('editEmployeeModal');
  if (modal) modal.classList.add('hidden');
}

function handleSaveEditEmployee(e) {
  e.preventDefault();
  const oldId = document.getElementById('editEmpOriginalId').value;
  const newCode = document.getElementById('editEmpCode').value.trim().toUpperCase();
  const newName = document.getElementById('editEmpName').value.trim();
  const newDept = document.getElementById('editEmpDept').value.trim();

  if (!newName) {
    showToast('⚠️ Vui lòng nhập họ và tên nhân viên!', 'warning');
    return;
  }

  const emp = (appData.employees || []).find(x => x.id === oldId);
  if (!emp) return;

  // Kiểm tra trùng mã nếu đổi sang mã khác
  if (newCode !== oldId && (appData.employees || []).some(x => x.id === newCode)) {
    showToast(`⚠️ Mã nhân viên "${newCode}" đã tồn tại! Vui lòng chọn mã khác.`, 'warning');
    return;
  }

  // Cập nhật thông tin nhân viên
  emp.id = newCode;
  emp.name = newName;
  emp.dept = newDept;

  // Đồng bộ sang toàn bộ công việc của nhân viên này
  (appData.tasks || []).forEach(t => {
    if (t.empId === oldId) {
      t.empId = newCode;
      t.empName = newName;
    }
  });

  saveDataToStorage();
  closeEditEmployeeModal();
  renderEmployeeTable();
  renderUserDropdown();
  populateEmployeeSelects();
  applyFilters();
  showToast(`✅ Đã cập nhật nhân viên: ${newName} (${newCode})`, 'success');
}

function resetEmpForm() {
  document.getElementById('empEditId').value = '';
  const codeInput = document.getElementById('empCode');
  codeInput.value = generateNextEmpId();
  codeInput.readOnly = true;
  document.getElementById('empName').value = '';
  document.getElementById('empDept').value = '';

  document.getElementById('empFormTitle').innerText = 'Thêm Nhân Viên Mới';
  document.getElementById('empBtnText').innerText = 'Thêm NV';
  document.getElementById('empCancelEditBtn').classList.add('hidden');
}

function deleteEmployee(id) {
  const emp = appData.employees.find(x => x.id === id);
  if (!emp) return;
  if (!confirm(`Bạn có chắc chắn muốn xóa nhân viên "${emp.name}" (${emp.id})?`)) return;
  appData.employees = appData.employees.filter(x => x.id !== id);
  saveDataToStorage();
  renderEmployeeTable();
  renderUserDropdown();
  applyFilters();
}

function viewEmployeeTasks(empId) {
  closeEmployeeModal();
  viewState.filterEmp = empId;
  document.getElementById('filterEmployee').value = empId;
  applyFilters();
}

// ================= QUẢN LÝ DỰ ÁN & CÔNG VIỆC CHÍNH (PROJECT MANAGEMENT) =================

// ================= QUẢN LÝ DỰ ÁN & CÔNG VIỆC CHÍNH (PROJECT MANAGEMENT) =================

// Đảm bảo appData.projects luôn được khởi tạo và đồng bộ với các công việc thật sự
function ensureProjectsInitialized() {
  if (!Array.isArray(appData.projects)) {
    appData.projects = [];
  }

  // Dọn sạch các project rác bị sinh nhầm từ task ID riêng lẻ trong các phiên bản trước:
  // Một project chỉ hợp lệ nếu:
  // (a) Có ít nhất 1 task trỏ đến nó qua mainTaskId, HOẶC
  // (b) Nó không phải là một task riêng lẻ bị sao chép nhầm
  const activeMainTaskIds = new Set(
    (appData.tasks || []).map(t => t.mainTaskId).filter(Boolean)
  );
  const standaloneTaskIds = new Set(
    (appData.tasks || []).filter(t => !t.mainTaskId).map(t => t.id)
  );

  appData.projects = appData.projects.filter(p => {
    if (!p || !p.id) return false;
    if (activeMainTaskIds.has(p.id)) return true;
    if (standaloneTaskIds.has(p.id)) return false;
    return true;
  });

  const projMap = new Map();
  appData.projects.forEach(p => {
    if (p && p.id) projMap.set(p.id, p);
  });

  // Tự động gom các mã mainTaskId có thật từ tasks vào danh sách projects nếu chưa có
  (appData.tasks || []).forEach(t => {
    if (t.mainTaskId && t.mainTaskId.trim() && !projMap.has(t.mainTaskId)) {
      const newP = {
        id: t.mainTaskId,
        title: t.mainTaskTitle || t.mainTaskId
      };
      appData.projects.push(newP);
      projMap.set(t.mainTaskId, newP);
    }
  });
}

// Lấy danh sách công việc chính / dự án duy nhất (CHỈ dự án thật, KHÔNG lấy việc riêng lẻ)
function getUniqueMainTasks() {
  ensureProjectsInitialized();
  const map = new Map();

  // 1. Nạp từ appData.projects trước (kể cả dự án chưa có công việc con)
  (appData.projects || []).forEach(p => {
    if (p && p.id && String(p.id).trim()) {
      map.set(p.id, { id: p.id, title: p.title || p.id, subtasks: [] });
    }
  });

  // 2. Gom các công việc con vào đúng dự án mẹ (CHỈ khi t.mainTaskId có giá trị và không rỗng)
  (appData.tasks || []).forEach(t => {
    if (t.mainTaskId && String(t.mainTaskId).trim()) {
      const id = String(t.mainTaskId).trim();
      const title = t.mainTaskTitle || (map.has(id) ? map.get(id).title : id);
      if (!map.has(id)) {
        map.set(id, { id, title, subtasks: [] });
      }
      map.get(id).subtasks.push(t);
    }
  });

  return Array.from(map.values());
}

// Mở modal Quản lý dự án
function openProjectManageModal() {
  const modal = document.getElementById('projectManageModal');
  if (!modal) return;
  modal.classList.remove('hidden');
  suggestNextProjectCode();
  const searchInput = document.getElementById('projectSearchInput');
  if (searchInput) searchInput.value = '';
  renderProjectManageList();
  updateSelectedProjectsUI();
}

// Đóng modal Quản lý dự án
function closeProjectManageModal() {
  const modal = document.getElementById('projectManageModal');
  if (modal) modal.classList.add('hidden');
}

// Gợi ý mã dự án tự động tiếp theo theo năm
function suggestNextProjectCode() {
  const codeEl = document.getElementById('newProjectCode');
  if (!codeEl) return;
  const year = '2026';
  let maxNum = 0;
  const allIds = [
    ...(appData.projects || []).map(p => p.id),
    ...(appData.tasks || []).map(t => t.id),
    ...(appData.tasks || []).map(t => t.mainTaskId).filter(Boolean)
  ];
  allIds.forEach(id => {
    if (!id) return;
    const m = id.match(/CV-2026-(\d+)/i) || id.match(/DA-2026-(\d+)/i);
    if (m) {
      const n = parseInt(m[1], 10);
      if (n > maxNum) maxNum = n;
    }
  });
  const nextNum = maxNum + 1;
  const nextCode = `CV-${year}-${String(nextNum).padStart(4, '0')}`;
  codeEl.value = nextCode;
}

// Thêm dự án mới
function handleAddNewProject(e) {
  if (e) e.preventDefault();
  const codeEl = document.getElementById('newProjectCode');
  const titleEl = document.getElementById('newProjectTitle');
  if (!codeEl || !titleEl) return;

  const code = codeEl.value.trim().toUpperCase();
  const title = titleEl.value.trim();

  if (!code) {
    alert('Vui lòng nhập mã dự án!');
    codeEl.focus();
    return;
  }
  if (!title) {
    alert('Vui lòng nhập tên dự án!');
    titleEl.focus();
    return;
  }

  ensureProjectsInitialized();
  if (appData.projects.some(p => p.id.toUpperCase() === code)) {
    alert(`Mã dự án [${code}] đã tồn tại trong hệ thống! Vui lòng chọn mã khác.`);
    codeEl.focus();
    return;
  }

  appData.projects.push({ id: code, title: title });
  saveDataToStorage();

  titleEl.value = '';
  suggestNextProjectCode();
  renderProjectManageList();
  renderFilterMainTasksSelect();
  renderParentSearchList();
  showToast(`Đã thêm dự án mới: [${code}] ${title}`);
}

// Render bảng danh sách dự án trong modal Quản lý dự án (Hỗ trợ checkbox chọn nhiều)
function renderProjectManageList(keyword = '') {
  const tbody = document.getElementById('projectManageTableBody');
  const badge = document.getElementById('projectTotalBadge');
  if (!tbody) return;

  ensureProjectsInitialized();
  const mainTasks = getUniqueMainTasks();
  const kw = (keyword || '').toLowerCase().trim();

  const filtered = mainTasks.filter(mt => {
    if (!kw) return true;
    return (mt.id || '').toLowerCase().includes(kw) || (mt.title || '').toLowerCase().includes(kw);
  });

  if (badge) badge.innerText = `${mainTasks.length} dự án`;

  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" class="p-6 text-center text-slate-400 italic">
          <i class="fa-solid fa-folder-open text-2xl mb-1 block text-slate-300"></i>
          Không tìm thấy dự án nào phù hợp
        </td>
      </tr>
    `;
    updateSelectedProjectsUI();
    return;
  }

  let html = '';
  filtered.forEach((mt, idx) => {
    const subCount = mt.subtasks ? mt.subtasks.length : 0;
    const completedCount = mt.subtasks ? mt.subtasks.filter(t => isTaskCompleted(t)).length : 0;
    const percent = subCount > 0 ? Math.round((completedCount / subCount) * 100) : 0;

    let progressHtml = '';
    if (subCount === 0) {
      progressHtml = '<span class="text-[11px] text-slate-400 italic">0 việc con</span>';
    } else {
      progressHtml = `
        <div class="space-y-1">
          <div class="flex items-center justify-between text-[10px] font-semibold text-slate-600">
            <span>${completedCount}/${subCount} việc</span>
            <span class="${percent === 100 ? 'text-emerald-600 font-bold' : 'text-sky-700'}">${percent}%</span>
          </div>
          <div class="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
            <div class="${percent === 100 ? 'bg-emerald-500' : 'bg-sky-500'} h-full rounded-full transition-all duration-300" style="width: ${percent}%;"></div>
          </div>
        </div>
      `;
    }

    html += `
      <tr class="hover:bg-slate-50 transition">
        <td class="p-2.5 text-center">
          <input type="checkbox" class="project-item-cb w-3.5 h-3.5 rounded text-sky-600 border-slate-300 cursor-pointer" value="${mt.id}" onchange="updateSelectedProjectsUI()">
        </td>
        <td class="p-2.5 text-center font-medium text-slate-500">${idx + 1}</td>
        <td class="p-2.5">
          <span class="inline-flex items-center gap-1 font-bold text-sky-900 bg-sky-50 px-2 py-0.5 rounded border border-sky-200 font-mono text-[11px]">
            <i class="fa-solid fa-diagram-project text-sky-600 text-[10px]"></i>
            ${mt.id}
          </span>
        </td>
        <td class="p-2.5 font-bold text-slate-800 text-xs">
          ${mt.title}
        </td>
        <td class="p-2.5 text-center">
          ${progressHtml}
        </td>
        <td class="p-2.5 text-center">
          <div class="flex items-center justify-center gap-1.5">
            <button type="button" onclick="filterByMainTask('${mt.id}'); closeProjectManageModal();" class="px-2 py-1 text-[11px] font-semibold rounded bg-sky-50 hover:bg-sky-100 text-sky-700 border border-sky-200 transition" title="Lọc xem các công việc của dự án này">
              <i class="fa-solid fa-filter text-[10px]"></i> Xem
            </button>
            <button type="button" onclick="handleEditProjectTitle('${mt.id}')" class="px-2 py-1 text-[11px] font-semibold rounded bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 transition" title="Đổi tên dự án">
              <i class="fa-solid fa-pen text-[10px]"></i> Sửa
            </button>
            <button type="button" onclick="handleDeleteProject('${mt.id}')" class="px-2 py-1 text-[11px] font-semibold rounded bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 transition" title="Xóa dự án khỏi hệ thống">
              <i class="fa-solid fa-trash text-[10px]"></i> Xóa
            </button>
          </div>
        </td>
      </tr>
    `;
  });

  tbody.innerHTML = html;
  updateSelectedProjectsUI();
}

// Bật / tắt tất cả checkbox dự án
function toggleSelectAllProjects(checked) {
  const cbs = document.querySelectorAll('.project-item-cb');
  cbs.forEach(cb => { cb.checked = checked; });
  updateSelectedProjectsUI();
}

// Cập nhật giao diện khi chọn/bỏ chọn checkbox dự án
function updateSelectedProjectsUI() {
  const checkedBoxes = Array.from(document.querySelectorAll('.project-item-cb:checked'));
  const count = checkedBoxes.length;
  const btn = document.getElementById('btnBulkDeleteProjects');
  const countSpan = document.getElementById('selectedProjectCount');
  const selectAll = document.getElementById('selectAllProjects');

  if (countSpan) countSpan.innerText = count;
  if (btn) {
    if (count > 0) btn.classList.remove('hidden');
    else btn.classList.add('hidden');
  }

  const allCbs = document.querySelectorAll('.project-item-cb');
  if (selectAll && allCbs.length > 0) {
    selectAll.checked = (count === allCbs.length);
    selectAll.indeterminate = (count > 0 && count < allCbs.length);
  }
}

// Xóa nhanh nhiều dự án cùng lúc
function handleBulkDeleteProjects() {
  const checkedBoxes = Array.from(document.querySelectorAll('.project-item-cb:checked'));
  const selectedIds = checkedBoxes.map(cb => cb.value);
  if (selectedIds.length === 0) return;

  const relatedSubtasks = (appData.tasks || []).filter(t => selectedIds.includes(t.mainTaskId));
  let confirmMsg = `Bạn có chắc chắn muốn xóa ${selectedIds.length} dự án đã chọn?`;
  if (relatedSubtasks.length > 0) {
    confirmMsg += `\n\nToàn bộ ${relatedSubtasks.length} công việc con thuộc các dự án này sẽ được giữ lại an toàn và chuyển thành Việc Riêng Lẻ.`;
  }

  if (!confirm(confirmMsg)) return;

  // Hủy liên kết trên các công việc con
  (appData.tasks || []).forEach(t => {
    if (selectedIds.includes(t.mainTaskId)) {
      t.mainTaskId = '';
      t.mainTaskTitle = '';
    }
  });

  // Xóa khỏi appData.projects
  appData.projects = (appData.projects || []).filter(p => !selectedIds.includes(p.id));

  saveDataToStorage();
  renderProjectManageList();
  renderFilterMainTasksSelect();
  renderParentSearchList();
  renderMainTable();
  updateSelectedProjectsUI();
  showToast(`Đã xóa thành công ${selectedIds.length} dự án!`);
}

// Đổi tên dự án
function handleEditProjectTitle(projectId) {
  if (!projectId) return;
  ensureProjectsInitialized();
  const project = (appData.projects || []).find(p => p.id === projectId);
  const currentTitle = project ? project.title : (appData.tasks.find(t => t.mainTaskId === projectId)?.mainTaskTitle || projectId);
  const newTitle = prompt(`Nhập tên mới cho dự án [${projectId}]:`, currentTitle);
  if (!newTitle || !newTitle.trim() || newTitle.trim() === currentTitle) return;

  const trimmed = newTitle.trim();
  const target = appData.projects.find(p => p.id === projectId);
  if (target) {
    target.title = trimmed;
  } else {
    appData.projects.push({ id: projectId, title: trimmed });
  }

  // Cập nhật toàn bộ task thuộc dự án này
  appData.tasks.forEach(t => {
    if (t.mainTaskId === projectId) {
      t.mainTaskTitle = trimmed;
    }
  });

  saveDataToStorage();
  renderProjectManageList();
  renderFilterMainTasksSelect();
  renderParentSearchList();
  renderMainTable();
  showToast(`Đã đổi tên dự án [${projectId}] thành "${trimmed}"!`);
}

// Xóa 1 dự án (Hỗ trợ hủy liên kết hoặc xóa công việc con an toàn)
function handleDeleteProject(projectId) {
  if (!projectId) return;
  ensureProjectsInitialized();
  const project = (appData.projects || []).find(p => p.id === projectId) || { id: projectId, title: projectId };
  const subtasks = (appData.tasks || []).filter(t => t.mainTaskId === projectId);

  if (subtasks.length === 0) {
    if (!confirm(`Bạn có chắc muốn xóa dự án [${project.id}] "${project.title}"?`)) return;
    appData.projects = (appData.projects || []).filter(p => p.id !== projectId);
    saveDataToStorage();
    renderProjectManageList();
    renderFilterMainTasksSelect();
    renderParentSearchList();
    renderMainTable();
    showToast(`Đã xóa dự án [${project.id}]!`);
    return;
  }

  // Dự án đang có công việc con: Cảnh báo và cho lựa chọn
  const promptMsg = `Dự án [${project.id}] "${project.title}" đang có ${subtasks.length} công việc con.\n\n` +
    `LỰA CHỌN XÓA:\n` +
    `• Nhấn [OK]: GIỮ LẠI các công việc (chuyển thành việc riêng lẻ độc lập) và xóa dự án.\n` +
    `• Nhấn [Cancel]: Hủy bỏ thao tác (không xóa).`;

  if (confirm(promptMsg)) {
    // Chuyển các việc con thành việc riêng lẻ
    appData.tasks.forEach(t => {
      if (t.mainTaskId === projectId) {
        t.mainTaskId = '';
        t.mainTaskTitle = '';
      }
    });
    appData.projects = (appData.projects || []).filter(p => p.id !== projectId);
    saveDataToStorage();
    renderProjectManageList();
    renderFilterMainTasksSelect();
    renderParentSearchList();
    renderMainTable();
    showToast(`Đã xóa dự án [${project.id}], ${subtasks.length} công việc con đã chuyển thành việc riêng lẻ.`);
  }
}

// ================= LỌC NHANH THEO THẺ KPI =================
function filterByKpiStatus(targetStatus) {
  const sel = document.getElementById('filterStatus');
  // Nếu đang lọc đúng status đó -> toggle quay về CHUA_HOAN_THANH (mặc định)
  if (viewState.filterStatus === targetStatus) {
    viewState.filterStatus = 'CHUA_HOAN_THANH';
  } else {
    viewState.filterStatus = targetStatus;
  }
  if (sel) sel.value = viewState.filterStatus;

  // Nếu người dùng click vào thẻ TỔNG SỐ (ALL) -> tự động mở rộng hiển thị 100% toàn bộ công việc
  if (viewState.filterStatus === 'ALL') {
    const mInput = document.getElementById('filterMonth');
    if (mInput) mInput.value = '';
    viewState.filterMonth = '';
    fitTimelineToTaskDates();
    return;
  }

  applyFilters();
}

function highlightActiveKpiCard() {
  const cards = {
    'ALL': document.getElementById('cardKpiTotal'),
    'DANG_LAM': document.getElementById('cardKpiInProgress'),
    'Hoàn thành': document.getElementById('cardKpiOnTime'),
    'Hoàn thành trễ': document.getElementById('cardKpiLate'),
    'Tạm dừng': document.getElementById('cardKpiPaused'),
    'QUA_HAN': document.getElementById('cardKpiOverdue')
  };

  const activeStatus = viewState.filterStatus;

  Object.entries(cards).forEach(([st, card]) => {
    if (!card) return;
    if (st === activeStatus) {
      card.classList.add('ring-2', 'ring-brand-500', 'bg-sky-50/50', 'shadow-md');
    } else {
      card.classList.remove('ring-2', 'ring-brand-500', 'bg-sky-50/50', 'shadow-md');
    }
  });
}

// ================= BỘ LỌC DỰ ÁN & CĂN CHỈNH BIỂU ĐỒ TỰ ĐỘNG =================
function renderFilterMainTasksSelect() {
  const select = document.getElementById('filterMainTask');
  if (!select) return;
  const curVal = viewState.filterMainTask || 'ALL';
  const mainTasks = getUniqueMainTasks();

  let html = '<option value="ALL">-- Tất cả dự án --</option>';
  html += `<option value="__NO_PROJECT__" ${curVal === '__NO_PROJECT__' ? 'selected' : ''}>🍃 Chưa thuộc dự án nào (Việc riêng lẻ)</option>`;
  mainTasks.forEach(mt => {
    const isSel = mt.id === curVal ? 'selected' : '';
    html += `<option value="${mt.id}" ${isSel}>[${mt.id}] ${mt.title} (${mt.subtasks.length} việc)</option>`;
  });
  select.innerHTML = html;
  select.value = curVal;
}

function handleMainTaskFilterChange() {
  const select = document.getElementById('filterMainTask');
  viewState.filterMainTask = select ? select.value : 'ALL';
  applyFilters();
  if (viewState.filterMainTask !== 'ALL') {
    fitTimelineToTaskDates();
  }
}

function clearMainTaskFilterInput() {
  const select = document.getElementById('filterMainTask');
  if (select) select.value = 'ALL';
  viewState.filterMainTask = 'ALL';
  applyFilters();
}

function filterByMainTask(mainTaskId) {
  if (!mainTaskId) return;
  if (viewState.filterMainTask === mainTaskId) {
    viewState.filterMainTask = 'ALL';
  } else {
    viewState.filterMainTask = mainTaskId;
  }
  const select = document.getElementById('filterMainTask');
  if (select) select.value = viewState.filterMainTask;
  const searchInput = document.getElementById('filterMainTaskSearch');
  if (searchInput) {
    if (viewState.filterMainTask === 'ALL') {
      searchInput.value = '';
    } else {
      const match = getUniqueMainTasks().find(m => m.id === viewState.filterMainTask);
      searchInput.value = match ? `[${match.id}] ${match.title}` : viewState.filterMainTask;
    }
  }
  applyFilters();
  if (viewState.filterMainTask !== 'ALL') {
    fitTimelineToTaskDates();
  }
}

function clearProjectFilter() {
  clearMainTaskFilterInput();
}

// ================= QUẢN LÝ CÔNG VIỆC (CRUD & SUBTASKS) =================
function renderSupportEmpCheckboxes(selectedIds = []) {
  const container = document.getElementById('supportEmpContainer');
  if (!container) return;
  const leadEmpId = document.getElementById('taskEmpId') ? document.getElementById('taskEmpId').value : '';
  container.innerHTML = '';

  const availableEmps = (appData.employees || []).filter(e => e.id !== leadEmpId);
  if (availableEmps.length === 0) {
    container.innerHTML = '<span class="text-[11px] text-slate-400 italic">Không có nhân sự khác</span>';
    updateSupportEmpCountBadge();
    return;
  }

  availableEmps.forEach(emp => {
    const isChecked = Array.isArray(selectedIds) && selectedIds.includes(emp.id);
    const label = document.createElement('label');
    label.className = `inline-flex items-center gap-1.5 px-2 py-1 rounded text-xs border cursor-pointer transition select-none ${
      isChecked ? 'bg-indigo-50 border-indigo-300 text-indigo-900 font-semibold' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'
    }`;
    label.innerHTML = `
      <input type="checkbox" value="${emp.id}" data-name="${emp.name}" class="support-emp-cb w-3.5 h-3.5 rounded text-indigo-600 border-slate-300 cursor-pointer" ${isChecked ? 'checked' : ''} onchange="_onSupportEmpCheckboxChange(this)">
      <span>${emp.name}</span>
      <span class="text-[10px] text-slate-400">(${emp.id})</span>
    `;
    container.appendChild(label);
  });
  updateSupportEmpCountBadge();
}

function _onSupportEmpCheckboxChange(cb) {
  const label = cb.closest('label');
  if (!label) return;
  if (cb.checked) {
    label.className = 'inline-flex items-center gap-1.5 px-2 py-1 rounded text-xs border cursor-pointer transition select-none bg-indigo-50 border-indigo-300 text-indigo-900 font-semibold';
  } else {
    label.className = 'inline-flex items-center gap-1.5 px-2 py-1 rounded text-xs border cursor-pointer transition select-none bg-white border-slate-200 text-slate-700 hover:bg-slate-100';
  }
  updateSupportEmpCountBadge();
}

function _updateSupportEmpOptions() {
  const checkedBoxes = Array.from(document.querySelectorAll('.support-emp-cb:checked'));
  const currentSelectedIds = checkedBoxes.map(cb => cb.value);
  renderSupportEmpCheckboxes(currentSelectedIds);
}

// ================= CHỌN VÀ LIÊN KẾT DỰ ÁN MẸ / VIỆC RIÊNG LẺ / TỰ LÀM DỰ ÁN =================

/**
 * Lấy toàn bộ danh sách các đối tượng có thể làm Dự án mẹ:
 * 1. Các dự án hiện có (gom từ mainTaskId)
 * 2. Toàn bộ các công việc trong hệ thống (loại trừ chính công việc đang sửa)
 */
function getAvailableParentTasks(currentTaskId = null) {
  const items = [];
  const seenIds = new Set();

  // 1. Gom các dự án mẹ hiện có (từ appData.projects và appData.tasks)
  ensureProjectsInitialized();
  const existingProjectsMap = new Map();
  (appData.projects || []).forEach(p => {
    if (p && p.id) {
      existingProjectsMap.set(p.id, {
        id: p.id,
        title: p.title || p.id,
        count: 0,
        emps: new Set()
      });
    }
  });

  (appData.tasks || []).forEach(t => {
    if (t.mainTaskId) {
      if (!existingProjectsMap.has(t.mainTaskId)) {
        existingProjectsMap.set(t.mainTaskId, {
          id: t.mainTaskId,
          title: t.mainTaskTitle || t.title || t.mainTaskId,
          count: 0,
          emps: new Set()
        });
      }
      const p = existingProjectsMap.get(t.mainTaskId);
      p.count++;
      if (t.empName) p.emps.add(t.empName);
    }
  });

  existingProjectsMap.forEach(p => {
    if (currentTaskId && p.id === currentTaskId) return;
    seenIds.add(p.id);
    const empArr = Array.from(p.emps);
    const empStr = empArr.length > 0 ? ` • 👤 ${empArr.slice(0, 3).join(', ')}${empArr.length > 3 ? '...' : ''}` : '';
    items.push({
      id: p.id,
      title: p.title,
      badge: 'Dự án',
      badgeColor: 'bg-indigo-100 text-indigo-800 border-indigo-200',
      subtext: `${p.count} việc${empStr}`,
      searchStr: `${p.id} ${p.title} ${empArr.join(' ')}`.toLowerCase()
    });
  });

  // CHỈ hiển thị Dự án thực thụ - KHÔNG hiển thị các công việc thường (tránh rối danh sách)
  // Công việc riêng lẻ không phải dự án không được xuất hiện trong danh sách này

  return items;
}

/**
 * Cập nhật thẻ trạng thái dự án hiện tại (Selected Card) trong taskModal
 */
function updateParentSelectedCard(mode, id = '', title = '') {
  const badge = document.getElementById('parentSelectedBadge');
  const titleEl = document.getElementById('parentSelectedTitle');
  const newInputs = document.getElementById('parentNewInputs');
  const mainCodeInput = document.getElementById('taskMainCode');
  const mainTitleInput = document.getElementById('taskMainTitle');

  if (mode === '__STANDALONE__') {
    if (badge) {
      badge.innerText = '🍃 Riêng lẻ';
      badge.className = 'px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-700 border border-slate-300 shrink-0';
    }
    if (titleEl) {
      titleEl.innerHTML = '<span class="font-bold text-slate-700 text-xs">Việc riêng lẻ (Không thuộc dự án nào)</span>';
    }
    if (newInputs) newInputs.classList.add('hidden');
    if (mainCodeInput) mainCodeInput.value = '';
    if (mainTitleInput) mainTitleInput.value = '';
  } else if (mode === '__SELF__') {
    const curTaskId = document.getElementById('taskId') ? document.getElementById('taskId').value : '';
    const curDetail = document.getElementById('taskDetail') ? document.getElementById('taskDetail').value.trim() : '';
    if (badge) {
      badge.innerText = '⭐ Tự làm Dự án';
      badge.className = 'px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-300 shrink-0';
    }
    if (titleEl) {
      titleEl.innerHTML = `<span class="font-bold text-amber-800 text-xs">Tự làm Dự Án Mẹ độc lập ${curTaskId ? `[${curTaskId}]` : ''}</span>`;
    }
    if (newInputs) newInputs.classList.add('hidden');
    if (mainCodeInput) mainCodeInput.value = curTaskId || '';
    if (mainTitleInput) mainTitleInput.value = curDetail || (curTaskId ? `Dự án ${curTaskId}` : '');
  } else if (mode === '__NEW__') {
    if (badge) {
      badge.innerText = '✨ Dự án mới';
      badge.className = 'px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300 shrink-0';
    }
    if (titleEl) {
      titleEl.innerHTML = '<span class="font-bold text-emerald-800 text-xs">Tạo Mã Dự Án Mẹ Mới Hoàn Toàn (Nhập bên dưới)</span>';
    }
    if (newInputs) newInputs.classList.remove('hidden');
    if (mainCodeInput) {
      mainCodeInput.readOnly = false;
      mainCodeInput.classList.remove('bg-slate-100');
      if (!mainCodeInput.value || !mainCodeInput.value.startsWith('CV-')) {
        const curYear = new Date().getFullYear();
        mainCodeInput.value = generateNextTaskId(curYear);
      }
    }
    if (mainTitleInput) {
      mainTitleInput.readOnly = false;
      mainTitleInput.classList.remove('bg-slate-100');
    }
  } else {
    // Mode là mã dự án/công việc cụ thể
    if (badge) {
      badge.innerText = '📁 Thuộc DA';
      badge.className = 'px-1.5 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800 border border-sky-200 shrink-0';
    }
    const safeT = String(title || id).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    if (titleEl) {
      titleEl.innerHTML = `<span class="px-1 py-0.5 rounded bg-sky-100 text-sky-800 font-bold text-[10px] mr-1 border border-sky-200">${id}</span><span class="font-bold text-slate-800 text-xs truncate" title="${safeT}">${safeT}</span>`;
    }
    if (newInputs) newInputs.classList.add('hidden');
    if (mainCodeInput) {
      mainCodeInput.value = id;
      mainCodeInput.readOnly = true;
      mainCodeInput.classList.add('bg-slate-100');
    }
    if (mainTitleInput) {
      mainTitleInput.value = title || id;
      mainTitleInput.readOnly = true;
      mainTitleInput.classList.add('bg-slate-100');
    }
  }
}

function setStandaloneProject() {
  const parentSelect = document.getElementById('taskParentSelect');
  if (parentSelect) parentSelect.value = '__STANDALONE__';
  updateParentSelectedCard('__STANDALONE__');
  toggleParentSearchList(false);
}

function setSelfAsProject() {
  const parentSelect = document.getElementById('taskParentSelect');
  if (parentSelect) parentSelect.value = '__SELF__';
  // Đồng bộ tên dự án mẹ = tên/nội dung của chính công việc này
  const curTaskId = document.getElementById('taskId') ? document.getElementById('taskId').value : '';
  const curDetail = document.getElementById('taskDetail') ? document.getElementById('taskDetail').value.trim() : '';
  const mainCodeInput = document.getElementById('taskMainCode');
  const mainTitleInput = document.getElementById('taskMainTitle');
  if (mainCodeInput) mainCodeInput.value = curTaskId || '';
  if (mainTitleInput) mainTitleInput.value = curDetail || (curTaskId ? `Dự án ${curTaskId}` : '');
  updateParentSelectedCard('__SELF__');
  toggleParentSearchList(false);
}

function selectParentTask(val) {
  const parentSelect = document.getElementById('taskParentSelect');
  if (parentSelect) parentSelect.value = val;

  if (val === '__STANDALONE__') {
    setStandaloneProject();
    return;
  }
  if (val === '__SELF__') {
    setSelfAsProject();
    return;
  }
  if (val === '__NEW__') {
    updateParentSelectedCard('__NEW__');
    toggleParentSearchList(false);
    return;
  }

  // Chọn mã ID cụ thể
  const currentTaskId = document.getElementById('taskId') ? document.getElementById('taskId').value : '';
  const avail = getAvailableParentTasks(currentTaskId);
  const found = avail.find(x => x.id === val);
  const title = found ? found.title : val;
  updateParentSelectedCard('CUSTOM', val, title);
  toggleParentSearchList(false);
}

function toggleParentSearchList(show) {
  const box = document.getElementById('parentSearchBox');
  if (!box) return;
  if (show !== undefined) {
    if (show) box.classList.remove('hidden');
    else box.classList.add('hidden');
  } else {
    box.classList.toggle('hidden');
  }

  if (!box.classList.contains('hidden')) {
    const currentTaskId = document.getElementById('taskId') ? document.getElementById('taskId').value : '';
    const curVal = document.getElementById('taskParentSelect') ? document.getElementById('taskParentSelect').value : '__STANDALONE__';
    const input = document.getElementById('taskParentSearchInput');
    const query = input ? input.value : '';
    renderParentTaskList(query, curVal);
    if (input) input.focus();
  }
}

function handleParentSearchFilter(val) {
  const curVal = document.getElementById('taskParentSelect') ? document.getElementById('taskParentSelect').value : '__STANDALONE__';
  renderParentTaskList(val, curVal);
}

function clearParentSearchFilter() {
  const input = document.getElementById('taskParentSearchInput');
  if (input) input.value = '';
  const curVal = document.getElementById('taskParentSelect') ? document.getElementById('taskParentSelect').value : '__STANDALONE__';
  renderParentTaskList('', curVal);
  if (input) input.focus();
}

function handleParentSelectChange() {
  const parentSelect = document.getElementById('taskParentSelect');
  const val = parentSelect ? parentSelect.value : '__STANDALONE__';
  selectParentTask(val);
}

// ================= CHỌN NHANH NHÂN VIÊN CHÍNH & PHỤ TRONG TASK MODAL =================

/**
 * Cập nhật datalist gợi ý cho ô tìm kiếm nhân viên chính
 */
function populateTaskEmpDatalist() {
  const datalist = document.getElementById('taskEmpDatalist');
  if (!datalist) return;
  datalist.innerHTML = '';
  (appData.employees || []).forEach(emp => {
    const opt = document.createElement('option');
    opt.value = `${emp.name} (${emp.id})`;
    datalist.appendChild(opt);
  });
}

/**
 * Xử lý khi người dùng gõ vào ô tìm kiếm nhân viên chính.
 * Tự động map sang select taskEmpId nếu tìm được match.
 */
function handleLeadEmpSearch(val) {
  const clearBtn = document.getElementById('taskEmpSearchClear');
  const badge = document.getElementById('taskEmpSelectedBadge');
  if (clearBtn) {
    if (val && val.trim()) clearBtn.classList.remove('hidden');
    else clearBtn.classList.add('hidden');
  }

  const v = (val || '').trim().toLowerCase();
  if (!v) {
    if (badge) badge.textContent = '';
    return;
  }

  const match = (appData.employees || []).find(e =>
    e.id.toLowerCase() === v ||
    e.name.toLowerCase() === v ||
    `${e.name} (${e.id})`.toLowerCase() === v ||
    e.name.toLowerCase().includes(v) ||
    e.id.toLowerCase().includes(v)
  );

  const select = document.getElementById('taskEmpId');
  if (match && select) {
    select.value = match.id;
    if (badge) badge.textContent = `✓ ${match.name}`;
    // Cập nhật lại nhân sự phụ (loại bỏ người chính mới chọn)
    const currentSupportIds = Array.from(document.querySelectorAll('.support-emp-cb:checked')).map(cb => cb.value);
    renderSupportEmpCheckboxes(currentSupportIds);
  } else {
    if (badge) badge.textContent = '';
  }
}

/**
 * Xử lý khi người dùng đổi select (dropdown) nhân viên chính.
 * Đồng bộ ngược lại ô tìm kiếm.
 */
function handleLeadEmpSelectChange(val) {
  const emp = (appData.employees || []).find(e => e.id === val);
  const searchInput = document.getElementById('taskEmpSearchInput');
  const badge = document.getElementById('taskEmpSelectedBadge');
  const clearBtn = document.getElementById('taskEmpSearchClear');
  if (emp) {
    if (searchInput) searchInput.value = `${emp.name} (${emp.id})`;
    if (badge) badge.textContent = `✓ ${emp.name}`;
    if (clearBtn) clearBtn.classList.remove('hidden');
    // Cập nhật lại nhân sự phụ
    const currentSupportIds = Array.from(document.querySelectorAll('.support-emp-cb:checked')).map(cb => cb.value);
    renderSupportEmpCheckboxes(currentSupportIds);
  } else {
    if (searchInput) searchInput.value = '';
    if (badge) badge.textContent = '';
    if (clearBtn) clearBtn.classList.add('hidden');
  }
}

/**
 * Xóa ô tìm kiếm nhân viên chính
 */
function clearLeadEmpSearch() {
  const searchInput = document.getElementById('taskEmpSearchInput');
  const badge = document.getElementById('taskEmpSelectedBadge');
  const clearBtn = document.getElementById('taskEmpSearchClear');
  if (searchInput) searchInput.value = '';
  if (badge) badge.textContent = '';
  if (clearBtn) clearBtn.classList.add('hidden');
}

/**
 * Chọn TẤT CẢ nhân sự phụ (trừ nhân viên chính)
 */
function selectAllSupportEmps() {
  const cbs = document.querySelectorAll('.support-emp-cb');
  cbs.forEach(cb => {
    cb.checked = true;
    _onSupportEmpCheckboxChange(cb);
  });
  updateSupportEmpCountBadge();
}

/**
 * Bỏ chọn TẤT CẢ nhân sự phụ
 */
function clearAllSupportEmps() {
  const cbs = document.querySelectorAll('.support-emp-cb');
  cbs.forEach(cb => {
    cb.checked = false;
    _onSupportEmpCheckboxChange(cb);
  });
  updateSupportEmpCountBadge();
}

/**
 * Lọc nhanh danh sách nhân sự phụ theo từ khóa
 */
function filterSupportEmpList(val) {
  const v = (val || '').trim().toLowerCase();
  const container = document.getElementById('supportEmpContainer');
  if (!container) return;
  const labels = container.querySelectorAll('label');
  labels.forEach(label => {
    if (!v) {
      label.style.display = '';
      return;
    }
    const text = label.textContent.toLowerCase();
    label.style.display = text.includes(v) ? '' : 'none';
  });
}

/**
 * Cập nhật badge số nhân sự phụ đã chọn
 */
function updateSupportEmpCountBadge() {
  const badge = document.getElementById('supportEmpCountBadge');
  if (!badge) return;
  const count = document.querySelectorAll('.support-emp-cb:checked').length;
  badge.textContent = `(${count})`;
}

function openTaskModal(taskId = null) {
  if (appData.currentUser.role !== 'admin') {
    alert('Chỉ quản trị viên (Admin) mới có quyền tạo mới hoặc chỉnh sửa cấu trúc công việc!');
    return;
  }

  const modal = document.getElementById('taskModal');
  const titleEl = document.getElementById('taskModalTitle');
  populateEmployeeSelects();

  // Reset ô tìm kiếm & đóng danh sách tìm kiếm
  const searchInput = document.getElementById('taskParentSearchInput');
  if (searchInput) searchInput.value = '';
  toggleParentSearchList(false);

  if (taskId) {
    titleEl.innerText = 'Chỉnh Sửa Công Việc';
    const task = appData.tasks.find(t => t.id === taskId);
    if (task) {
      document.getElementById('taskId').value = task.id;
      if (!task.mainTaskId) {
        setStandaloneProject();
      } else if (task.mainTaskId === task.id) {
        setSelfAsProject();
      } else {
        selectParentTask(task.mainTaskId);
        if (task.mainTaskTitle) {
          document.getElementById('taskMainTitle').value = task.mainTaskTitle;
        }
      }
      document.getElementById('taskDetail').value = task.detail || '';
      document.getElementById('taskEmpId').value = task.empId;
      // Đồng bộ ô tìm kiếm nhân viên chính
      populateTaskEmpDatalist();
      const leadEmp = (appData.employees || []).find(e => e.id === task.empId);
      const searchInput = document.getElementById('taskEmpSearchInput');
      const badge = document.getElementById('taskEmpSelectedBadge');
      const clearBtn = document.getElementById('taskEmpSearchClear');
      if (searchInput) searchInput.value = leadEmp ? `${leadEmp.name} (${leadEmp.id})` : task.empId;
      if (badge) badge.textContent = leadEmp ? `✓ ${leadEmp.name}` : '';
      if (clearBtn && leadEmp) clearBtn.classList.remove('hidden');
      document.getElementById('taskStatus').value = task.status;
      document.getElementById('taskStartDate').value = task.startDate;
      const durationInput = document.getElementById('taskPlanDuration');
      const unitSelect = document.getElementById('taskPlanUnit');
      if (durationInput) durationInput.value = task.planDuration || task.planDays || 1;
      if (unitSelect) unitSelect.value = task.planUnit || 'ngày';
      document.getElementById('taskPlanDays').value = task.planDays || 1;
      document.getElementById('taskPlanEndDate').value = task.planEndDate || '';
      document.getElementById('taskActualEndDate').value = task.actualEndDate || '';
      document.getElementById('taskNote').value = task.note || '';
      const linkInput = document.getElementById('taskLink');
      if (linkInput) linkInput.value = task.link || '';
      const sourceSelect = document.getElementById('taskSource');
      if (sourceSelect) sourceSelect.value = task.taskSource || 'Cải thiện nội bộ';
      renderSupportEmpCheckboxes(task.supportEmpIds || []);
    }
  } else {
    titleEl.innerText = 'Thêm Công Việc Mới';
    document.getElementById('taskId').value = '';
    document.getElementById('taskForm').reset();
    setStandaloneProject(); // Mặc định tạo việc riêng lẻ độc lập
    // Reset ô tìm kiếm nhân viên chính
    populateTaskEmpDatalist();
    const searchInputNew = document.getElementById('taskEmpSearchInput');
    const badgeNew = document.getElementById('taskEmpSelectedBadge');
    const clearBtnNew = document.getElementById('taskEmpSearchClear');
    if (searchInputNew) searchInputNew.value = '';
    if (badgeNew) badgeNew.textContent = '';
    if (clearBtnNew) clearBtnNew.classList.add('hidden');
    // Reset bộ lọc nhân sự phụ
    const supportSearch = document.getElementById('supportEmpSearchInput');
    if (supportSearch) supportSearch.value = '';
    const linkInput = document.getElementById('taskLink');
    if (linkInput) linkInput.value = '';
    const sourceSelect = document.getElementById('taskSource');
    if (sourceSelect) sourceSelect.value = 'Cải thiện nội bộ';
    document.getElementById('taskStartDate').value = '2026-10-01';
    const durationInput = document.getElementById('taskPlanDuration');
    const unitSelect = document.getElementById('taskPlanUnit');
    if (durationInput) durationInput.value = 1;
    if (unitSelect) unitSelect.value = 'ngày';
    document.getElementById('taskPlanDays').value = 1;
    calculatePlanEndDate();
    renderSupportEmpCheckboxes([]);
  }

  modal.classList.remove('hidden');
}

function renderParentTaskList(filterQuery = '', selectedId = '__STANDALONE__') {
  const container = document.getElementById('taskParentListContainer');
  const clearBtn = document.getElementById('taskParentSearchClear');
  if (!container) return;

  const currentTaskId = document.getElementById('taskId') ? document.getElementById('taskId').value : '';
  const q = (filterQuery || '').trim().toLowerCase();
  if (clearBtn) {
    if (q) clearBtn.classList.remove('hidden');
    else clearBtn.classList.add('hidden');
  }

  const allAvailable = getAvailableParentTasks(currentTaskId);
  const filteredTasks = q ? allAvailable.filter(m => m.searchStr && m.searchStr.includes(q)) : allAvailable;

  let html = '';

  // Khối các tùy chọn đặc biệt nếu không gõ tìm kiếm hoặc tìm kiếm khớp từ khóa
  const showSpecial = !q || q.includes('riêng') || q.includes('tự') || q.includes('mới') || q.includes('da');
  if (showSpecial) {
    html += `
      <div class="grid grid-cols-1 sm:grid-cols-3 gap-1 mb-1 pb-1 border-b border-sky-100">
        <div onclick="setStandaloneProject()" 
             class="p-1.5 rounded cursor-pointer transition flex items-center justify-between border ${selectedId === '__STANDALONE__' ? 'bg-slate-100 border-slate-400 font-bold' : 'hover:bg-slate-50 border-slate-200 text-slate-700'}">
          <span class="text-[11px]"><i class="fa-solid fa-link-slash text-slate-500 mr-1"></i>Việc riêng lẻ</span>
          ${selectedId === '__STANDALONE__' ? '<i class="fa-solid fa-check text-slate-700 text-xs"></i>' : ''}
        </div>
        <div onclick="setSelfAsProject()" 
             class="p-1.5 rounded cursor-pointer transition flex items-center justify-between border ${selectedId === '__SELF__' ? 'bg-amber-50 border-amber-400 font-bold text-amber-900' : 'hover:bg-amber-50/50 border-slate-200 text-slate-700'}">
          <span class="text-[11px]"><i class="fa-solid fa-star text-amber-500 mr-1"></i>Tự làm Dự án</span>
          ${selectedId === '__SELF__' ? '<i class="fa-solid fa-check text-amber-600 text-xs"></i>' : ''}
        </div>
        <div onclick="selectParentTask('__NEW__')" 
             class="p-1.5 rounded cursor-pointer transition flex items-center justify-between border ${selectedId === '__NEW__' ? 'bg-emerald-50 border-emerald-400 font-bold text-emerald-900' : 'hover:bg-emerald-50/50 border-slate-200 text-slate-700'}">
          <span class="text-[11px]"><i class="fa-solid fa-plus text-emerald-600 mr-1"></i>+ Tạo Dự án mới</span>
          ${selectedId === '__NEW__' ? '<i class="fa-solid fa-check text-emerald-600 text-xs"></i>' : ''}
        </div>
      </div>
    `;
  }

  if (filteredTasks.length === 0) {
    html += `
      <div class="p-3 text-center text-slate-400 text-xs italic">
        Không tìm thấy dự án mẹ hoặc công việc nào khớp với "${filterQuery}". Nhấn "+ Tạo Dự án mới" hoặc chọn "Việc riêng lẻ" ở trên.
      </div>
    `;
  } else {
    filteredTasks.forEach(mt => {
      const isSelected = selectedId === mt.id;
      const safeTitle = String(mt.title || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
      html += `
        <div onclick="selectParentTask('${mt.id}')" 
             class="p-1.5 rounded-lg cursor-pointer transition flex items-center justify-between border ${isSelected ? 'bg-sky-50 border-sky-400 text-sky-950 font-bold shadow-xs' : 'hover:bg-slate-50 border-slate-200 text-slate-700'}">
          <div class="flex items-center gap-1.5 min-w-0 pr-2">
            <span class="px-1.5 py-0.5 rounded text-[9px] font-bold ${mt.badgeColor || 'bg-sky-100 text-sky-800 border-sky-200'} border shrink-0">
              ${mt.badge || 'Việc'}
            </span>
            <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-800 border border-slate-300 shrink-0 font-mono">
              ${mt.id}
            </span>
            <div class="truncate text-xs" title="${safeTitle}">
              <span class="${isSelected ? 'font-bold text-sky-900' : 'font-medium text-slate-800'}">${safeTitle}</span>
              ${mt.subtext ? `<span class="text-[10px] text-slate-400 font-normal ml-1">(${mt.subtext})</span>` : ''}
            </div>
          </div>
          <div class="flex items-center gap-1 shrink-0">
            ${isSelected ? '<span class="text-sky-600 text-xs font-bold mr-1"><i class="fa-solid fa-check"></i></span>' : ''}
          </div>
        </div>
      `;
    });
  }

  container.innerHTML = html;
}

function closeTaskModal() {
  document.getElementById('taskModal').classList.add('hidden');
}

function calculatePlanEndDate() {
  const startStr = document.getElementById('taskStartDate').value;
  const durationInput = document.getElementById('taskPlanDuration');
  const unitSelect = document.getElementById('taskPlanUnit');
  const val = durationInput ? (parseFloat(durationInput.value) || 1) : (parseInt(document.getElementById('taskPlanDays').value) || 1);
  const unit = unitSelect ? unitSelect.value : 'ngày';

  if (startStr && val > 0) {
    const d = parseDate(startStr);
    if (d) {
      let end = d;
      let daysEquivalent = Math.ceil(val);
      if (unit === 'giờ') {
        end = d; // Cùng ngày
        daysEquivalent = 1;
      } else if (unit === 'ngày') {
        end = addDays(d, Math.ceil(val) - 1);
        daysEquivalent = Math.ceil(val);
      } else if (unit === 'tuần') {
        end = addDays(d, Math.ceil(val * 7) - 1);
        daysEquivalent = Math.ceil(val * 7);
      } else if (unit === 'tháng') {
        end = addDays(d, Math.ceil(val * 30) - 1);
        daysEquivalent = Math.ceil(val * 30);
      }
      document.getElementById('taskPlanEndDate').value = formatDate(end);
      const hiddenDays = document.getElementById('taskPlanDays');
      if (hiddenDays) hiddenDays.value = daysEquivalent;
    }
  }
}

/**
 * Tính toán ngược: Từ Ngày Bắt Đầu và Ngày Kế Hoạch Xong -> Tự suy ra Thời Gian Dự Kiến
 */
function calculatePlanDurationFromEndDate() {
  const startStr = document.getElementById('taskStartDate').value;
  const endStr = document.getElementById('taskPlanEndDate').value;
  if (!startStr || !endStr) return;

  const dStart = parseDate(startStr);
  const dEnd = parseDate(endStr);
  if (!dStart || !dEnd) return;

  if (dEnd < dStart) {
    showToast('⚠️ Ngày kết thúc kế hoạch không được nhỏ hơn ngày bắt đầu!', 'warning');
    document.getElementById('taskPlanEndDate').value = startStr;
    const durationInput = document.getElementById('taskPlanDuration');
    const unitSelect = document.getElementById('taskPlanUnit');
    const hiddenDays = document.getElementById('taskPlanDays');
    if (durationInput) durationInput.value = 1;
    if (unitSelect) unitSelect.value = 'ngày';
    if (hiddenDays) hiddenDays.value = 1;
    return;
  }

  const diffDays = Math.floor((dEnd - dStart) / (1000 * 60 * 60 * 24)) + 1;
  const durationInput = document.getElementById('taskPlanDuration');
  const unitSelect = document.getElementById('taskPlanUnit');
  const hiddenDays = document.getElementById('taskPlanDays');

  if (diffDays > 0) {
    if (diffDays % 30 === 0 && diffDays >= 30) {
      if (durationInput) durationInput.value = diffDays / 30;
      if (unitSelect) unitSelect.value = 'tháng';
    } else if (diffDays % 7 === 0 && diffDays >= 7) {
      if (durationInput) durationInput.value = diffDays / 7;
      if (unitSelect) unitSelect.value = 'tuần';
    } else {
      if (durationInput) durationInput.value = diffDays;
      if (unitSelect) unitSelect.value = 'ngày';
    }
    if (hiddenDays) hiddenDays.value = diffDays;
  }
}

function handleTaskStatusChange() {
  const status = document.getElementById('taskStatus').value;
  const actualInput = document.getElementById('taskActualEndDate');
  if (status === 'Hoàn thành' && !actualInput.value) {
    actualInput.value = document.getElementById('taskPlanEndDate').value || document.getElementById('taskStartDate').value;
  }
}

function handleSaveTask(e) {
  e.preventDefault();
  const id = document.getElementById('taskId').value;
  const parentMode = document.getElementById('taskParentSelect') ? document.getElementById('taskParentSelect').value : '__STANDALONE__';
  const detail = document.getElementById('taskDetail').value.trim();
  const empId = document.getElementById('taskEmpId').value;
  const status = document.getElementById('taskStatus').value;
  const startDate = document.getElementById('taskStartDate').value;
  const durationInput = document.getElementById('taskPlanDuration');
  const unitSelect = document.getElementById('taskPlanUnit');
  const planDuration = durationInput ? (parseFloat(durationInput.value) || 1) : 1;
  const planUnit = unitSelect ? unitSelect.value : 'ngày';
  const planDays = parseInt(document.getElementById('taskPlanDays').value) || 1;
  const planEndDate = document.getElementById('taskPlanEndDate').value;
  const actualEndDate = document.getElementById('taskActualEndDate').value;
  const note = document.getElementById('taskNote').value.trim();
  const linkInput = document.getElementById('taskLink');
  const link = linkInput ? autoCleanWindowsPath(linkInput.value) : '';
  const sourceSelect = document.getElementById('taskSource');
  const taskSource = sourceSelect ? sourceSelect.value : 'Cải thiện nội bộ';

  const supportChecked = Array.from(document.querySelectorAll('.support-emp-cb:checked'));
  const supportEmpIds = supportChecked.map(cb => cb.value);
  const supportEmpNames = supportChecked.map(cb => cb.dataset.name || cb.value);

  const emp = appData.employees.find(x => x.id === empId);
  const empName = emp ? emp.name : 'Chưa phân công';

  // Xác định mã và tiêu đề dự án mẹ
  let mainTaskId = '';
  let mainTaskTitle = '';

  if (parentMode === '__STANDALONE__') {
    mainTaskId = '';
    mainTaskTitle = '';
  } else if (parentMode === '__SELF__') {
    // Tự biến thành 1 dự án riêng: mainTaskId = task.id
    if (id) {
      mainTaskId = id;
      mainTaskTitle = detail || 'Dự án ' + id;
    } else {
      mainTaskId = '__TEMP_SELF__';
      mainTaskTitle = detail || 'Dự án mới';
    }
  } else if (parentMode === '__NEW__') {
    mainTaskId = document.getElementById('taskMainCode').value.trim().toUpperCase();
    mainTaskTitle = document.getElementById('taskMainTitle').value.trim() || mainTaskId;
  } else {
    // Chọn 1 dự án mẹ hoặc 1 công việc cụ thể (ví dụ CV-2026-0028)
    mainTaskId = parentMode;
    const parentTask = appData.tasks.find(t => t.id === mainTaskId);
    if (parentTask) {
      mainTaskTitle = parentTask.detail || parentTask.title || parentTask.mainTaskTitle || mainTaskId;
      // QUAN TRỌNG: Nếu công việc mẹ này trước đó đang bị gán vào dự án khác (như CV-2026-0028 bị gán dưới CV-8174),
      // tự động nâng cấp công việc mẹ thành Dự Án Gốc Độc Lập để tránh chuỗi cha-con lồng nhau bất thường
      if (parentTask.mainTaskId && parentTask.mainTaskId !== parentTask.id) {
        parentTask.mainTaskId = parentTask.id;
        parentTask.mainTaskTitle = mainTaskTitle;
      }
    } else {
      mainTaskTitle = document.getElementById('taskMainTitle').value.trim() || mainTaskId;
    }
  }

  if (id) {
    const task = appData.tasks.find(t => t.id === id);
    if (task) {
      if (mainTaskId === '__TEMP_SELF__') {
        mainTaskId = id;
      }
      task.mainTaskId = mainTaskId;
      task.mainTaskTitle = mainTaskTitle;
      task.title = mainTaskTitle || detail;
      task.detail = detail;
      // BẢO TOÀN statusLogs: KHÔNG bao giờ xóa lịch sử nhật ký khi chỉnh sửa công việc
      // task.statusLogs giữ nguyên, không thay đổi qua form này
      task.empId = empId;
      task.empName = empName;
      task.supportEmpIds = supportEmpIds;
      task.supportEmpNames = supportEmpNames;
      task.status = status;
      task.startDate = startDate;
      task.planDuration = planDuration;
      task.planUnit = planUnit;
      task.planDays = planDays;
      task.planEndDate = planEndDate;
      task.actualEndDate = actualEndDate;
      task.note = note;
      task.link = link;
      task.taskSource = taskSource;
    }
  } else {
    // Sinh mã CV chi tiết theo chuẩn CV-YYYY-XXXX (tự tăng theo năm bắt đầu)
    const taskYear = startDate ? parseInt(startDate.slice(0, 4)) : new Date().getFullYear();
    const newId = generateNextTaskId(taskYear);
    if (mainTaskId === '__TEMP_SELF__') {
      mainTaskId = newId;
    }
    appData.tasks.push({
      id: newId,
      mainTaskId,
      mainTaskTitle,
      title: mainTaskTitle || detail,
      detail,
      empId,
      empName,
      supportEmpIds,
      supportEmpNames,
      startDate,
      planDuration,
      planUnit,
      planDays,
      planEndDate,
      actualEndDate,
      status,
      link,
      statusLogs: [],  // Khởi tạo rỗng cho task mới, sẽ được tạo khi cập nhật tiến độ
      note,
      taskSource,
      lastStatusUpdate: startDate
    });
  }

  saveDataToStorage();
  closeTaskModal();
  applyFilters();
  if (typeof showToast === 'function') {
    showToast('Đã lưu thông tin công việc thành công!', 'success');
  }
}

function editTask(taskId) {
  openTaskModal(taskId);
}

function deleteTask(taskId) {
  if (!confirm('Bạn có chắc chắn muốn xóa công việc này?')) return;
  appData.tasks = appData.tasks.filter(t => t.id !== taskId);
  saveDataToStorage();
  applyFilters();
}

// ================= CẬP NHẬT TIẾN ĐỘ NHANH & CHỌN NHANH VIỆC DỞ DANG =================
function openQuickUpdateModal(taskId = null) {
  const modal = document.getElementById('quickUpdateModal');
  const selectQuickTask = document.getElementById('quickTaskSelect');

  // Lọc các công việc dở dang (chưa xong) của nhân viên đang chọn hoặc tất cả
  const currentEmpId = appData.currentUser.role === 'employee' ? appData.currentUser.id : viewState.filterEmp;
  let pendingTasks = appData.tasks.filter(t => {
    const isPending = t.status !== 'Hoàn thành';
    if (currentEmpId && currentEmpId !== 'ALL') {
      return isPending && t.empId === currentEmpId;
    }
    return isPending;
  });

  if (pendingTasks.length === 0) {
    pendingTasks = appData.tasks;
  }

  selectQuickTask.innerHTML = '';
  pendingTasks.forEach(t => {
    const opt = document.createElement('option');
    opt.value = t.id;
    opt.textContent = `[${t.empName}] ${t.mainTaskTitle || t.title} - ${t.detail || ''} (${t.status})`;
    selectQuickTask.appendChild(opt);
  });

  if (taskId) {
    selectQuickTask.value = taskId;
  }

  handleQuickTaskSelectChange();
  modal.classList.remove('hidden');
}

function handleQuickTaskSelectChange() {
  const taskId = document.getElementById('quickTaskSelect').value;
  const task = appData.tasks.find(t => t.id === taskId);
  if (!task) return;

  document.getElementById('quickTaskId').value = task.id;
  document.getElementById('quickTaskTitle').innerText = `${task.mainTaskTitle || task.title} - ${task.detail || ''}`;
  document.getElementById('quickTaskEmp').innerText = `${task.empName} (${task.empId})`;
  document.getElementById('quickTaskStatus').value = task.status;
  document.getElementById('quickActualEndDate').value = task.actualEndDate || formatDate(new Date(2026, 9, 5));
  document.getElementById('quickTaskNote').value = task.note || '';
}

function closeQuickUpdateModal() {
  document.getElementById('quickUpdateModal').classList.add('hidden');
}

function handleSaveQuickUpdate(e) {
  e.preventDefault();
  const id = document.getElementById('quickTaskId').value;
  const task = appData.tasks.find(t => t.id === id);
  if (!task) return;

  task.status = document.getElementById('quickTaskStatus').value;
  task.actualEndDate = document.getElementById('quickActualEndDate').value;
  task.note = document.getElementById('quickTaskNote').value.trim();

  saveDataToStorage();
  closeQuickUpdateModal();
  applyFilters();
}

// ================= ĐIỀU HƯỚNG VÀ BỘ LỌC =================
function applyFilters() {
  viewState.filterEmp = document.getElementById('filterEmployee').value;
  viewState.filterMonth = document.getElementById('filterMonth').value;
  viewState.filterStatus = document.getElementById('filterStatus').value;
  viewState.filterKeyword = document.getElementById('filterKeyword').value;
  const priEl = document.getElementById('filterPriority');
  if (priEl) viewState.filterPriority = priEl.value;
  const sortEl = document.getElementById('filterSortBy');
  if (sortEl) viewState.filterSortBy = sortEl.value;
  const mainEl = document.getElementById('filterMainTask');
  if (mainEl) viewState.filterMainTask = mainEl.value;

  if (viewState.filterMonth && !viewState.filterStartDate) {
    viewState.startOffsetDate = `${viewState.filterMonth}-01`;
  }

  renderMainTable();
  highlightActiveKpiCard();
}

function handleMonthFilterChange() {
  viewState.filterMonth = document.getElementById('filterMonth').value;
  viewState.filterStartDate = '';
  viewState.filterEndDate = '';
  const sInput = document.getElementById('filterStartDate');
  const eInput = document.getElementById('filterEndDate');
  if (sInput) sInput.value = '';
  if (eInput) eInput.value = '';
  if (viewState.filterMonth) {
    viewState.startOffsetDate = `${viewState.filterMonth}-01`;
  }
  applyFilters();
}

function handleDateRangeFilterChange() {
  const s = document.getElementById('filterStartDate').value;
  const e = document.getElementById('filterEndDate').value;
  if (s && e) {
    if (s > e) {
      alert('Ngày bắt đầu không được lớn hơn ngày kết thúc!');
      return;
    }
    viewState.filterStartDate = s;
    viewState.filterEndDate = e;
    viewState.filterMonth = '';
    const mInput = document.getElementById('filterMonth');
    if (mInput) mInput.value = '';
    viewState.startOffsetDate = s;
    setTimeScale('DAY');
    applyFilters();
  }
}

function clearDateRangeFilter() {
  viewState.filterStartDate = '';
  viewState.filterEndDate = '';
  const sInput = document.getElementById('filterStartDate');
  const eInput = document.getElementById('filterEndDate');
  if (sInput) sInput.value = '';
  if (eInput) eInput.value = '';
  setCurrentMonth();
}

function viewAllMonths() {
  const mInput = document.getElementById('filterMonth');
  if (mInput) mInput.value = '';
  viewState.filterMonth = '';
  viewState.filterStartDate = '';
  viewState.filterEndDate = '';
  const sInput = document.getElementById('filterStartDate');
  const eInput = document.getElementById('filterEndDate');
  if (sInput) sInput.value = '';
  if (eInput) eInput.value = '';

  const selStatus = document.getElementById('filterStatus');
  if (selStatus && viewState.filterStatus === 'CHUA_HOAN_THANH') {
    viewState.filterStatus = 'ALL';
    selStatus.value = 'ALL';
  }

  fitTimelineToTaskDates();
  showToast('Đang hiển thị toàn bộ công việc xuyên suốt tất cả các tháng (63/63 việc)', 'info');
}

function setCurrentMonth() {
  document.getElementById('filterMonth').value = '2026-10';
  viewState.filterMonth = '2026-10';
  viewState.filterStartDate = '';
  viewState.filterEndDate = '';
  const sInput = document.getElementById('filterStartDate');
  const eInput = document.getElementById('filterEndDate');
  if (sInput) sInput.value = '';
  if (eInput) eInput.value = '';
  viewState.startOffsetDate = '2026-10-01';
  setTimeScale('DAY');
  applyFilters();
}

function setFullYearView() {
  document.getElementById('filterMonth').value = '';
  viewState.filterMonth = '';
  viewState.filterStartDate = '';
  viewState.filterEndDate = '';
  const sInput = document.getElementById('filterStartDate');
  const eInput = document.getElementById('filterEndDate');
  if (sInput) sInput.value = '';
  if (eInput) eInput.value = '';
  setTimeScale('MONTH');
}

function setDaysWindow(mode) {
  viewState.windowMode = mode.toString();

  document.getElementById('btnWindow10').className = 'px-2 py-0.5 rounded font-semibold text-slate-700 hover:bg-white transition text-xs';
  document.getElementById('btnWindow15').className = 'px-2 py-0.5 rounded font-semibold text-slate-700 hover:bg-white transition text-xs';
  document.getElementById('btnWindowMonth').className = 'px-2 py-0.5 rounded font-semibold text-slate-700 hover:bg-white transition text-xs';

  if (mode === 10) {
    document.getElementById('btnWindow10').className = 'px-2 py-0.5 rounded font-semibold bg-white text-brand-700 shadow-sm transition text-xs';
  } else if (mode === 15) {
    document.getElementById('btnWindow15').className = 'px-2 py-0.5 rounded font-semibold bg-white text-brand-700 shadow-sm transition text-xs';
  } else {
    document.getElementById('btnWindowMonth').className = 'px-2 py-0.5 rounded font-semibold bg-white text-brand-700 shadow-sm transition text-xs';
  }

  renderMainTable();
}

function shiftTimelineDays(days) {
  const cur = parseDate(viewState.startOffsetDate) || new Date(2026, 9, 1);
  const next = addDays(cur, days);
  viewState.startOffsetDate = formatDate(next);
  renderMainTable();
}

// ================= MODAL CẤU HÌNH XUẤT BÁO CÁO EXCEL (CONFIG TITLE & PERSISTENCE) =================
const EXPORT_CONFIG_STORAGE_KEY = 'MBC_EXCEL_EXPORT_CONFIG';

function generateSmartExportTitle() {
  let title = 'BÁO CÁO KẾ HOẠCH & THỰC TÍCH CÔNG VIỆC NHÓM';
  if (viewState.filterMainTask && viewState.filterMainTask !== 'ALL') {
    const mTasks = getUniqueMainTasks();
    const foundM = mTasks.find(m => m.id === viewState.filterMainTask);
    const mName = foundM ? foundM.title : viewState.filterMainTask;
    title += ` - DỰ ÁN: ${mName.toUpperCase()}`;
  } else if (viewState.filterEmp !== 'ALL') {
    const emp = appData.employees.find(e => e.id === viewState.filterEmp);
    if (emp) title += ` - NHÂN SỰ: ${emp.name.toUpperCase()} (${emp.dept})`;
  }
  if (viewState.filterMonth) {
    title += ` - THÁNG ${viewState.filterMonth.split('-')[1]}/${viewState.filterMonth.split('-')[0]}`;
  } else {
    title += ' - NĂM 2026';
  }
  return title;
}

function openExportConfigModal() {
  const modal = document.getElementById('exportConfigModal');
  const titleInput = document.getElementById('exportReportTitle');
  const unitInput = document.getElementById('exportUnitName');
  const scaleSelect = document.getElementById('exportScaleSelect');
  const chk = document.getElementById('saveExportConfigCheckbox');

  // Đọc cấu hình đã lưu trong LocalStorage (nếu có)
  try {
    const raw = localStorage.getItem(EXPORT_CONFIG_STORAGE_KEY);
    if (raw) {
      const saved = JSON.parse(raw);
      if (saved) {
        if (saved.customUnit && unitInput) unitInput.value = saved.customUnit;
        if (saved.exportScale && scaleSelect) scaleSelect.value = saved.exportScale;
        if (saved.customTitle && saved.isCustomTitle && titleInput) {
          titleInput.value = saved.customTitle;
        } else if (titleInput) {
          titleInput.value = generateSmartExportTitle();
        }
        if (chk) chk.checked = true;
        modal.classList.remove('hidden');
        return;
      }
    }
  } catch(e) {}

  if (titleInput) titleInput.value = generateSmartExportTitle();
  if (chk) chk.checked = true;
  modal.classList.remove('hidden');
}

function closeExportConfigModal() {
  document.getElementById('exportConfigModal').classList.add('hidden');
}

function saveExportConfigManual() {
  const titleInput = document.getElementById('exportReportTitle');
  const unitInput = document.getElementById('exportUnitName');
  const scaleSelect = document.getElementById('exportScaleSelect');
  const chk = document.getElementById('saveExportConfigCheckbox');

  const customTitle = titleInput ? titleInput.value.trim() : '';
  const customUnit = unitInput ? unitInput.value.trim() : '';
  const exportScale = scaleSelect ? scaleSelect.value : 'CURRENT';
  const isRemember = chk ? chk.checked : true;

  if (isRemember) {
    const config = { customTitle, customUnit, exportScale, isCustomTitle: true };
    localStorage.setItem(EXPORT_CONFIG_STORAGE_KEY, JSON.stringify(config));
    alert('Đã lưu cấu hình xuất báo cáo Excel thành công!');
  } else {
    localStorage.removeItem(EXPORT_CONFIG_STORAGE_KEY);
    alert('Đã bỏ ghi nhớ cấu hình xuất Excel.');
  }
}

function resetExportConfigToDefault() {
  localStorage.removeItem(EXPORT_CONFIG_STORAGE_KEY);
  const unitInput = document.getElementById('exportUnitName');
  const scaleSelect = document.getElementById('exportScaleSelect');
  const titleInput = document.getElementById('exportReportTitle');
  const chk = document.getElementById('saveExportConfigCheckbox');

  if (unitInput) unitInput.value = 'MBC Group - Phân xưởng sản xuất';
  if (scaleSelect) scaleSelect.value = 'CURRENT';
  if (chk) chk.checked = true;
  if (titleInput) titleInput.value = generateSmartExportTitle();
}

// ================= XUẤT BÁO CÁO EXCEL TRỰC QUAN LIỀN MẠCH (GANTT MATRIX CHUẨN) =================
/**
 * Xuất file Excel báo cáo đẹp mắt:
 * - Tiêu đề báo cáo tùy chỉnh hoặc theo nhân viên lọc
 * - Thanh tiến độ liền mạch (border-left/right: none giữa các ngày liên tiếp)
 * - Mũi tên kết thúc ► sắc nét ở ngày cuối
 */
function executeExportExcelReport() {
  try {
    const customTitle = document.getElementById('exportReportTitle').value.trim() || 'BÁO CÁO KẾ HOẠCH & THỰC TÍCH CÔNG VIỆC NHÓM';
    const customUnit = document.getElementById('exportUnitName').value.trim() || 'MBC Group - Quản Lý Dự Án';
    const exportScale = document.getElementById('exportScaleSelect').value;

    // Ghi nhớ cấu hình nếu checkbox được chọn
    const chk = document.getElementById('saveExportConfigCheckbox');
    if (chk && chk.checked) {
      const config = { customTitle, customUnit, exportScale, isCustomTitle: true };
      localStorage.setItem(EXPORT_CONFIG_STORAGE_KEY, JSON.stringify(config));
    }

    // ── Bước 1: Lọc & gom nhóm task trước khi xây dựng timeline ──
    const today = (new Date().getFullYear() === 2026) ? new Date() : new Date(2026, 9, 8);
    let tasksToExport = appData.tasks.filter(task => {
      if (appData.currentUser.role === 'employee' && task.empId !== appData.currentUser.id) return false;
      if (viewState.filterEmp !== 'ALL' && task.empId !== viewState.filterEmp) return false;

      const effStatus = getTaskEffectiveStatus(task, today);
      const isCompleted = isTaskCompleted(task);
      const isOverdue = isTaskOverdue(task, today);

      if (viewState.filterStatus === 'CHUA_HOAN_THANH') {
        if (isCompleted) return false;
      } else if (viewState.filterStatus === 'HOAN_THANH_ALL') {
        if (!isCompleted) return false;
      } else if (viewState.filterStatus === 'DANG_LAM') {
        // Loại bỏ việc đã xong VÀ việc tạm dừng triệt để
        if (isCompleted || effStatus === 'Tạm dừng') return false;
      } else if (viewState.filterStatus === 'Tạm dừng') {
        if (effStatus !== 'Tạm dừng') return false;
      } else if (viewState.filterStatus === 'QUA_HAN') {
        if (!isOverdue) return false;
      } else if (viewState.filterStatus === 'Hoàn thành') {
        if (effStatus !== 'Hoàn thành') return false;
      } else if (viewState.filterStatus === 'Hoàn thành trễ') {
        if (effStatus !== 'Hoàn thành trễ') return false;
      } else if (viewState.filterStatus !== 'ALL') {
        if (effStatus !== viewState.filterStatus && task.status !== viewState.filterStatus) return false;
      }

      // Lọc từ khóa nếu có
      if (viewState.filterKeyword) {
        const kw = viewState.filterKeyword.toLowerCase().trim();
        const matchTitle = (task.title || '').toLowerCase().includes(kw);
        const matchDetail = (task.detail || '').toLowerCase().includes(kw);
        const matchEmp = (task.empName || '').toLowerCase().includes(kw);
        const matchMain = (task.mainTaskTitle || '').toLowerCase().includes(kw);
        if (!matchTitle && !matchDetail && !matchEmp && !matchMain) return false;
      }

      // Lọc theo Dự án chính nếu có
      if (viewState.filterMainTask && viewState.filterMainTask !== 'ALL') {
        if (viewState.filterMainTask === '__NO_PROJECT__') {
          if (task.mainTaskId && task.mainTaskId.trim()) return false;
        } else {
          const mId = viewState.filterMainTask.toLowerCase();
          const taskMain = (task.mainTaskId || '').toLowerCase();
          const taskTitle = (task.mainTaskTitle || task.title || '').toLowerCase();
          if (taskMain !== mId && taskTitle !== mId && (task.id || '').toLowerCase() !== mId) return false;
        }
      }

      return true;
    });

    // SẮP XẾP CHUẨN XUẤT EXCEL: Dự án chính => Người thực hiện => Tình trạng
    const statusOrderMap = {
      'Đang làm': 1,
      'Đang làm (Trễ hạn)': 2,
      'Tạm dừng': 3,
      'Hoàn thành': 4,
      'Hoàn thành trễ': 5
    };

    tasksToExport.sort((a, b) => {
      // Cấp 1: Dự án chính (các công việc cùng dự án gom cạnh nhau, việc riêng lẻ để sau cùng)
      const projA = (a.mainTaskId || a.mainTaskTitle || '').trim();
      const projB = (b.mainTaskId || b.mainTaskTitle || '').trim();
      if (projA && !projB) return -1;
      if (!projA && projB) return 1;
      if (projA !== projB) {
        return projA.localeCompare(projB, 'vi', { numeric: true, sensitivity: 'base' });
      }

      // Cấp 2: Người thực hiện (A -> Z theo tên)
      const empA = (a.empName || '').trim();
      const empB = (b.empName || '').trim();
      if (empA !== empB) {
        return empA.localeCompare(empB, 'vi', { sensitivity: 'base' });
      }

      // Cấp 3: Tình trạng (Đang làm -> Tạm dừng -> Hoàn thành -> Hoàn thành trễ)
      const effA = getTaskEffectiveStatus(a, today);
      const effB = getTaskEffectiveStatus(b, today);
      const ordA = statusOrderMap[effA] || 99;
      const ordB = statusOrderMap[effB] || 99;
      if (ordA !== ordB) return ordA - ordB;

      // Sau cùng: Theo ngày bắt đầu tăng dần
      const da = parseDate(a.startDate) || new Date(0);
      const db = parseDate(b.startDate) || new Date(0);
      return da.getTime() - db.getTime();
    });

    // ── Bước 2: Xây dựng cột timeline sau khi đã có tasksToExport ──
    let timelineCols = getTimelineColumns(tasksToExport);
    if (exportScale === 'FIT_TASKS') {
      let minStart = null, maxEnd = null;
      tasksToExport.forEach(t => {
        const s = parseDate(t.startDate);
        const e = parseDate(t.actualEndDate || t.planEndDate);
        if (s && (!minStart || s < minStart)) minStart = s;
        if (e && (!maxEnd || e > maxEnd)) maxEnd = e;
      });
      if (minStart && maxEnd && minStart <= maxEnd) {
        timelineCols = [];
        const dayNames = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];
        const totalDays = dateDiffInDays(minStart, maxEnd) + 1;
        for (let i = 0; i < totalDays; i++) {
          const d = addDays(minStart, i);
          timelineCols.push({
            type: 'DAY', date: d,
            label: `${String(d.getDate()).padStart(2,'0')}/${String(d.getMonth()+1).padStart(2,'0')}`,
            subLabel: dayNames[d.getDay()], yearLabel: d.getFullYear(),
            isWeekend: d.getDay() === 0 || d.getDay() === 6,
            startDate: d, endDate: d
          });
        }
      }
    } else if (exportScale && exportScale !== 'CURRENT') {
      const origScale = viewState.timeScale;
      viewState.timeScale = exportScale;
      timelineCols = getTimelineColumns(tasksToExport);
      viewState.timeScale = origScale;
    }

    // Thống kê cho thẻ KPI
    const totalExp = tasksToExport.length;
    const inProgExp = tasksToExport.filter(t => {
      const st = getTaskEffectiveStatus(t, today);
      return st === 'Đang làm' || st === 'Đang làm (Trễ hạn)';
    }).length;
    const pausedExp = tasksToExport.filter(t => getTaskEffectiveStatus(t, today) === 'Tạm dừng').length;
    const onTimeExp = tasksToExport.filter(t => getTaskEffectiveStatus(t, today) === 'Hoàn thành').length;
    const lateExp = tasksToExport.filter(t => getTaskEffectiveStatus(t, today) === 'Hoàn thành trễ').length;
    const overdueExp = tasksToExport.filter(t => isTaskOverdue(t, today)).length;

    let tableHtml = `
      <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
      <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <style>
          table { border-collapse: collapse; font-family: 'Segoe UI', Arial, sans-serif; font-size: 11px; table-layout: auto; }
          th { background-color: #0f3d52; color: #ffffff; font-weight: bold; border: 1px solid #94a3b8; text-align: center; padding: 6px 4px; vertical-align: middle; }
          td { border: 1px solid #cbd5e1; padding: 5px 6px; vertical-align: middle; mso-number-format: "\\@"; white-space: normal; word-break: break-word; overflow-wrap: break-word; }
          .title-row { font-size: 16px; font-weight: bold; background-color: #1e3a8a; color: #ffffff; height: 38px; text-align: center; vertical-align: middle; }
          .sub-title { font-size: 11px; background-color: #f8fafc; color: #475569; text-align: center; font-style: italic; vertical-align: middle; padding: 4px; }
          .kpi-card { font-size: 11px; font-weight: bold; text-align: center; padding: 6px; border: 1px solid #cbd5e1; vertical-align: middle; }
          .info-cell { background-color: #ffffff; white-space: normal; word-break: break-word; overflow-wrap: break-word; vertical-align: middle; mso-height-source: auto; height: auto; }
          .plan-label { background-color: #eff6ff; color: #1e40af; font-weight: bold; text-align: center; font-size: 10px; white-space: nowrap; }
          .actual-label { background-color: #f0fdf4; color: #15803d; font-weight: bold; text-align: center; font-size: 10px; white-space: nowrap; }
          .weekend-cell { background-color: #f8fafc; }
        </style>
      </head>
      <body>
        <table>
          <tr>
            <td colspan="${18 + timelineCols.length}" class="title-row">${customTitle}</td>
          </tr>
          <tr>
            <td colspan="${18 + timelineCols.length}" class="sub-title">Đơn vị: <b>${customUnit}</b> | Thời gian xuất: <b>${new Date().toLocaleString('vi-VN')}</b> | Tổng số việc: <b>${totalExp}</b></td>
          </tr>
          <tr></tr>
          <!-- THẺ KPI TỔNG HỢP TRÊN EXCEL -->
          <tr>
            <td colspan="3" class="kpi-card" style="background-color: #eff6ff; color: #1e40af;">TỔNG VIỆC: ${totalExp}</td>
            <td colspan="3" class="kpi-card" style="background-color: #fefce8; color: #a16207;">ĐANG LÀM: ${inProgExp}</td>
            <td colspan="3" class="kpi-card" style="background-color: #f1f5f9; color: #475569;">TẠM DỪNG: ${pausedExp}</td>
            <td colspan="3" class="kpi-card" style="background-color: #f0fdf4; color: #15803d;">ĐÚNG HẠN (+3Đ): ${onTimeExp}</td>
            <td colspan="3" class="kpi-card" style="background-color: #fff7ed; color: #c2410c;">HOÀN THÀNH TRỄ: ${lateExp}</td>
            <td colspan="3" class="kpi-card" style="background-color: #fef2f2; color: #b91c1c;">QUÁ HẠN: ${overdueExp}</td>
            <td colspan="${timelineCols.length}" style="background-color: #f1f5f9; font-size: 10px; color: #334155;">
              <b>CHÚ THÍCH:</b> 
              <span style="color: #1e40af; font-weight: bold;">■ Kế hoạch (►)</span> | 
              <span style="color: #0284c7; font-weight: bold;">■ Đang làm (►)</span> | 
              <span style="color: #15803d; font-weight: bold;">■ Đúng hạn (✔)</span> | 
              <span style="color: #64748b; font-weight: bold;">■ Tạm dừng (⏸)</span> | 
              <span style="color: #d97706; font-weight: bold;">■ Trễ hạn (⚠)</span> | 
              <span style="color: #b45309; font-weight: bold;">📝 Có ghi chú tiến độ</span>
            </td>
          </tr>
          <tr></tr>
          <tr>
            <th style="width: 35px;">STT</th>
            <th style="width: 85px;">Mã CV</th>
            <th style="width: 180px;">Dự Án Chính</th>
            <th style="width: 240px;">Nội Dung Chi Tiết (Giai Đoạn)</th>
            <th style="width: 120px;">Người Thực Hiện</th>
            <th style="width: 110px;">Người Giao Việc</th>
            <th style="width: 95px;">Thể Loại</th>
            <th style="width: 80px;">Bắt Đầu</th>
            <th style="width: 70px;">Kế Hoạch</th>
            <th style="width: 80px;">Hạn Kế Hoạch</th>
            <th style="width: 80px;">Hoàn Thành</th>
            <th style="width: 95px;">Tình Trạng</th>
            <th style="width: 220px;">Hiện Trạng (Mới Nhất)</th>
            <th style="width: 200px;">Ghi Chú Lần 1</th>
            <th style="width: 200px;">Ghi Chú Lần 2</th>
            <th style="width: 200px;">Ghi Chú Lần 3</th>
            <th style="width: 90px;">Link / Tệp</th>
            <th style="width: 65px;">Loại</th>
            ${timelineCols.map(col => `<th style="min-width: 48px;">${col.label}<br><span style="font-size: 9px; font-weight: normal; opacity: 0.8;">${col.subLabel || ''}</span></th>`).join('')}
          </tr>
    `;

    tasksToExport.forEach((task, idx) => {
      const rawStatus = (task.status || '').trim();
      const isPaused = rawStatus === 'Tạm dừng' || rawStatus === 'Tam dung' || rawStatus === 'Dừng dự án' || rawStatus === 'Dung du an';
      const isCompleted = rawStatus === 'Hoàn thành' || rawStatus === 'Hoan thanh' || rawStatus === 'Hoàn thành trễ' || rawStatus === 'Hoan thanh tre' || !!task.actualEndDate;
      const isInProgress = !isCompleted && !isPaused;

      const tStart = parseDate(task.startDate);
      const tPlanEnd = parseDate(task.planEndDate);
      let taskEffectiveToday = (new Date().getFullYear() === 2026) ? new Date() : new Date(2026, 9, 8);
      if (task.lastStatusUpdate) {
        const lastUp = parseDate(task.lastStatusUpdate);
        if (lastUp && lastUp > taskEffectiveToday) taskEffectiveToday = lastUp;
      }
      let tActualEnd = parseDate(task.actualEndDate);
      if (!tActualEnd && (isInProgress || isPaused)) {
        tActualEnd = taskEffectiveToday;
        if (tStart && tActualEnd < tStart) tActualEnd = tStart;
      }

      // Thông tin chi tiết các cột mới theo yêu cầu người dùng
      const logs = Array.isArray(task.statusLogs) ? [...task.statusLogs].sort((a, b) => (a.date || '').localeCompare(b.date || '')) : [];
      const latestLog = logs.length > 0 ? logs[logs.length - 1] : null;
      const latestNote = latestLog ? (latestLog.note || '') : (task.note || '');

      const formatLogEntry = (l) => {
        if (!l) return '';
        const d = formatVnDate(l.date) || l.date || '';
        const p = (l.progress !== undefined && l.progress !== '') ? ` - ${l.progress}%` : '';
        const n = l.note || '';
        return `[${d}${p}]: ${n}`;
      };

      const log1 = formatLogEntry(logs[0]);
      const log2 = formatLogEntry(logs[1]);
      const log3 = formatLogEntry(logs[2]);

      const effStatus = getTaskEffectiveStatus(task, today);
      const projName = task.mainTaskTitle || task.mainTaskId || 'Việc độc lập';
      const assigner = task.taskSource || 'Cải thiện nội bộ';
      const taskCategory = task.mainTaskId ? 'Theo dự án' : 'Việc độc lập';
      const actualEndStr = (task.actualEndDate && String(task.actualEndDate).trim() !== 'Chưa hoàn thành') ? formatVnDate(task.actualEndDate) : '';

      // Xác định các cột nằm trong phạm vi Kế hoạch
      const planIndices = [];
      timelineCols.forEach((col, cIdx) => {
        if (tStart && tPlanEnd && col.startDate <= tPlanEnd && col.endDate >= tStart) {
          planIndices.push(cIdx);
        }
      });

      // Xác định các cột nằm trong phạm vi Thực tích
      const actualIndices = [];
      timelineCols.forEach((col, cIdx) => {
        if (tStart && tActualEnd && col.startDate <= tActualEnd && col.endDate >= tStart) {
          actualIndices.push(cIdx);
        }
      });

      // HÀNG 1: THÔNG TIN GỘP + KẾ HOẠCH
      let row1 = `
        <tr>
          <td rowspan="2" style="text-align: center; font-weight: bold;" class="info-cell">${idx + 1}</td>
          <td rowspan="2" style="text-align: center; font-weight: bold; color: #0284c7;" class="info-cell">${task.id || ''}</td>
          <td rowspan="2" style="font-weight: bold; color: #0f172a;" class="info-cell">${projName}</td>
          <td rowspan="2" class="info-cell" style="color: #334155;">${task.detail || task.title || ''}</td>
          <td rowspan="2" class="info-cell" style="font-weight: 500;">${task.empName || ''}</td>
          <td rowspan="2" class="info-cell" style="text-align: center; color: #0369a1; font-weight: 500;">${assigner}</td>
          <td rowspan="2" class="info-cell" style="text-align: center;">${taskCategory}</td>
          <td rowspan="2" style="text-align: center;" class="info-cell">${formatVnDate(task.startDate)}</td>
          <td rowspan="2" style="text-align: center; font-weight: bold;" class="info-cell">${formatPlanDuration(task)}</td>
          <td rowspan="2" style="text-align: center;" class="info-cell">${formatVnDate(task.planEndDate)}</td>
          <td rowspan="2" style="text-align: center; font-weight: bold; color: #15803d;" class="info-cell">${actualEndStr}</td>
          <td rowspan="2" style="text-align: center; font-weight: bold;" class="info-cell">${effStatus}</td>
          <td rowspan="2" class="info-cell" style="color: #0f172a; font-weight: 500;">${latestNote}</td>
          <td rowspan="2" class="info-cell" style="font-size: 10px; color: #475569;">${log1}</td>
          <td rowspan="2" class="info-cell" style="font-size: 10px; color: #475569;">${log2}</td>
          <td rowspan="2" class="info-cell" style="font-size: 10px; color: #475569;">${log3}</td>
          <td rowspan="2" style="text-align: center; font-size: 10px;" class="info-cell">${task.link ? `<a href="${task.link}">Mở Link</a>` : ''}</td>
          <td class="plan-label">Kế hoạch</td>
      `;

      // Render ô Gantt Kế hoạch liền khối sắc nét
      timelineCols.forEach((col, cIdx) => {
        const inPlan = planIndices.includes(cIdx);
        if (inPlan) {
          const isFirst = cIdx === planIndices[0];
          const isLast = cIdx === planIndices[planIndices.length - 1];
          const borderStyle = `border-top: 2px solid #1e3a8a; border-bottom: 2px solid #1e3a8a; ${isFirst ? 'border-left: 2px solid #1e3a8a;' : 'border-left: none;'} ${isLast ? 'border-right: 2px solid #1e3a8a;' : 'border-right: none;'}`;
          row1 += `<td style="background-color: #1e40af; ${borderStyle} text-align: center; color: #ffffff; font-weight: bold; font-size: 11px;">${isLast ? '►' : '—'}</td>`;
        } else {
          row1 += `<td class="${col.isWeekend ? 'weekend-cell' : ''}"></td>`;
        }
      });
      row1 += `</tr>`;

      // HÀNG 2: THỰC TÍCH LIỀN KHỐI
      let row2 = `<tr><td class="actual-label">Thực tích</td>`;
      timelineCols.forEach((col, cIdx) => {
        const inActual = actualIndices.includes(cIdx);
        if (inActual) {
          const isFirst = cIdx === actualIndices[0];
          const isLast = cIdx === actualIndices[actualIndices.length - 1];
          const isDelayed = !isPaused && tPlanEnd && col.startDate > tPlanEnd;

          // Kiểm tra xem cột này có ghi nhận cập nhật không
          const logForCol = (task.statusLogs || []).filter(l => {
            const ld = parseDate(l.date);
            return ld && col.startDate <= ld && col.endDate >= ld;
          });

          let barColor = '#16a34a';
          let borderColor = '#14532d';
          let symbol = isLast ? '✔' : '—';

          if (isPaused) {
            barColor = '#64748b';
            borderColor = '#334155';
            symbol = isLast ? '⏸' : '—';
          } else if (!task.actualEndDate && isInProgress) {
            barColor = '#0284c7'; // Xanh cyan/blue cho đang làm
            borderColor = '#0369a1';
            symbol = isLast ? '►' : '—';
          } else if (isDelayed) {
            barColor = '#d97706';
            borderColor = '#9a3412';
            symbol = isLast ? '⚠' : '—';
          }

          let noteText = '';
          if (logForCol.length > 0) {
            const lastLog = logForCol[logForCol.length - 1];
            const p = lastLog.progress !== undefined ? `${lastLog.progress}%` : '';
            symbol = p ? `📝${p}` : '📝';
            noteText = logForCol.map(l => `${l.date}${l.progress !== undefined ? ' ('+l.progress+'%)' : ''}: ${l.note || ''}`).join(' | ');
          }

          const borderStyle = `border-top: 2px solid ${borderColor}; border-bottom: 2px solid ${borderColor}; ${isFirst ? `border-left: 2px solid ${borderColor};` : 'border-left: none;'} ${isLast ? `border-right: 2px solid ${borderColor};` : 'border-right: none;'}`;
          row2 += `<td style="background-color: ${barColor}; ${borderStyle} text-align: center; color: #ffffff; font-weight: bold; font-size: 10px;" title="${noteText.replace(/"/g, '&quot;')}">${symbol}</td>`;
        } else {
          row2 += `<td class="${col.isWeekend ? 'weekend-cell' : ''}"></td>`;
        }
      });
      row2 += `</tr>`;

      tableHtml += row1 + row2;
    });

    tableHtml += `
        </table>
      </body>
      </html>
    `;

    const blob = new Blob([tableHtml], { type: 'application/vnd.ms-excel;charset=utf-8' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `MBC_BaoCao_Gantt_${formatDate(new Date())}.xls`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    closeExportConfigModal();
  } catch (err) {
    alert('Lỗi xuất báo cáo Excel: ' + err.message);
  }
}

// Xuất file CSDL phẳng (.xlsx)
function exportRawDatabaseExcel() {
  try {
    const dataRows = [];
    dataRows.push([
      'STT', 'Mã CV Chính', 'Tên Công Việc Chính', 'Mã CV Chi Tiết', 'Nội Dung Chi Tiết', 'Mã NV', 'Người Thực Hiện',
      'Phòng Ban', 'Ngày Bắt Đầu', 'Ngày Kết Thúc', 'Tiến Độ (%)', 'Trạng Thái', 'Ghi Chú'
    ]);

    appData.tasks.forEach((t, idx) => {
      dataRows.push([
        idx + 1,
        t.mainTaskId || '',
        t.mainTaskName || '',
        t.id || '',
        t.name || '',
        t.assignedEmployeeId || '',
        t.assignedEmployeeName || '',
        t.assignedDepartment || '',
        t.startDate || '',
        t.endDate || '',
        t.progress ?? 0,
        t.status || '',
        t.notes || ''
      ]);
    });

    const ws = XLSX.utils.aoa_to_sheet(dataRows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'CSDL_CongViec');
    XLSX.writeFile(wb, `CSDL_CongViec_${new Date().toISOString().slice(0, 10)}.xlsx`);
  } catch (err) {
    alert('Lỗi xuất CSDL Excel: ' + err.message);
  }
}

// ================= TẢI FILE MẪU & NHẬP DỮ LIỆU THÔNG MINH (SMART MERGE) =================
let currentImportTarget = 'TASK';
let parsedSmartImportData = null;

function openSmartImportModal(target = 'TASK') {
  currentImportTarget = target;
  parsedSmartImportData = null;
  const modal = document.getElementById('importModal');
  if (modal) modal.classList.remove('hidden');
  const fileInput = document.getElementById('smartImportFileInput');
  if (fileInput) fileInput.value = '';
  const selName = document.getElementById('smartImportSelectedFileName');
  if (selName) selName.innerText = 'Nhấn để chọn file hoặc kéo thả file vào đây';
  const btn = document.getElementById('btnExecuteSmartImport');
  if (btn) btn.disabled = true;
  const alertBox = document.getElementById('smartImportAlert');
  if (alertBox) alertBox.classList.add('hidden');
  switchSmartImportTarget(target);
}

function closeSmartImportModal() {
  const modal = document.getElementById('importModal');
  if (modal) modal.classList.add('hidden');
}

function openImportExcelModal() {
  openSmartImportModal('TASK');
}

function closeImportExcelModal() {
  closeSmartImportModal();
}

function switchSmartImportTarget(target) {
  currentImportTarget = target;
  const tabTask = document.getElementById('tabImportTask');
  const tabEmp = document.getElementById('tabImportEmp');
  const modalTitle = document.getElementById('importModalTitle');
  const modalIcon = document.getElementById('importModalIcon');
  const ruleDesc = document.getElementById('importRuleDesc');
  const empBox = document.getElementById('empExportBox');
  const taskBox = document.getElementById('taskExportBox');
  const statusLogBox = document.getElementById('statusLogExportBox');
  const titleTxt = document.getElementById('templateTitleText');
  const subTxt = document.getElementById('templateSubText');

  if (target === 'TASK') {
    if (tabTask) tabTask.className = 'flex-1 py-1.5 rounded-lg bg-white text-emerald-700 shadow-sm transition flex items-center justify-center gap-1.5';
    if (tabEmp) tabEmp.className = 'flex-1 py-1.5 rounded-lg text-slate-600 hover:text-slate-900 transition flex items-center justify-center gap-1.5';
    if (modalTitle) modalTitle.innerText = 'Nhập Công Việc Vào Hệ Thống (Chỉ Chèn Việc Chưa Có)';
    if (modalIcon) modalIcon.className = 'fa-solid fa-list-check text-lg text-emerald-300';
    if (ruleDesc) ruleDesc.innerHTML = 'Hệ thống sẽ đối soát ID và nội dung: <b>Chỉ chèn các công việc chưa có</b>. Toàn bộ công việc đã có sẽ được giữ nguyên 100%, không bị trùng lặp!';
    if (empBox) empBox.classList.add('hidden');
    if (taskBox) taskBox.classList.remove('hidden');
    if (statusLogBox) statusLogBox.classList.remove('hidden');
    if (titleTxt) titleTxt.innerText = 'Tải file mẫu Excel Công Việc:';
    if (subTxt) subTxt.innerText = 'Mẫu có sẵn định dạng cột chuẩn xác để thêm công việc mới';
  } else {
    if (tabEmp) tabEmp.className = 'flex-1 py-1.5 rounded-lg bg-white text-indigo-700 shadow-sm transition flex items-center justify-center gap-1.5';
    if (tabTask) tabTask.className = 'flex-1 py-1.5 rounded-lg text-slate-600 hover:text-slate-900 transition flex items-center justify-center gap-1.5';
    if (modalTitle) modalTitle.innerText = 'Nhập Nhân Sự Vào Hệ Thống (Chỉ Chèn Nhân Sự Mới)';
    if (modalIcon) modalIcon.className = 'fa-solid fa-users text-lg text-indigo-300';
    if (ruleDesc) ruleDesc.innerHTML = 'Hệ thống sẽ đối soát Mã nhân viên và Họ tên: <b>Chỉ thêm nhân sự mới</b>. Nhân sự đã có sẽ được giữ nguyên!';
    if (empBox) empBox.classList.remove('hidden');
    if (taskBox) taskBox.classList.add('hidden');
    if (statusLogBox) statusLogBox.classList.add('hidden');
    if (titleTxt) titleTxt.innerText = 'Tải file mẫu Excel Nhân Sự:';
    if (subTxt) subTxt.innerText = 'Mẫu có sẵn định dạng cột chuẩn xác để thêm nhân sự mới';
  }
}

function downloadSmartImportTemplate() {
  if (currentImportTarget === 'TASK') {
    downloadExcelTemplate();
  } else {
    downloadEmployeeTemplate();
  }
}

function downloadEmployeeTemplate() {
  const templateData = [
    ['Mã Nhân Viên', 'Họ Và Tên', 'Phòng Ban / Bộ Phận', 'Email', 'Điện Thoại'],
    ['NV06', 'Vũ Đình Trọng', 'Kỹ thuật - Bảo trì', 'trong.vd@mbc.vn', '0901234567'],
    ['NV07', 'Ngô Thu Trang', 'Kiểm tra chất lượng (QC)', 'trang.nt@mbc.vn', '0912345678'],
    ['NV08', 'Đỗ Mạnh Hùng', 'Kế hoạch sản xuất', 'hung.dm@mbc.vn', '0923456789']
  ];
  const ws = XLSX.utils.aoa_to_sheet(templateData);
  ws['!cols'] = [{ wch: 16 }, { wch: 25 }, { wch: 28 }, { wch: 28 }, { wch: 16 }];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'MauImportNhanSu');
  XLSX.writeFile(wb, 'MBC_Mau_Import_NhanSu.xlsx');
}

function exportCurrentEmployeesToExcel() {
  if (!appData.employees || appData.employees.length === 0) {
    showToast('⚠️ Chưa có nhân sự nào trong hệ thống!', 'warning');
    return;
  }
  const header = ['Mã Nhân Viên', 'Họ Và Tên', 'Phòng Ban / Bộ Phận', 'Email', 'Điện Thoại'];
  const rows = appData.employees.map(emp => [
    emp.id || '',
    emp.name || '',
    emp.dept || emp.position || '',
    emp.email || '',
    emp.phone || ''
  ]);
  const ws = XLSX.utils.aoa_to_sheet([header, ...rows]);
  ws['!cols'] = [{ wch: 16 }, { wch: 28 }, { wch: 28 }, { wch: 30 }, { wch: 16 }];
  // Highlight header row
  const range = XLSX.utils.decode_range(ws['!ref']);
  for (let C = range.s.c; C <= range.e.c; C++) {
    const cellAddr = XLSX.utils.encode_cell({ r: 0, c: C });
    if (!ws[cellAddr]) continue;
    ws[cellAddr].s = { fill: { fgColor: { rgb: '0C4A6E' } }, font: { color: { rgb: 'FFFFFF' }, bold: true } };
  }
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'DanhSachNhanSu');
  const today = new Date();
  const fname = `MBC_DanhSach_NhanSu_${today.getFullYear()}${String(today.getMonth()+1).padStart(2,'0')}${String(today.getDate()).padStart(2,'0')}.xlsx`;
  XLSX.writeFile(wb, fname);
  showToast(`✅ Đã xuất ${rows.length} nhân sự ra ${fname}!`, 'success');
}

function exportCurrentTasksToExcel() {
  if (!appData.tasks || appData.tasks.length === 0) {
    showToast('⚠️ Chưa có công việc nào trong hệ thống!', 'warning');
    return;
  }

  // Tìm số lượng note lớn nhất trong tất cả các công việc để tạo số cột động
  let maxNotes = 0;
  appData.tasks.forEach(t => {
    if (Array.isArray(t.statusLogs) && t.statusLogs.length > maxNotes) {
      maxNotes = t.statusLogs.length;
    }
  });

  const baseHeader = [
    'Mã CV',
    'Mã CV Chính',
    'Công việc chính',
    'Nội dung chi tiết',
    'Người thực hiện chính',
    'Mã NV',
    'Người phối hợp',
    'Nguồn yêu cầu',
    'Ngày bắt đầu (YYYY-MM-DD)',
    'Thời gian dự kiến',
    'Ngày kế hoạch xong (YYYY-MM-DD)',
    'Thời gian hoàn thành (YYYY-MM-DD)',
    'Hiện Trạng (Ghi Chú Cập Nhật Mới Nhất)',
    'Ngày Cập Nhật Cuối',
    'Tiến Độ (%)',
    'Tình trạng',
    'Link / Tệp',
    'Ghi chú'
  ];

  // Thêm các cột Nhật ký động theo maxNotes
  const noteHeaders = [];
  for (let n = 1; n <= maxNotes; n++) {
    noteHeaders.push(`Nhật Ký ${n} [Ngày - Tiến Độ - Nội Dung]`);
  }
  const header = [...baseHeader, ...noteHeaders];

  const rows = appData.tasks.map(t => {
    // Sắp xếp logs từ cũ đến mới để cột 1 là lần đầu, cột cuối là lần mới nhất
    const logs = Array.isArray(t.statusLogs) ? [...t.statusLogs].sort((a, b) => (a.date || '').localeCompare(b.date || '')) : [];
    const latestLog = logs.length > 0 ? logs[logs.length - 1] : null;

    const baseRow = [
      t.id || '',
      t.mainTaskId || '',
      t.mainTaskTitle || t.title || '',
      t.detail || '',
      t.empName || '',
      t.empId || '',
      Array.isArray(t.supportEmpNames) ? t.supportEmpNames.join(', ') : (t.supportEmps || ''),
      t.taskSource || 'Cải thiện nội bộ',
      t.startDate || '',
      formatPlanDuration(t),
      t.planEndDate || '',
      t.actualEndDate || '',
      latestLog ? (latestLog.note || '') : '',
      latestLog ? (latestLog.date || '') : '',
      latestLog && latestLog.progress !== undefined ? latestLog.progress + '%' : '',
      t.status || 'Đang làm',
      t.link || '',
      t.note || ''
    ];

    // Điền dữ liệu cho các cột nhật ký động
    for (let n = 0; n < maxNotes; n++) {
      if (logs[n]) {
        const l = logs[n];
        const datePart = l.date || '';
        const progPart = l.progress !== undefined ? ` - ${l.progress}%` : '';
        const notePart = l.note || '';
        baseRow.push(`[${datePart}${progPart}]: ${notePart}`);
      } else {
        baseRow.push('');
      }
    }

    return baseRow;
  });

  const ws = XLSX.utils.aoa_to_sheet([header, ...rows]);
  const baseCols = [
    { wch: 16 }, // Mã CV
    { wch: 16 }, // Mã CV Chính
    { wch: 28 }, // Công việc chính
    { wch: 32 }, // Nội dung chi tiết
    { wch: 22 }, // Người thực hiện chính
    { wch: 12 }, // Mã NV
    { wch: 26 }, // Người phối hợp
    { wch: 20 }, // Nguồn yêu cầu
    { wch: 26 }, // Ngày bắt đầu
    { wch: 20 }, // Thời gian dự kiến
    { wch: 28 }, // Ngày kế hoạch xong
    { wch: 28 }, // Thời gian hoàn thành
    { wch: 40 }, // Hiện Trạng
    { wch: 22 }, // Ngày CN Cuối
    { wch: 14 }, // Tiến Độ %
    { wch: 18 }, // Tình trạng
    { wch: 32 }, // Link / Tệp
    { wch: 25 }  // Ghi chú
  ];
  for (let n = 0; n < maxNotes; n++) {
    baseCols.push({ wch: 38 });
  }
  ws['!cols'] = baseCols;
  const range = XLSX.utils.decode_range(ws['!ref']);
  for (let C = range.s.c; C <= range.e.c; C++) {
    const cellAddr = XLSX.utils.encode_cell({ r: 0, c: C });
    if (!ws[cellAddr]) continue;
    ws[cellAddr].s = { fill: { fgColor: { rgb: '047857' } }, font: { color: { rgb: 'FFFFFF' }, bold: true } };
  }
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'DanhSachCongViec');
  const today = new Date();
  const fname = `MBC_DanhSach_CongViec_${today.getFullYear()}${String(today.getMonth()+1).padStart(2,'0')}${String(today.getDate()).padStart(2,'0')}.xlsx`;
  XLSX.writeFile(wb, fname);
  showToast(`✅ Đã xuất ${rows.length} công việc ra ${fname}!`, 'success');
}

function downloadExcelTemplate() {
  const templateData = [
    ['Mã CV Chính', 'Công việc chính', 'Nội dung chi tiết', 'Người thực hiện chính', 'Mã NV', 'Người phối hợp', 'Nguồn yêu cầu', 'Ngày bắt đầu (YYYY-MM-DD)', 'Thời gian dự kiến', 'Ngày kế hoạch xong (YYYY-MM-DD)', 'Thời gian hoàn thành (YYYY-MM-DD)', 'Tình trạng', 'Link / Tệp', 'Ghi chú'],
    ['CV-TUM', 'Sửa chữa máy TUM', 'Xác nhận tình trạng linh kiện', 'Nguyễn Quang Thảo', 'NV01', 'Trần Văn Bình, Lê Thị Thu', 'Trưởng phòng', '2026-10-01', '1 ngày', '2026-10-01', '2026-10-01', 'Hoàn thành', 'https://drive.google.com/mbc', 'Nghiệm thu tốt'],
    ['CV-MAY-EP', 'Bảo dưỡng định kỳ máy ép', 'Kiểm tra đường ống dầu thủy lực', 'Trần Văn Bình', 'NV02', 'Lê Thị Thu', 'Tổng Giám đốc', '2026-10-03', '3 ngày', '2026-10-05', '2026-10-05', 'Hoàn thành', 'C:\\MBC\\BaoDuongMayEp', 'Đúng hạn'],
    ['CV-KIEM-DINH', 'Kiểm định thiết bị đo', 'Hiệu chuẩn thước kẹp điện tử', 'Lê Thị Thu', 'NV03', '', 'Đối ứng sự cố', '2026-10-05', '2 ngày', '2026-10-06', '', 'Đang làm', '', 'Đang thực hiện']
  ];

  const ws = XLSX.utils.aoa_to_sheet(templateData);
  ws['!cols'] = [
    { wch: 14 }, { wch: 25 }, { wch: 30 }, { wch: 20 }, { wch: 10 },
    { wch: 24 }, { wch: 18 }, { wch: 25 }, { wch: 20 }, { wch: 28 },
    { wch: 28 }, { wch: 16 }, { wch: 28 }, { wch: 25 }
  ];
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'MauImportCongViec');
  XLSX.writeFile(wb, 'MBC_Mau_Import_CongViec.xlsx');
}

function handleSmartImportFileSelect(e) {
  const file = e.target.files[0];
  if (!file) return;

  const selName = document.getElementById('smartImportSelectedFileName');
  if (selName) selName.innerText = `Đã chọn: ${file.name} (${Math.round(file.size / 1024)} KB)`;
  const fileName = file.name.toLowerCase();

  if (fileName.endsWith('.json')) {
    const reader = new FileReader();
    reader.onload = function(evt) {
      try {
        const parsed = JSON.parse(evt.target.result);
        parsedSmartImportData = { type: 'JSON', data: parsed };
        const btn = document.getElementById('btnExecuteSmartImport');
        if (btn) btn.disabled = false;
      } catch (err) {
        alert('Lỗi định dạng JSON: ' + err.message);
      }
    };
    reader.readAsText(file);
  } else if (fileName.endsWith('.xlsx') || fileName.endsWith('.xls')) {
    const reader = new FileReader();
    reader.onload = function(evt) {
      try {
        const data = new Uint8Array(evt.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
        const sheetData = XLSX.utils.sheet_to_json(firstSheet, { header: 1 });
        parsedSmartImportData = { type: 'EXCEL', data: sheetData };
        if (sheetData.length > 1) {
          const btn = document.getElementById('btnExecuteSmartImport');
          if (btn) btn.disabled = false;
        } else {
          alert('File Excel không có dòng dữ liệu hợp lệ!');
        }
      } catch (err) {
        alert('Không thể đọc file Excel: ' + err.message);
      }
    };
    reader.readAsArrayBuffer(file);
  } else {
    alert('Vui lòng chọn file định dạng .xlsx, .xls hoặc .json!');
  }
}

/**
 * Phân tích chuỗi hoặc số thời gian dự kiến linh hoạt (ví dụ: "4 giờ", "2 tuần", "1 tháng", "5 ngày", 5)
 */
function parseDurationString(val) {
  if (val === undefined || val === null || val === '') return null;
  if (typeof val === 'number') {
    return { duration: val, unit: 'ngày', days: Math.ceil(val) };
  }
  const str = String(val).trim().toLowerCase();
  const match = str.match(/^([\d.,]+)\s*(giờ|gio|h|ngày|ngay|d|tuần|tuan|w|tháng|thang|m)?/);
  if (!match) {
    const fallbackNum = parseFloat(str.replace(',', '.')) || 1;
    return { duration: fallbackNum, unit: 'ngày', days: Math.ceil(fallbackNum) };
  }
  const num = parseFloat(match[1].replace(',', '.')) || 1;
  const unitRaw = match[2] || 'ngày';
  let unit = 'ngày';
  let days = Math.ceil(num);
  if (unitRaw.startsWith('g') || unitRaw === 'h') {
    unit = 'giờ';
    days = 1;
  } else if (unitRaw.startsWith('tuan') || unitRaw.startsWith('tuần') || unitRaw === 'w') {
    unit = 'tuần';
    days = Math.ceil(num * 7);
  } else if (unitRaw.startsWith('thang') || unitRaw.startsWith('tháng') || unitRaw === 'm') {
    unit = 'tháng';
    days = Math.ceil(num * 30);
  } else {
    unit = 'ngày';
    days = Math.ceil(num);
  }
  return { duration: num, unit, days };
}

function processSmartImport() {
  if (!parsedSmartImportData) return;

  let addedCount = 0;
  let skippedCount = 0;

  if (currentImportTarget === 'TASK') {
    let rawTasks = [];
    if (parsedSmartImportData.type === 'JSON') {
      const d = parsedSmartImportData.data;
      if (Array.isArray(d)) rawTasks = d;
      else if (d.tasks && Array.isArray(d.tasks)) rawTasks = d.tasks;
    } else {
      const rows = parsedSmartImportData.data.slice(1);
      const header = parsedSmartImportData.data[0].map(h => String(h || '').trim().toLowerCase());
      const colTaskId = header.findIndex(h => h === 'mã cv' || h === 'ma cv' || h.includes('mã công việc'));
      const colMainId = header.findIndex(h => h.includes('mã cv chính') || h.includes('ma cv chinh') || (h.includes('mã cv') && h !== 'mã cv' && h !== 'ma cv'));
      const colMainTitle = header.findIndex(h => h.includes('công việc chính') || h.includes('cong viec chinh') || h.includes('công việc'));
      const colDetail = header.findIndex(h => h.includes('chi tiết') || h.includes('nội dung'));
      const colEmp = header.findIndex(h => h.includes('thực hiện chính') || h.includes('người chính') || h.includes('người thực hiện') || h.includes('nguoi thuc hien'));
      const colEmpId = header.findIndex(h => h.includes('mã nv'));
      const colSupport = header.findIndex(h => h.includes('phối hợp') || h.includes('phu') || h.includes('phụ') || h.includes('hỗ trợ') || h.includes('người cùng làm'));
      const colSource = header.findIndex(h => h.includes('nguồn') || h.includes('nguon') || h.includes('yêu cầu') || h.includes('giao việc'));
      const colStart = header.findIndex(h => h.includes('bắt đầu'));
      const colDays = header.findIndex(h => h.includes('dự kiến') && (h.includes('thời gian') || h.includes('ngày') || h.includes('giờ') || h.includes('tuần') || h.includes('tháng') || !h.includes('kết thúc')));
      const colPlanEnd = header.findIndex(h => (h.includes('kế hoạch') || h.includes('ke hoach') || h.includes('dự kiến')) && (h.includes('xong') || h.includes('kết thúc') || h.includes('ket thuc') || h.includes('hạn') || h.includes('han')));
      const colActual = header.findIndex(h => h.includes('hoàn thành') && !h.includes('kế hoạch') && !h.includes('dự kiến'));
      const colStatus = header.findIndex(h => h.includes('tình trạng'));
      const colLink = header.findIndex(h => h.includes('link') || h.includes('tệp') || h.includes('tài liệu'));
      const colNote = header.findIndex(h => h.includes('ghi chú'));

      // Tìm tất cả các cột Nhật ký / Ghi chú tiến độ động
      const noteColIndices = [];
      header.forEach((h, idx) => {
        if (h.includes('nhật ký') || h.includes('nhat ky') || (h.includes('lịch sử') && h.includes('cập nhật')) || (h.includes('hiện trạng') && h.includes('ghi chú'))) {
          noteColIndices.push(idx);
        }
      });

      rows.forEach((row, rIdx) => {
        if (!row || row.length === 0) return;
        const title = colMainTitle >= 0 ? String(row[colMainTitle] || '').trim() : '';
        if (!title) return;
        const taskId = (colTaskId >= 0 && row[colTaskId]) ? String(row[colTaskId]).trim() : `TASK-IMP-${Date.now().toString().slice(-4)}${rIdx + 1}`;
        const mainTaskId = colMainId >= 0 ? String(row[colMainId] || `CV-${Date.now().toString().slice(-4)}`).trim().toUpperCase() : `CV-${Date.now().toString().slice(-4)}`;
        const detail = colDetail >= 0 ? String(row[colDetail] || '').trim() : '';
        const empName = colEmp >= 0 ? String(row[colEmp] || '').trim() : 'Nguyễn Quang Thảo';
        let empId = colEmpId >= 0 ? String(row[colEmpId] || '').trim().toUpperCase() : '';
        if (!empId) {
          const matchEmp = appData.employees.find(e => e.name.toLowerCase() === empName.toLowerCase());
          empId = matchEmp ? matchEmp.id : 'NV01';
        }

        // Xử lý Người phối hợp
        let supportEmpIds = [];
        let supportEmpNames = [];
        if (colSupport >= 0 && row[colSupport]) {
          const rawSupportStr = String(row[colSupport]).trim();
          const parts = rawSupportStr.split(/[,;\n]+/).map(s => s.trim()).filter(Boolean);
          parts.forEach(part => {
            const foundEmp = appData.employees.find(e => 
              e.id.toLowerCase() === part.toLowerCase() || 
              e.name.toLowerCase() === part.toLowerCase() ||
              part.toLowerCase().includes(e.name.toLowerCase()) ||
              part.toLowerCase().includes(e.id.toLowerCase())
            );
            if (foundEmp && foundEmp.id !== empId) {
              if (!supportEmpIds.includes(foundEmp.id)) {
                supportEmpIds.push(foundEmp.id);
                supportEmpNames.push(foundEmp.name);
              }
            } else if (part) {
              supportEmpNames.push(part);
            }
          });
        }

        const taskSource = colSource >= 0 ? String(row[colSource] || 'Cải thiện nội bộ').trim() : 'Cải thiện nội bộ';
        let startDate = colStart >= 0 ? parseFlexibleDate(row[colStart]) : '2026-10-01';
        if (!startDate) startDate = '2026-10-01';
        const sDate = parseDate(startDate) || new Date(2026, 9, 1);

        // Tính toán 2 chiều giữa Thời Gian Dự Kiến & Ngày Kế Hoạch Xong
        let planDuration = 1;
        let planUnit = 'ngày';
        let planDays = 1;
        let planEndDate = '';

        const rawDaysVal = colDays >= 0 ? row[colDays] : null;
        const parsedDur = parseDurationString(rawDaysVal);

        let rawPlanEnd = colPlanEnd >= 0 ? parseFlexibleDate(row[colPlanEnd]) : '';

        if (parsedDur) {
          // Có thời gian dự kiến -> tính ngày kết thúc kế hoạch
          planDuration = parsedDur.duration;
          planUnit = parsedDur.unit;
          planDays = parsedDur.days;
          planEndDate = rawPlanEnd || formatDate(addDays(sDate, planDays - 1));
        } else if (rawPlanEnd) {
          // Ngược lại: không có thời gian dự kiến nhưng có ngày yêu cầu hoàn thành -> tự tính ngược ra
          const pEndDate = parseDate(rawPlanEnd);
          if (pEndDate && pEndDate >= sDate) {
            const diff = Math.floor((pEndDate - sDate) / (1000 * 60 * 60 * 24)) + 1;
            planDays = diff;
            planDuration = diff;
            planUnit = 'ngày';
            planEndDate = rawPlanEnd;
          } else {
            planDays = 1;
            planDuration = 1;
            planUnit = 'ngày';
            planEndDate = rawPlanEnd;
          }
        } else {
          // Mặc định 1 ngày
          planDays = 1;
          planDuration = 1;
          planUnit = 'ngày';
          planEndDate = formatDate(sDate);
        }

        let actualEndDate = colActual >= 0 ? parseFlexibleDate(row[colActual]) : '';
        const status = colStatus >= 0 ? String(row[colStatus] || 'Đang làm').trim() : 'Đang làm';
        const link = colLink >= 0 ? String(row[colLink] || '').trim() : '';
        const note = colNote >= 0 ? String(row[colNote] || '').trim() : '';

        // Đọc toàn bộ các cột nhật ký / note
        let importedStatusLogs = [];
        noteColIndices.forEach(cIdx => {
          const cellVal = String(row[cIdx] || '').trim();
          if (!cellVal) return;
          const parts = cellVal.includes(' ; ') ? cellVal.split(' ; ') : [cellVal];
          parts.forEach(part => {
            const p = part.trim();
            if (!p) return;
            // Match pattern: [DD/MM/YYYY - X%]: Nội dung hoặc [DD/MM/YYYY]: Nội dung
            const m = p.match(/^\[\s*([\d\/\-]+)(?:\s*[\-\–]\s*(\d+)%)?\s*\]\s*:\s*(.*)$/);
            if (m) {
              const dRaw = m[1].trim();
              const dParsed = parseFlexibleDate(dRaw) || startDate;
              const prog = m[2] !== undefined ? parseInt(m[2], 10) : undefined;
              const nText = m[3].trim();
              const logEntry = {
                date: dParsed,
                note: nText,
                status: status,
                author: empName
              };
              if (prog !== undefined) logEntry.progress = prog;
              importedStatusLogs.push(logEntry);
            } else if (p) {
              importedStatusLogs.push({
                date: startDate,
                note: p,
                status: status,
                author: empName
              });
            }
          });
        });

        let lastUp = '';
        if (importedStatusLogs.length > 0) {
          const sorted = [...importedStatusLogs].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
          lastUp = sorted[0].date;
        }

        rawTasks.push({
          id: taskId,
          mainTaskId,
          mainTaskTitle: title,
          title,
          detail,
          empId,
          empName,
          supportEmpIds,
          supportEmpNames,
          taskSource,
          startDate,
          planDuration,
          planUnit,
          planDays,
          planEndDate,
          actualEndDate,
          status,
          link,
          note,
          statusLogs: importedStatusLogs,
          lastStatusUpdate: lastUp || ''
        });
      });
    }

    rawTasks.forEach(task => {
      const existingTask = appData.tasks.find(t => {
        if (task.id && t.id && t.id.toLowerCase() === task.id.toLowerCase()) return true;
        const sameTitle = (t.mainTaskTitle || t.title).toLowerCase() === (task.mainTaskTitle || task.title).toLowerCase();
        const sameEmp = t.empId === task.empId || (t.empName && task.empName && t.empName.toLowerCase() === task.empName.toLowerCase());
        const sameStart = t.startDate === task.startDate;
        const sameDetail = (t.detail || '').toLowerCase() === (task.detail || '').toLowerCase();
        return sameTitle && sameEmp && sameStart && sameDetail;
      });

      if (existingTask) {
        // Cập nhật bổ sung các note mới vào existingTask nếu có
        if (task.statusLogs && task.statusLogs.length > 0) {
          if (!existingTask.statusLogs) existingTask.statusLogs = [];
          task.statusLogs.forEach(newLog => {
            const hasLog = existingTask.statusLogs.some(el => el.date === newLog.date && el.note === newLog.note);
            if (!hasLog) {
              existingTask.statusLogs.push(newLog);
            }
          });
          if (task.lastStatusUpdate) {
            existingTask.lastStatusUpdate = task.lastStatusUpdate;
          }
        }
        skippedCount++;
      } else {
        addedCount++;
        if (!task.id) task.id = `TASK-${Date.now().toString().slice(-4)}${addedCount}`;
        appData.tasks.push(task);
      }
    });

  } else {
    // NHẬP NHÂN SỰ
    let rawEmps = [];
    if (parsedSmartImportData.type === 'JSON') {
      const d = parsedSmartImportData.data;
      if (Array.isArray(d)) rawEmps = d;
      else if (d.employees && Array.isArray(d.employees)) rawEmps = d.employees;
    } else {
      const rows = parsedSmartImportData.data.slice(1);
      const header = parsedSmartImportData.data[0].map(h => String(h || '').trim().toLowerCase());
      const colId = header.findIndex(h => h.includes('mã nv') || h.includes('mã nhân viên'));
      const colName = header.findIndex(h => h.includes('họ và tên') || h.includes('tên') || h.includes('nhân sự'));
      const colDept = header.findIndex(h => h.includes('phòng') || h.includes('bộ phận') || h.includes('dept'));

      rows.forEach((row, rIdx) => {
        if (!row || row.length === 0) return;
        const name = colName >= 0 ? String(row[colName] || '').trim() : '';
        if (!name) return;
        const id = colId >= 0 ? String(row[colId] || `NV0${appData.employees.length + rIdx + 1}`).trim().toUpperCase() : `NV0${appData.employees.length + rIdx + 1}`;
        const dept = colDept >= 0 ? String(row[colDept] || 'Kỹ thuật').trim() : 'Kỹ thuật';
        rawEmps.push({ id, name, dept });
      });
    }

    rawEmps.forEach(emp => {
      if (!emp.name) return;
      const exists = appData.employees.some(e => {
        if (emp.id && e.id && e.id.toLowerCase() === emp.id.toLowerCase()) return true;
        return e.name.toLowerCase() === emp.name.toLowerCase();
      });

      if (exists) {
        skippedCount++;
      } else {
        addedCount++;
        if (!emp.id) emp.id = `NV0${appData.employees.length + 1}`;
        appData.employees.push(emp);
      }
    });
  }

  saveDataToStorage();
  updateAuthUI();
  renderUserDropdown();
  populateEmployeeSelects();
  renderEmployeeTable();
  applyFilters();

  const alertBox = document.getElementById('smartImportAlert');
  if (alertBox) {
    alertBox.className = 'p-3 rounded-lg text-xs bg-emerald-100 text-emerald-800 border border-emerald-300 font-semibold block';
    alertBox.innerText = `Thành công! Đã chèn thêm ${addedCount} mục mới chưa có (Bỏ qua ${skippedCount} mục đã có sẵn).`;
    alertBox.classList.remove('hidden');
  }

  setTimeout(() => {
    closeSmartImportModal();
  }, 1600);
}

// ================= SAO LƯU & XUẤT CÁC FILE JSON =================
function openSyncModal() {
  document.getElementById('syncModal').classList.remove('hidden');
}

function closeSyncModal() {
  document.getElementById('syncModal').classList.add('hidden');
}

function exportDatabaseJson() {
  downloadJsonFile(appData, 'database.json');
}

function exportTasksJson() {
  downloadJsonFile(appData.tasks, 'tasks.json');
}

function exportEmployeesJson() {
  downloadJsonFile(appData.employees, 'employees.json');
}

function downloadJsonFile(obj, filename) {
  const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(obj, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', dataStr);
  downloadAnchor.setAttribute('download', filename);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

// ================= XUẤT DỮ LIỆU RA EXCEL (BẢNG PHẲNG) =================
/**
 * Xuất toàn bộ danh sách công việc ra file Excel bảng phẳng (không Gantt).
 * Bao gồm đầy đủ các trường thông tin để thuận tiện phân tích / lưu trữ.
 */
function exportTasksDataToExcel() {
  const today = new Date();
  const todayStr = `${today.getDate().toString().padStart(2,'0')}/${(today.getMonth()+1).toString().padStart(2,'0')}/${today.getFullYear()}`;

  // Header
  const headers = [
    'STT', 'Mã CV', 'Dự Án Chính', 'Nội Dung Chi Tiết',
    'Người Thực Hiện', 'Mã NV', 'Người Giao Việc', 'Thể Loại',
    'Ngày Bắt Đầu', 'Dự Kiến', 'Ngày HT Kế Hoạch',
    'Ngày HT Thực Tế', 'Trạng Thái', 'Hiện Trạng (Mới Nhất)',
    'Ghi Chú Lần 1', 'Ghi Chú Lần 2', 'Ghi Chú Lần 3',
    'Điểm KPI', 'Cập Nhật Cuối', 'Link / Tài Liệu', 'Ghi Chú'
  ];

  const statusMap = { 'Hoàn thành': '✔ Hoàn thành', 'Hoàn thành trễ': '⚠ Hoàn thành trễ', 'Đang làm': '▶ Đang làm', 'Tạm dừng': '⏸ Tạm dừng', 'Dừng dự án': '⏹ Dừng dự án' };

  // Sắp xếp theo: Dự án chính => Người => Tình trạng
  const tasksSorted = [...appData.tasks];
  const statusOrderMap = { 'Đang làm': 1, 'Đang làm (Trễ hạn)': 2, 'Tạm dừng': 3, 'Hoàn thành': 4, 'Hoàn thành trễ': 5 };
  tasksSorted.sort((a, b) => {
    const projA = (a.mainTaskId || a.mainTaskTitle || '').trim();
    const projB = (b.mainTaskId || b.mainTaskTitle || '').trim();
    if (projA && !projB) return -1;
    if (!projA && projB) return 1;
    if (projA !== projB) return projA.localeCompare(projB, 'vi', { numeric: true, sensitivity: 'base' });

    const empA = (a.empName || '').trim();
    const empB = (b.empName || '').trim();
    if (empA !== empB) return empA.localeCompare(empB, 'vi', { sensitivity: 'base' });

    const effA = getTaskEffectiveStatus(a, today);
    const effB = getTaskEffectiveStatus(b, today);
    const ordA = statusOrderMap[effA] || 99;
    const ordB = statusOrderMap[effB] || 99;
    if (ordA !== ordB) return ordA - ordB;

    const da = parseDate(a.startDate) || new Date(0);
    const db = parseDate(b.startDate) || new Date(0);
    return da.getTime() - db.getTime();
  });

  const formatLogEntry = (l) => {
    if (!l) return '';
    const d = formatVnDate(l.date) || l.date || '';
    const p = (l.progress !== undefined && l.progress !== '') ? ` - ${l.progress}%` : '';
    const n = l.note || '';
    return `[${d}${p}]: ${n}`;
  };

  const rows = tasksSorted.map((t, i) => {
    const logs = Array.isArray(t.statusLogs) ? [...t.statusLogs].sort((a, b) => (a.date || '').localeCompare(b.date || '')) : [];
    const latestLog = logs.length > 0 ? logs[logs.length - 1] : null;
    const latestNote = latestLog ? (latestLog.note || '') : (t.note || '');
    const actualEndStr = (t.actualEndDate && String(t.actualEndDate).trim() !== 'Chưa hoàn thành') ? formatVnDate(t.actualEndDate) : '';

    return [
      i + 1,
      t.id || '',
      t.mainTaskTitle || t.mainTaskId || 'Việc độc lập',
      t.detail || t.title || '',
      t.empName || '',
      t.empId || '',
      t.taskSource || 'Cải thiện nội bộ',
      t.mainTaskId ? 'Theo dự án' : 'Việc độc lập',
      formatVnDate(t.startDate) || '',
      formatPlanDuration(t) || '',
      formatVnDate(t.planEndDate) || '',
      actualEndStr,
      statusMap[t.status] || t.status || '',
      latestNote,
      formatLogEntry(logs[0]),
      formatLogEntry(logs[1]),
      formatLogEntry(logs[2]),
      t.kpiPoints !== undefined ? t.kpiPoints : '',
      formatVnDate(t.lastStatusUpdate || t.startDate) || '',
      t.link || '',
      t.note || ''
    ];
  });

  // Xây dựng HTML table để xuất
  const title = `DANH SÁCH CÔNG VIỆC - MBC GROUP (Xuất: ${todayStr})`;
  let html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">`;
  html += `<head><meta charset="UTF-8"><style>`;
  html += `body{font-family:'Segoe UI',Arial,sans-serif;font-size:10pt;}`;
  html += `table{border-collapse:collapse;width:100%;table-layout:auto;}`;
  html += `td,th{border:1px solid #94a3b8;padding:6px 8px;vertical-align:middle;mso-number-format:"\\@";white-space:normal;word-break:break-word;overflow-wrap:break-word;height:auto;mso-height-source:auto;}`;
  html += `.title-row td{background:#1e3a5f;color:white;font-weight:bold;font-size:13pt;text-align:center;border:none;padding:10px;}`;
  html += `.date-row td{background:#f1f5f9;color:#475569;font-size:9pt;text-align:right;border:none;padding:4px 8px;}`;
  html += `.header-row th{background:#334155;color:white;font-weight:bold;text-align:center;font-size:9pt;padding:6px 8px;}`;
  html += `.data-row td{font-size:9pt;}`;
  html += `.data-row:nth-child(even) td{background:#f8fafc;}`;
  html += `.status-done{color:#16a34a;font-weight:bold;}`;
  html += `.status-late{color:#d97706;font-weight:bold;}`;
  html += `.status-overdue{color:#dc2626;font-weight:bold;}`;
  html += `.status-paused{color:#78716c;}`;
  html += `</style></head><body>`;
  html += `<table>`;
  html += `<tr class="title-row"><td colspan="${headers.length}">${title}</td></tr>`;
  html += `<tr class="date-row"><td colspan="${headers.length}">Tổng số: ${rows.length} công việc &nbsp;|&nbsp; Xuất lúc: ${todayStr}</td></tr>`;
  html += `<tr class="header-row">${headers.map(h => `<th>${h}</th>`).join('')}</tr>`;
  rows.forEach(r => {
    const statusVal = String(r[12] || '');
    let statusClass = '';
    if (statusVal.includes('Hoàn thành trễ')) statusClass = 'status-late';
    else if (statusVal.includes('Hoàn thành')) statusClass = 'status-done';
    else if (statusVal.includes('Tạm dừng') || statusVal.includes('Dừng')) statusClass = 'status-paused';
    html += `<tr class="data-row">${r.map((cell, ci) => `<td${ci === 12 && statusClass ? ` class="${statusClass}"` : ''}>${String(cell).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</td>`).join('')}</tr>`;
  });
  html += `</table></body></html>`;

  const blob = new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `DanhSach_CongViec_MBC_${today.getFullYear()}${String(today.getMonth()+1).padStart(2,'0')}${String(today.getDate()).padStart(2,'0')}.xls`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast('✅ Đã xuất danh sách công việc ra Excel thành công!', 'success');
}

/**
 * Xuất toàn bộ danh sách nhân sự ra file Excel bảng phẳng.
 */
function exportEmployeesDataToExcel() {
  const today = new Date();
  const todayStr = `${today.getDate().toString().padStart(2,'0')}/${(today.getMonth()+1).toString().padStart(2,'0')}/${today.getFullYear()}`;

  const headers = [
    'STT', 'Mã NV', 'Họ & Tên', 'Phòng Ban / Vị Trí', 'Email',
    'Điện Thoại', 'Tổng Công Việc', 'Đã Hoàn Thành', 'Đang Làm', 'Tỷ Lệ HT (%)', 'Tổng Điểm KPI'
  ];

  const rows = appData.employees.map((emp, i) => {
    const empTasks = appData.tasks.filter(t => t.empId === emp.id);
    const doneCount = empTasks.filter(t => t.status && t.status.includes('Hoàn thành')).length;
    const doingCount = empTasks.filter(t => t.status && !t.status.includes('Hoàn thành') && t.status !== 'Tạm dừng' && t.status !== 'Dừng dự án').length;
    const total = empTasks.length;
    const rate = total > 0 ? Math.round(doneCount / total * 100) : 0;
    const kpiTotal = empTasks.reduce((sum, t) => sum + (t.kpiPoints || 0), 0);
    return [
      i + 1,
      emp.id || '',
      emp.name || '',
      emp.dept || emp.position || '',
      emp.email || '',
      emp.phone || '',
      total,
      doneCount,
      doingCount,
      rate,
      kpiTotal
    ];
  });

  const title = `DANH SÁCH NHÂN SỰ - MBC GROUP (Xuất: ${todayStr})`;
  let html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">`;
  html += `<head><meta charset="UTF-8"><style>`;
  html += `body{font-family:Arial,sans-serif;font-size:10pt;}`;
  html += `table{border-collapse:collapse;width:100%;}`;
  html += `td,th{border:1px solid #94a3b8;padding:4px 6px;vertical-align:middle;}`;
  html += `.title-row td{background:#164e63;color:white;font-weight:bold;font-size:13pt;text-align:center;border:none;padding:10px;}`;
  html += `.date-row td{background:#f0f9ff;color:#0369a1;font-size:9pt;text-align:right;border:none;padding:3px 6px;}`;
  html += `.header-row th{background:#0c4a6e;color:white;font-weight:bold;text-align:center;font-size:9pt;}`;
  html += `.data-row td{font-size:9pt;}`;
  html += `.data-row:nth-child(even) td{background:#f0f9ff;}`;
  html += `.num{text-align:center;}`;
  html += `.rate-good{color:#16a34a;font-weight:bold;text-align:center;}`;
  html += `.rate-mid{color:#d97706;font-weight:bold;text-align:center;}`;
  html += `.rate-low{color:#dc2626;font-weight:bold;text-align:center;}`;
  html += `</style></head><body>`;
  html += `<table>`;
  html += `<tr class="title-row"><td colspan="${headers.length}">${title}</td></tr>`;
  html += `<tr class="date-row"><td colspan="${headers.length}">Tổng nhân sự: ${rows.length} &nbsp;|&nbsp; Xuất lúc: ${todayStr}</td></tr>`;
  html += `<tr class="header-row">${headers.map(h => `<th>${h}</th>`).join('')}</tr>`;
  rows.forEach(r => {
    const rate = r[9];
    const rateClass = rate >= 80 ? 'rate-good' : rate >= 50 ? 'rate-mid' : 'rate-low';
    html += `<tr class="data-row">${r.map((cell, ci) => {
      let cls = '';
      if (ci >= 6 && ci <= 8) cls = 'num';
      if (ci === 9) cls = rateClass;
      if (ci === 10) cls = 'num';
      return `<td${cls ? ` class="${cls}"` : ''}>${String(cell).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}</td>`;
    }).join('')}</tr>`;
  });
  html += `</table></body></html>`;

  const blob = new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `DanhSach_NhanSu_MBC_${today.getFullYear()}${String(today.getMonth()+1).padStart(2,'0')}${String(today.getDate()).padStart(2,'0')}.xls`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast('✅ Đã xuất danh sách nhân sự ra Excel thành công!', 'success');
}

// ================= XUẤT NHẬT KÝ CẬP NHẬT TÌNH TRẠNG RA EXCEL =================
function exportStatusLogsToExcel() {
  const today = new Date();
  const todayStr = `${String(today.getDate()).padStart(2,'0')}/${String(today.getMonth()+1).padStart(2,'0')}/${today.getFullYear()}`;
  const todayFile = `${today.getFullYear()}${String(today.getMonth()+1).padStart(2,'0')}${String(today.getDate()).padStart(2,'0')}`;

  // Thu thập tất cả log từ toàn bộ tasks, mỗi log = 1 dòng
  const rows = [];
  let stt = 1;
  const sortedTasks = [...(appData.tasks || [])].sort((a, b) => (a.id || '').localeCompare(b.id || ''));

  sortedTasks.forEach(task => {
    const logs = Array.isArray(task.statusLogs) ? task.statusLogs : [];
    if (logs.length === 0) {
      // Task chưa có log nào — vẫn ghi 1 dòng để biết tình trạng
      rows.push({
        stt: stt++,
        taskId: task.id || '',
        taskTitle: task.mainTaskTitle || task.title || '',
        taskDetail: task.detail || '',
        empName: task.empName || '',
        taskStatus: task.status || '',
        logDate: '',
        logStatus: '',
        logProgress: '',
        logNote: '(Chưa có nhật ký cập nhật)',
        logAuthor: '',
        taskSource: task.taskSource || '',
        planEndDate: task.planEndDate || '',
        lastUpdate: task.lastStatusUpdate || ''
      });
    } else {
      // Sắp xếp log theo ngày tăng dần
      const sortedLogs = [...logs].sort((a, b) => (a.date || '').localeCompare(b.date || ''));
      sortedLogs.forEach(log => {
        rows.push({
          stt: stt++,
          taskId: task.id || '',
          taskTitle: task.mainTaskTitle || task.title || '',
          taskDetail: task.detail || '',
          empName: task.empName || '',
          taskStatus: task.status || '',
          logDate: formatVnDate(log.date) || log.date || '',
          logStatus: log.status || '',
          logProgress: log.progress !== undefined ? log.progress + '%' : '',
          logNote: log.note || '',
          logAuthor: log.author || '',
          taskSource: task.taskSource || '',
          planEndDate: formatVnDate(task.planEndDate) || '',
          lastUpdate: formatVnDate(task.lastStatusUpdate) || ''
        });
      });
    }
  });

  const headers = [
    'STT', 'Mã CV', 'Tên Công Việc', 'Nội Dung Chi Tiết',
    'Người Thực Hiện', 'Trạng Thái CV Hiện Tại',
    'Ngày Cập Nhật', 'Tình Trạng Báo Cáo', 'Tiến Độ (%)',
    'Nội Dung Ghi Chú', 'Người Cập Nhật',
    'Nguồn Yêu Cầu', 'Hạn Kế Hoạch', 'Cập Nhật Cuối'
  ];

  const statusColorMap = {
    'Hoàn thành': '#16a34a',
    'Hoàn thành trễ': '#d97706',
    'Đang làm': '#0369a1',
    'Tạm dừng': '#64748b',
    'Dừng dự án': '#dc2626'
  };

  const title = `NHẬT KÝ CẬP NHẬT TÌNH TRẠNG CÔNG VIỆC - MBC GROUP (Xuất: ${todayStr})`;
  let html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">`;
  html += `<head><meta charset="UTF-8"><style>`;
  html += `body{font-family:Arial,sans-serif;font-size:10pt;}`;
  html += `table{border-collapse:collapse;width:100%;}`;
  html += `td,th{border:1px solid #94a3b8;padding:4px 7px;vertical-align:middle;}`;
  html += `.title-row td{background:#312e81;color:white;font-weight:bold;font-size:13pt;text-align:center;border:none;padding:10px;}`;
  html += `.date-row td{background:#eef2ff;color:#4338ca;font-size:9pt;text-align:right;border:none;padding:3px 7px;}`;
  html += `.header-row th{background:#3730a3;color:white;font-weight:bold;text-align:center;font-size:9pt;white-space:nowrap;}`;
  html += `.data-row td{font-size:9pt;word-wrap:break-word;max-width:250px;}`;
  html += `.data-row:nth-child(even) td{background:#eef2ff;}`;
  html += `.no-log td{color:#94a3b8;font-style:italic;background:#f8fafc;}`;
  html += `.num{text-align:center;}`;
  html += `.pct{text-align:center;font-weight:bold;color:#0369a1;}`;
  html += `.s-done{color:#16a34a;font-weight:bold;} .s-late{color:#d97706;font-weight:bold;} .s-doing{color:#0369a1;} .s-pause{color:#64748b;} .s-stop{color:#dc2626;font-weight:bold;}`;
  html += `</style></head><body>`;
  html += `<table>`;
  html += `<tr class="title-row"><td colspan="${headers.length}">${title}</td></tr>`;
  html += `<tr class="date-row"><td colspan="${headers.length}">Tổng số dòng nhật ký: ${rows.length} &nbsp;|&nbsp; Tổng công việc: ${sortedTasks.length} &nbsp;|&nbsp; Xuất lúc: ${todayStr}</td></tr>`;
  html += `<tr class="header-row">${headers.map(h => `<th>${h}</th>`).join('')}</tr>`;

  rows.forEach(r => {
    const isNoLog = r.logNote === '(Chưa có nhật ký cập nhật)';
    const rowClass = isNoLog ? 'data-row no-log' : 'data-row';
    const escape = s => String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

    // Màu trạng thái CV
    let statusCls = '';
    const st = r.taskStatus;
    if (st && st.includes('Hoàn thành') && !st.includes('trễ')) statusCls = 's-done';
    else if (st && st.includes('trễ')) statusCls = 's-late';
    else if (st === 'Đang làm') statusCls = 's-doing';
    else if (st === 'Tạm dừng') statusCls = 's-pause';
    else if (st === 'Dừng dự án') statusCls = 's-stop';

    // Màu tình trạng báo cáo trong log
    let logStatusCls = '';
    const ls = r.logStatus;
    if (ls && ls.includes('Hoàn thành') && !ls.includes('trễ')) logStatusCls = 's-done';
    else if (ls && ls.includes('trễ')) logStatusCls = 's-late';
    else if (ls === 'Đang làm') logStatusCls = 's-doing';
    else if (ls === 'Tạm dừng') logStatusCls = 's-pause';

    html += `<tr class="${rowClass}">
      <td class="num">${r.stt}</td>
      <td class="num">${escape(r.taskId)}</td>
      <td>${escape(r.taskTitle)}</td>
      <td>${escape(r.taskDetail)}</td>
      <td>${escape(r.empName)}</td>
      <td class="${statusCls}">${escape(r.taskStatus)}</td>
      <td class="num">${escape(r.logDate)}</td>
      <td class="${logStatusCls}">${escape(r.logStatus)}</td>
      <td class="pct">${escape(r.logProgress)}</td>
      <td>${escape(r.logNote)}</td>
      <td>${escape(r.logAuthor)}</td>
      <td>${escape(r.taskSource)}</td>
      <td class="num">${escape(r.planEndDate)}</td>
      <td class="num">${escape(r.lastUpdate)}</td>
    </tr>`;
  });

  html += `</table></body></html>`;

  const blob = new Blob([html], { type: 'application/vnd.ms-excel;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `NhatKy_CapNhat_TinhTrang_MBC_${todayFile}.xls`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast('✅ Đã xuất Nhật Ký Cập Nhật Tình Trạng ra Excel thành công!', 'success');
}

function importDatabaseJson(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(evt) {
    try {
      const parsed = JSON.parse(evt.target.result);
      if (parsed && (parsed.employees || parsed.tasks || Array.isArray(parsed))) {
        if (Array.isArray(parsed)) {
          if (parsed.length > 0 && parsed[0].planDays !== undefined) {
            appData.tasks = parsed;
          } else if (parsed.length > 0 && parsed[0].dept !== undefined) {
            appData.employees = parsed;
          }
        } else {
          appData = parsed;
        }

        saveDataToStorage();
        closeSyncModal();
        updateAuthUI();
        renderEmployeeTable();
        applyFilters();
        alert('Khôi phục CSDL JSON thành công!');
      } else {
        alert('File JSON không đúng cấu trúc của ứng dụng!');
      }
    } catch (err) {
      alert('Lỗi đọc file JSON: ' + err.message);
    }
  };
  reader.readAsText(file);
}

function restoreDefaultDatabase() {
  const defaultSource = (typeof window !== 'undefined' && window.MBC_DEFAULT_DATABASE) ? window.MBC_DEFAULT_DATABASE : null;
  if (!defaultSource || !defaultSource.tasks || defaultSource.tasks.length === 0) {
    alert('Không tìm thấy file database.js trong thư mục ứng dụng!');
    return;
  }
  if (!confirm('Bạn có chắc muốn nạp lại CSDL gốc từ file database.js (Mặc định 2026-2027)? Toàn bộ dữ liệu hiện tại sẽ được cập nhật đồng bộ.')) {
    return;
  }

  appData = JSON.parse(JSON.stringify(defaultSource));
  saveDataToStorage();
  closeSyncModal();
  updateAuthUI();
  renderEmployeeTable();
  populateEmployeeSelects();
  applyFilters();
  alert(`Đã nạp thành công ${appData.tasks.length} công việc và ${appData.employees.length} nhân sự từ database.js!`);
}

function resetToSampleData() {
  restoreDefaultDatabase();
}

// ================= NHẬT KÝ CẬP NHẬT TÌNH TRẠNG (STATUS LOG MODAL) =================
function openStatusLogModal(taskId) {
  const task = appData.tasks.find(t => t.id === taskId);
  if (!task) return;
  document.getElementById('statusLogTaskId').value = task.id;
  document.getElementById('statusLogTaskName').innerText = `[${task.id}] ${task.mainTaskTitle || task.title} - ${task.empName}`;
  document.getElementById('statusLogStatus').value = task.status || 'Đang làm';
  document.getElementById('statusLogContent').value = '';
  document.getElementById('statusLogProgress').value = '';

  const now = new Date();
  const todayStr = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
  const dateInputEl = document.getElementById('statusLogDate');
  if (dateInputEl) dateInputEl.value = todayStr;

  const historyEl = document.getElementById('statusLogHistory');
  const logs = task.statusLogs || [];

  // Vẽ mini SVG progress chart nếu có dữ liệu
  const miniChartEl = document.getElementById('statusLogMiniChart');
  if (miniChartEl) {
    const logsWithProg = logs.filter(l => l.progress !== undefined && l.progress !== '');
    if (logsWithProg.length >= 2) {
      const W = 320, H = 80, PAD = 20;
      const maxX = logsWithProg.length - 1;
      const pts = logsWithProg.map((l, i) => {
        const x = PAD + (i / maxX) * (W - PAD * 2);
        const y = H - PAD - ((l.progress || 0) / 100) * (H - PAD * 2);
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      }).join(' ');
      const circles = logsWithProg.map((l, i) => {
        const x = PAD + (i / maxX) * (W - PAD * 2);
        const y = H - PAD - ((l.progress || 0) / 100) * (H - PAD * 2);
        return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="3" fill="#7c3aed" title="${formatVnDate(l.date)}: ${l.progress}%"/>`;
      }).join('');
      const labels = logsWithProg.map((l, i) => {
        const x = PAD + (i / maxX) * (W - PAD * 2);
        const y = H - PAD - ((l.progress || 0) / 100) * (H - PAD * 2);
        return `<text x="${x.toFixed(1)}" y="${(y - 5).toFixed(1)}" text-anchor="middle" font-size="8" fill="#6d28d9">${l.progress}%</text>`;
      }).join('');
      miniChartEl.innerHTML = `
        <div class="text-[10px] font-semibold text-violet-700 mb-1"><i class="fa-solid fa-chart-line mr-1"></i>Biểu đồ tiến độ theo các lần cập nhật:</div>
        <svg width="${W}" height="${H}" class="w-full" viewBox="0 0 ${W} ${H}" style="background:#f5f3ff;border-radius:8px;">
          <line x1="${PAD}" y1="${H-PAD}" x2="${W-PAD}" y2="${H-PAD}" stroke="#ddd6fe" stroke-width="1"/>
          <line x1="${PAD}" y1="${PAD}" x2="${PAD}" y2="${H-PAD}" stroke="#ddd6fe" stroke-width="1"/>
          <text x="${PAD-2}" y="${PAD+3}" text-anchor="end" font-size="7" fill="#9ca3af">100%</text>
          <text x="${PAD-2}" y="${H-PAD+3}" text-anchor="end" font-size="7" fill="#9ca3af">0%</text>
          <polyline points="${pts}" fill="none" stroke="#7c3aed" stroke-width="1.5" stroke-linejoin="round"/>
          ${circles}${labels}
        </svg>
      `;
      miniChartEl.classList.remove('hidden');
    } else {
      miniChartEl.innerHTML = '';
      miniChartEl.classList.add('hidden');
    }
  }

  if (logs.length === 0) {
    historyEl.innerHTML = '<div class="text-slate-400 text-center py-3 text-xs">Chưa có lịch sử cập nhật nào</div>';
  } else {
    historyEl.innerHTML = '';
    logs.slice().reverse().forEach(log => {
      const div = document.createElement('div');
      div.className = 'p-2 rounded-lg bg-white border border-slate-200 text-xs space-y-0.5 shadow-xs';
      const progressBadge = (log.progress !== undefined && log.progress !== '') ? `<span class="ml-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-50 text-amber-700 border border-amber-200">${log.progress}%</span>` : '';
      div.innerHTML = `
        <div class="flex items-center justify-between font-bold text-slate-700">
          <span class="text-violet-700"><i class="fa-regular fa-clock mr-1"></i>${formatVnDate(log.date) || log.date} ${progressBadge}</span>
          <span class="px-1.5 py-0.5 rounded text-[9px] font-semibold bg-violet-50 text-violet-700 border border-violet-200">${log.status || ''}</span>
        </div>
        <div class="text-slate-600 text-[11px]">${log.note ? log.note : '<em class="text-slate-400">Không ghi chú nội dung</em>'}</div>
        <div class="text-[9px] text-slate-400 text-right">Người cập nhật: ${log.author || 'Thành viên'}</div>
      `;
      historyEl.appendChild(div);
    });
  }

  document.getElementById('statusLogModal').classList.remove('hidden');
}

function closeStatusLogModal() {
  document.getElementById('statusLogModal').classList.add('hidden');
}

/**
 * Gia hạn theo dõi công việc thêm 3 ngày mà không ghi thêm note rác vào lịch sử
 */
function snoozeStatusUpdate(days = 3) {
  const taskId = document.getElementById('statusLogTaskId').value;
  const task = appData.tasks.find(t => t.id === taskId);
  if (!task) return;

  const now = new Date();
  const todayDefault = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;

  // Reset ngày cập nhật cuối về hôm nay để reset mốc cảnh báo quá hạn cập nhật
  task.lastStatusUpdate = todayDefault;
  // TUYỆT ĐỐI KHÔNG thêm note nào vào task.statusLogs theo đúng yêu cầu người dùng

  saveDataToStorage();
  closeStatusLogModal();
  applyFilters();
  showToast(`⏱️ Đã gia hạn theo dõi 3 ngày cho công việc [${task.id}], không ghi chú mới.`, 'info');
}

function saveStatusLog() {
  const taskId = document.getElementById('statusLogTaskId').value;
  const task = appData.tasks.find(t => t.id === taskId);
  if (!task) return;

  const note = document.getElementById('statusLogContent').value.trim();
  const status = document.getElementById('statusLogStatus').value;
  const progressRaw = document.getElementById('statusLogProgress') ? document.getElementById('statusLogProgress').value.trim() : '';
  const progress = progressRaw !== '' ? Math.min(100, Math.max(0, parseInt(progressRaw) || 0)) : undefined;

  // Dùng ngày người dùng chọn hoặc mặc định ngày thực tế hệ thống
  const now = new Date();
  const todayDefault = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
  const dateInputEl = document.getElementById('statusLogDate');
  const chosenDate = (dateInputEl && dateInputEl.value) ? dateInputEl.value : todayDefault;

  if (!task.statusLogs) task.statusLogs = [];
  const logEntry = {
    date: chosenDate,
    note: note,
    status: status,
    author: (appData.currentUser && appData.currentUser.name) ? appData.currentUser.name : 'Người dùng'
  };
  if (progress !== undefined) logEntry.progress = progress;
  task.statusLogs.push(logEntry);

  task.status = status;
  task.lastStatusUpdate = chosenDate;
  if (status.includes('Hoàn thành') && !task.actualEndDate) {
    task.actualEndDate = chosenDate;
  } else if (!status.includes('Hoàn thành') && task.actualEndDate) {
    task.actualEndDate = '';
  }

  saveDataToStorage();
  closeStatusLogModal();
  applyFilters();
  showToast('✅ Đã ghi nhận cập nhật tình trạng!', 'success');
}

// ================= MODAL GẮN LINK / TỆP CHO CÔNG VIỆC =================
function openEditTaskLinkModal(taskId) {
  const task = appData.tasks.find(t => t.id === taskId);
  if (!task) return;
  document.getElementById('taskLinkModalTaskId').value = task.id;
  const subTitle = document.getElementById('taskLinkModalSubTitle');
  if (subTitle) subTitle.innerText = `[${task.id}] ${task.mainTaskTitle || task.title} - ${task.empName}`;
  const input = document.getElementById('taskLinkModalInput');
  if (input) {
    input.value = task.link || '';
    setTimeout(() => input.focus(), 100);
  }
  document.getElementById('taskLinkModal').classList.remove('hidden');
}

function closeTaskLinkModal() {
  document.getElementById('taskLinkModal').classList.add('hidden');
}

function saveTaskLinkFromModal() {
  const taskId = document.getElementById('taskLinkModalTaskId').value;
  const task = appData.tasks.find(t => t.id === taskId);
  if (!task) return;
  const linkVal = autoCleanWindowsPath(document.getElementById('taskLinkModalInput').value);
  task.link = linkVal;
  saveDataToStorage();
  closeTaskLinkModal();
  applyFilters();
  showToast(linkVal ? '✅ Đã cập nhật đường dẫn liên kết cho công việc!' : 'ℹ️ Đã xóa liên kết công việc!', 'success');
}

// ================= LỊCH NGHỈ ĐẶC BIỆT & NGÀY LỄ (HOLIDAY MODAL) =================
function openHolidayModal() {
  renderHolidayList();
  document.getElementById('holidayModal').classList.remove('hidden');
}

function closeHolidayModal() {
  document.getElementById('holidayModal').classList.add('hidden');
  applyFilters();
}

function renderHolidayList() {
  const listEl = document.getElementById('holidayList');
  const countBadge = document.getElementById('holidayCountBadge');
  const holidays = appData.holidays || [];
  if (countBadge) countBadge.innerText = `(${holidays.length} ngày)`;

  if (holidays.length === 0) {
    listEl.innerHTML = '<div class="text-xs text-slate-400 text-center py-4">Chưa có ngày nghỉ nào được cài đặt</div>';
    return;
  }

  holidays.sort((a, b) => (a.date || '').localeCompare(b.date || ''));

  listEl.innerHTML = '';
  holidays.forEach(h => {
    const isNational = h.type === 'NATIONAL';
    const div = document.createElement('div');
    div.className = `flex items-center justify-between p-2.5 rounded-xl border text-xs ${isNational ? 'bg-red-50/70 border-red-200' : 'bg-purple-50/70 border-purple-200'} shadow-xs`;
    div.innerHTML = `
      <div class="flex items-center gap-2">
        <span class="w-3 h-3 rounded-full ${isNational ? 'bg-red-500' : 'bg-purple-500'} shrink-0"></span>
        <div>
          <span class="font-bold text-slate-800">${formatVnDate(h.date)}</span>
          <span class="text-slate-600 ml-2 font-medium">${h.name}</span>
        </div>
      </div>
      <div class="flex items-center gap-2">
        <span class="text-[10px] font-semibold px-2 py-0.5 rounded ${isNational ? 'bg-red-100 text-red-800 border border-red-300' : 'bg-purple-100 text-purple-800 border border-purple-300'}">
          ${isNational ? 'Lễ quốc gia' : 'Nghỉ đặc biệt'}
        </span>
        <button onclick="deleteHoliday('${h.date}')" class="text-slate-400 hover:text-rose-600 px-1 py-0.5 transition" title="Xóa ngày nghỉ">
          <i class="fa-solid fa-trash-can text-[11px]"></i>
        </button>
      </div>
    `;
    listEl.appendChild(div);
  });
}

function addHoliday() {
  const date = document.getElementById('holidayDate').value;
  const type = document.getElementById('holidayType').value;
  const name = document.getElementById('holidayName').value.trim();

  if (!date) {
    alert('Vui lòng chọn ngày nghỉ!');
    return;
  }
  if (!name) {
    alert('Vui lòng nhập tên / lý do ngày nghỉ!');
    return;
  }

  if (!appData.holidays) appData.holidays = [];
  const existing = appData.holidays.find(h => h.date === date);
  if (existing) {
    existing.name = name;
    existing.type = type;
  } else {
    appData.holidays.push({ date, name, type });
  }

  saveDataToStorage();
  document.getElementById('holidayName').value = '';
  document.getElementById('holidayDate').value = '';
  renderHolidayList();
}

function deleteHoliday(date) {
  if (!confirm(`Bạn có chắc muốn xóa ngày nghỉ ${formatVnDate(date)}?`)) return;
  appData.holidays = (appData.holidays || []).filter(h => h.date !== date);
  saveDataToStorage();
  renderHolidayList();
}

// ================= KHỞI ĐỘNG ỨNG DỤNG =================
window.addEventListener('DOMContentLoaded', async () => {
  await loadInitialData();
  const filterMonthInput = document.getElementById('filterMonth');
  if (filterMonthInput) filterMonthInput.value = viewState.filterMonth;

  const filterStatusSelect = document.getElementById('filterStatus');
  if (filterStatusSelect) filterStatusSelect.value = viewState.filterStatus;

  updateAuthUI();
  renderUserDropdown();
  populateEmployeeSelects();
  renderFilterMainTasksSelect();
  applyFilters();

  document.addEventListener('click', (e) => {
    const userDropdown = document.getElementById('userDropdown');
    if (userDropdown && !userDropdown.contains(e.target) && !e.target.closest('button[onclick="toggleUserDropdown()"]')) {
      userDropdown.classList.add('hidden');
    }
  });
});

// ================= QUICK LINKS (LIÊN KẾT NHANH) =================
const QUICK_LINKS_KEY = 'MBC_QUICK_LINKS';

function loadQuickLinks() {
  try {
    const raw = localStorage.getItem(QUICK_LINKS_KEY);
    return raw ? JSON.parse(raw) : [
      { id: 'ql1', name: '📁 Thư mục dự án', url: 'file:///C:/Users/12953 Bao/Desktop/desktop/work/Project/Python/BasicLearnPython/W3schools/Python Tutorial/GravityCode/MBC/QuanLyCongViecNhom/', desc: 'Thư mục chứa ứng dụng' },
      { id: 'ql2', name: '📋 Hướng dẫn sử dụng', url: 'HuongDanSuDung.md', desc: 'File hướng dẫn' }
    ];
  } catch { return []; }
}

function saveQuickLinks(links) {
  localStorage.setItem(QUICK_LINKS_KEY, JSON.stringify(links));
}

function openQuickLinksModal() {
  renderQuickLinksModal();
  document.getElementById('quickLinksModal').classList.remove('hidden');
}

function closeQuickLinksModal() {
  document.getElementById('quickLinksModal').classList.add('hidden');
}

function renderQuickLinksModal() {
  const links = loadQuickLinks();
  const listEl = document.getElementById('quickLinksList');
  if (!listEl) return;

  if (links.length === 0) {
    listEl.innerHTML = '<div class="text-slate-400 text-center py-4 text-xs">Chưa có liên kết nào. Thêm bên dưới!</div>';
    return;
  }

  listEl.innerHTML = '';
  links.forEach(link => {
    const div = document.createElement('div');
    div.className = 'flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 group transition';
    div.innerHTML = `
      <button onclick="openQuickLink('${encodeURIComponent(link.url)}')" class="flex-1 text-left min-w-0" title="${link.url}">
        <div class="font-semibold text-sm text-sky-700 truncate">${link.name}</div>
        <div class="text-[10px] text-slate-400 truncate">${link.url}</div>
        ${link.desc ? `<div class="text-[10px] text-slate-500 italic">${link.desc}</div>` : ''}
      </button>
      <button onclick="openQuickLink('${encodeURIComponent(link.url)}')" class="px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-sky-100 text-sky-700 hover:bg-sky-200 transition flex items-center gap-1 shrink-0">
        <i class="fa-solid fa-external-link-alt text-[10px]"></i> Mở
      </button>
      <button onclick="deleteQuickLink('${link.id}')" class="opacity-0 group-hover:opacity-100 transition text-rose-400 hover:text-rose-600 text-xs px-1.5" title="Xóa liên kết này">
        <i class="fa-solid fa-trash"></i>
      </button>
    `;
    listEl.appendChild(div);
  });
}

function openQuickLink(encodedUrl) {
  const url = decodeURIComponent(encodedUrl).trim();
  if (!url) return;
  // Xử lý đường dẫn file:/// và UNC (\\server\share)
  let finalUrl = url;
  if (url.startsWith('\\\\') || (url.length > 2 && url[1] === ':' && (url[2] === '\\' || url[2] === '/'))) {
    // Windows absolute path → convert to file:///
    finalUrl = 'file:///' + url.replace(/\\/g, '/');
  }
  window.open(finalUrl, '_blank');
}

function addQuickLink() {
  const nameEl = document.getElementById('qlNewName');
  const urlEl = document.getElementById('qlNewUrl');
  const descEl = document.getElementById('qlNewDesc');
  const name = nameEl ? nameEl.value.trim() : '';
  const url = urlEl ? urlEl.value.trim() : '';
  const desc = descEl ? descEl.value.trim() : '';

  if (!name) { showToast('⚠️ Vui lòng nhập tên liên kết!', 'warning'); return; }
  if (!url)  { showToast('⚠️ Vui lòng nhập đường dẫn!', 'warning'); return; }

  const links = loadQuickLinks();
  links.push({ id: 'ql' + Date.now(), name, url, desc });
  saveQuickLinks(links);
  if (nameEl) nameEl.value = '';
  if (urlEl) urlEl.value = '';
  if (descEl) descEl.value = '';
  renderQuickLinksModal();
  showToast('✅ Đã thêm liên kết: ' + name, 'success');
}

function deleteQuickLink(id) {
  const links = loadQuickLinks().filter(l => l.id !== id);
  saveQuickLinks(links);
  renderQuickLinksModal();
  showToast('🗑️ Đã xóa liên kết', 'success');
}

// ================= XÓA NHANH NHÂN VIÊN (BULK DELETE EMPLOYEE) =================
function _onEmpCheckboxChange() {
  _updateEmpBulkDeleteBtn();
  // Cập nhật trạng thái checkbox "Chọn tất cả"
  const all = Array.from(document.querySelectorAll('.emp-cb'));
  const checked = all.filter(cb => cb.checked);
  const selectAllCb = document.getElementById('empSelectAll');
  if (selectAllCb) {
    selectAllCb.checked = all.length > 0 && checked.length === all.length;
    selectAllCb.indeterminate = checked.length > 0 && checked.length < all.length;
  }
}

function _updateEmpBulkDeleteBtn() {
  const checked = Array.from(document.querySelectorAll('.emp-cb:checked'));
  const btn = document.getElementById('btnBulkDeleteEmp');
  const countEl = document.getElementById('empSelectedCount');
  if (btn) {
    if (checked.length > 0) {
      btn.classList.remove('hidden');
    } else {
      btn.classList.add('hidden');
    }
  }
  if (countEl) countEl.innerText = checked.length;
}

function toggleSelectAllEmployees(checked) {
  document.querySelectorAll('.emp-cb').forEach(cb => { cb.checked = checked; });
  _updateEmpBulkDeleteBtn();
}

function bulkDeleteEmployees() {
  const checked = Array.from(document.querySelectorAll('.emp-cb:checked'));
  if (checked.length === 0) return;
  const ids = checked.map(cb => cb.dataset.id);
  const names = ids.map(id => {
    const emp = appData.employees.find(e => e.id === id);
    return emp ? `${emp.name} (${id})` : id;
  });
  if (!confirm(`Bạn có chắc muốn xóa ${ids.length} nhân viên sau đây?\n\n${names.join('\n')}\n\n⚠️ Lưu ý: Các công việc của nhân viên này sẽ KHÔNG bị xóa theo.`)) return;
  appData.employees = appData.employees.filter(e => !ids.includes(e.id));
  saveDataToStorage();
  renderEmployeeTable();
  renderUserDropdown();
  applyFilters();
  showToast(`🗑️ Đã xóa ${ids.length} nhân viên`, 'success');
}

// ================= XÓA NHANH CÔNG VIỆC (BULK DELETE TASK) =================
let _bulkTaskList = []; // Cache danh sách task đang hiện trong modal

function openBulkDeleteTaskModal() {
  document.getElementById('bulkDeleteTaskModal').classList.remove('hidden');
  document.getElementById('bulkTaskSearchInput').value = '';
  document.getElementById('bulkTaskSelectAll').checked = false;
  _bulkTaskList = [...appData.tasks]; // Lấy toàn bộ task
  renderBulkTaskTable(_bulkTaskList);
  updateBulkTaskSelectionUI();
}

function closeBulkDeleteTaskModal() {
  document.getElementById('bulkDeleteTaskModal').classList.add('hidden');
  _bulkTaskList = [];
}

function renderBulkTaskTable(taskList) {
  const tbody = document.getElementById('bulkTaskTableBody');
  const totalEl = document.getElementById('bulkTaskTotalCount');
  if (!tbody) return;
  tbody.innerHTML = '';
  if (totalEl) totalEl.innerText = taskList.length;

  const statusColorMap = {
    'Hoàn thành': 'text-emerald-700 bg-emerald-50',
    'Đang thực hiện': 'text-sky-700 bg-sky-50',
    'Chờ xử lý': 'text-amber-700 bg-amber-50',
    'Tạm dừng': 'text-slate-600 bg-slate-100',
    'Quá hạn': 'text-rose-700 bg-rose-50',
  };

  taskList.forEach(task => {
    const statusClass = statusColorMap[task.status] || 'text-slate-600 bg-slate-50';
    const tr = document.createElement('tr');
    tr.className = 'hover:bg-rose-50/30 transition';
    tr.dataset.taskId = task.id;
    tr.innerHTML = `
      <td class="p-2 text-center">
        <input type="checkbox" class="bulk-task-cb w-3.5 h-3.5 cursor-pointer accent-rose-500" data-id="${task.id}" onchange="updateBulkTaskSelectionUI()">
      </td>
      <td class="p-2 font-semibold text-slate-800 max-w-[220px] truncate" title="${task.name}">${task.name || '(Chưa đặt tên)'}</td>
      <td class="p-2 text-slate-600">${task.empName || task.empId || '-'}</td>
      <td class="p-2 text-center text-slate-500">${task.startDate || '-'}</td>
      <td class="p-2 text-center text-slate-500">${task.planEndDate || '-'}</td>
      <td class="p-2 text-center font-bold text-indigo-600">${task.progress != null ? task.progress + '%' : '-'}</td>
      <td class="p-2 text-center"><span class="px-1.5 py-0.5 rounded text-[10px] font-semibold ${statusClass}">${task.status || '-'}</span></td>
    `;
    tbody.appendChild(tr);
  });

  updateBulkTaskSelectionUI();
}

function filterBulkTaskList() {
  const keyword = (document.getElementById('bulkTaskSearchInput').value || '').toLowerCase().trim();
  if (!keyword) {
    renderBulkTaskTable(appData.tasks);
    _bulkTaskList = [...appData.tasks];
    return;
  }
  const filtered = appData.tasks.filter(t =>
    (t.name || '').toLowerCase().includes(keyword) ||
    (t.empName || '').toLowerCase().includes(keyword) ||
    (t.empId || '').toLowerCase().includes(keyword) ||
    (t.status || '').toLowerCase().includes(keyword)
  );
  _bulkTaskList = filtered;
  renderBulkTaskTable(filtered);
}

function toggleSelectAllBulkTasks(checked) {
  document.querySelectorAll('.bulk-task-cb').forEach(cb => { cb.checked = checked; });
  updateBulkTaskSelectionUI();
}

function updateBulkTaskSelectionUI() {
  const all = Array.from(document.querySelectorAll('.bulk-task-cb'));
  const checked = all.filter(cb => cb.checked);

  const badge = document.getElementById('bulkTaskSelectedBadge');
  const deleteCount = document.getElementById('bulkTaskDeleteCount');
  const selectAllCb = document.getElementById('bulkTaskSelectAll');

  if (badge) badge.innerText = `Đã chọn: ${checked.length}`;
  if (deleteCount) deleteCount.innerText = checked.length;

  if (selectAllCb) {
    selectAllCb.checked = all.length > 0 && checked.length === all.length;
    selectAllCb.indeterminate = checked.length > 0 && checked.length < all.length;
  }
}

function executeBulkDeleteTasks() {
  const checked = Array.from(document.querySelectorAll('.bulk-task-cb:checked'));
  if (checked.length === 0) {
    showToast('⚠️ Chưa chọn công việc nào để xóa!', 'warning');
    return;
  }
  const ids = checked.map(cb => cb.dataset.id);
  if (!confirm(`Bạn có chắc muốn xóa ${ids.length} công việc đã chọn?\n\n⚠️ Hành động này không thể hoàn tác!`)) return;
  appData.tasks = appData.tasks.filter(t => !ids.includes(t.id));
  saveDataToStorage();
  closeBulkDeleteTaskModal();
  applyFilters();
  showToast(`🗑️ Đã xóa ${ids.length} công việc`, 'success');
}

// ================= XÓA NHANH CÔNG VIỆC TRÊN BẢNG GANTT CHÍNH =================
function _onGanttTaskCheckboxChange(input) {
  _updateGanttBulkDeleteUI();
}

function toggleSelectAllGanttTasks(checked) {
  const cbs = document.querySelectorAll('.gantt-task-cb');
  cbs.forEach(cb => { cb.checked = checked; });
  _updateGanttBulkDeleteUI();
}

function _updateGanttBulkDeleteUI() {
  const all = Array.from(document.querySelectorAll('.gantt-task-cb'));
  const checked = all.filter(cb => cb.checked);
  const btn = document.getElementById('ganttBulkDeleteBtn');
  const countEl = document.getElementById('ganttSelectedCount');
  const selectAllCb = document.getElementById('selectAllGanttTasks');

  if (countEl) countEl.innerText = checked.length;
  if (btn) {
    if (checked.length > 0) {
      btn.classList.remove('hidden');
    } else {
      btn.classList.add('hidden');
    }
  }
  if (selectAllCb) {
    selectAllCb.checked = all.length > 0 && checked.length === all.length;
    selectAllCb.indeterminate = checked.length > 0 && checked.length < all.length;
  }
}

function bulkDeleteGanttSelectedTasks() {
  const checked = Array.from(document.querySelectorAll('.gantt-task-cb:checked'));
  if (checked.length === 0) {
    showToast('⚠️ Vui lòng chọn ít nhất 1 công việc để xóa!', 'warning');
    return;
  }
  const ids = checked.map(cb => cb.dataset.id).filter(Boolean);
  const tasksToDelete = appData.tasks.filter(t => ids.includes(t.id));
  const previewNames = tasksToDelete.slice(0, 5).map(t => `• [${t.id}] ${t.title || t.mainTaskTitle || 'Công việc'}`).join('\n');
  const moreText = tasksToDelete.length > 5 ? `\n... và ${tasksToDelete.length - 5} công việc khác` : '';

  if (!confirm(`Bạn có chắc muốn xóa ${ids.length} công việc đã chọn trên bảng Gantt?\n\n${previewNames}${moreText}\n\n⚠️ Hành động này không thể hoàn tác!`)) {
    return;
  }

  appData.tasks = appData.tasks.filter(t => !ids.includes(t.id));
  saveDataToStorage();
  applyFilters();
  _updateGanttBulkDeleteUI();
  showToast(`🗑️ Đã xóa thành công ${ids.length} công việc!`, 'success');
}

// ================= HỖ TRỢ MỞ VÀ SAO CHÉP LIÊN KẾT / TỆP =================
// Chuẩn hóa và làm sạch đường dẫn Windows (UNC, ổ đĩa, URL, xóa sạch dấu ngoặc kép thừa)
function autoCleanWindowsPath(raw) {
  if (!raw) return '';
  let p = String(raw).trim();
  // Bóc tách dấu ngoặc kép thừa (", ') do người dùng Copy as path từ Explorer
  p = p.replace(/^[\s"\'“”]+|[\s"\'“”]+$/g, '');
  if (/^https?:\/\//i.test(p)) return p;

  // URL decode
  try { p = decodeURIComponent(p); } catch(e) {}
  p = p.replace(/^[\s"\'“”]+|[\s"\'“”]+$/g, '');
  p = p.replace(/\//g, '\\');
  // Bóc tách file: prefix
  p = p.replace(/^file:\\*/i, '');
  p = p.replace(/^[\s"\'“”]+|[\s"\'“”]+$/g, '');

  // Local drive: C:\...
  const driveMatch = p.match(/^\\*([a-zA-Z]:\\.*)$/);
  if (driveMatch) return driveMatch[1];

  // UNC path: \\server\share\...
  const rawClean = String(raw).trim().replace(/^[\s"\'“”]+|[\s"\'“”]+$/g, '');
  if (rawClean.startsWith('\\\\') || rawClean.startsWith('//') || rawClean.toLowerCase().startsWith('file://')) {
    const stripped = p.replace(/^\\+/, '');
    return '\\\\' + stripped;
  }
  return p;
}

function _normalizeWindowsPathForBridge(raw) {
  return autoCleanWindowsPath(raw);
}

// ================= MỞ TỆP / THƯ MỤC NATIVE WINDOWS (MICRO-BRIDGE & DUAL-CHANNEL) =================
function executeOpenFileBridge(rawPath) {
  if (!rawPath || !String(rawPath).trim()) {
    showToast('⚠️ Vui lòng nhập hoặc dán đường dẫn liên kết', 'warning');
    return;
  }
  const linkStr = String(rawPath).trim();

  // 1. URL Web (http / https) -> Mở tab mới
  if (/^https?:\/\//i.test(linkStr)) {
    window.open(linkStr, '_blank');
    return;
  }

  // 2. Local / UNC Windows Path
  const cleanLocalPath = autoCleanWindowsPath(linkStr);
  const targetUrl = `http://127.0.0.1:38271/open?path=${encodeURIComponent(cleanLocalPath)}`;

  // Tự động sao chép vào Clipboard trước để người dùng có thể Win+R dán bất cứ lúc nào
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(cleanLocalPath).catch(() => {});
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 2500);

  fetch(targetUrl, { signal: controller.signal })
    .then(res => res.json())
    .then(data => {
      clearTimeout(timeoutId);
      if (data && data.success) {
        const typeLabel = data.is_dir ? '📂 Thư mục Windows' : '📄 Tệp Office / Ứng dụng';
        const note = data.matched ? ' (Đã tự động so khớp tên đầy đủ)' : '';
        showToast(`🚀 Đã mở ${typeLabel}: "${data.path || cleanLocalPath}"${note}`, 'success');
      } else {
        const errMsg = (data && data.error) ? `\n(Chi tiết: ${data.error})` : '';
        showToast(`⚠️ Không tìm thấy đường dẫn: "${cleanLocalPath}"${errMsg}\n📋 Đã copy link vào Clipboard`, 'warning');
      }
    })
    .catch(() => {
      clearTimeout(timeoutId);
      // Fallback Kênh 2: Kích hoạt iframe ngầm (vượt qua hạn chế CORS sandbox của Chrome khi mở file:///)
      const ifr = document.createElement('iframe');
      ifr.style.display = 'none';
      ifr.src = targetUrl;
      document.body.appendChild(ifr);
      setTimeout(() => ifr.remove(), 2500);

      showToast(`🚀 Đã gửi lệnh mở tới File Helper: "${cleanLocalPath}"\n📋 Đã copy link vào Clipboard`, 'info');
    });
}

function openTaskFileLink(taskId) {
  const task = (appData.tasks || []).find(t => t.id === taskId);
  if (!task || !task.link || !task.link.trim()) {
    showToast('⚠️ Công việc này chưa có đường dẫn liên kết', 'warning');
    return;
  }
  executeOpenFileBridge(task.link);
}

function testOpenTaskLinkFromModal() {
  const input = document.getElementById('taskLinkModalInput');
  if (!input || !input.value.trim()) {
    showToast('⚠️ Vui lòng nhập đường dẫn để mở thử', 'warning');
    return;
  }
  executeOpenFileBridge(input.value);
}

function _fallbackLocalFileOpen(cleanLocalPath) {
  // Helper chưa chạy -> Sao chép đường dẫn vào Clipboard
  const msg = `⚠️ Chưa bật file helper!\n📋 Đã sao chép đường dẫn: "${cleanLocalPath}"\n\nCách mở ngay:\n• Nhấn Win+R rồi dán đường dẫn vào → Enter\n• Hoặc nhấp đúp "Chay_Ung_Dung_MBC.vbs" để bật helper tự động`;
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(cleanLocalPath)
      .then(() => showToast(msg, 'warning'))
      .catch(() => showToast(`📂 Đường dẫn: "${cleanLocalPath}"\n${msg}`, 'warning'));
  } else {
    showToast(`📂 Đường dẫn: "${cleanLocalPath}"\n${msg}`, 'warning');
  }
}


