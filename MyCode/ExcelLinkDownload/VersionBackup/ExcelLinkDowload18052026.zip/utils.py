# utils.py
def col_to_index(col_str: str) -> int:
    """
    Chuyển đổi ký tự cột Excel thành số (1-index)
    A -> 1, Z -> 26, AA -> 27, AB -> 28
    """
    if not col_str:
        return 1
    
    result = 0
    for c in col_str.upper().strip():
        if c.isalpha():
            result = result * 26 + (ord(c) - ord('A') + 1)
    
    return max(result, 1)