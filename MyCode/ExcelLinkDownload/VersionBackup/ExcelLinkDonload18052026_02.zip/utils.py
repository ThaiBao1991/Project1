# utils.py
import urllib.parse

def col_to_index(col_str: str) -> int:
    """
    Chuyển đổi ký tự cột Excel thành số (1-index)
    A -> 1, Z -> 26, AA -> 27, AB -> 28
    """
    if not col_str:
        return 1
    
    result = 0
    for c in col_str.upper().strip():
        if c.isalpha():
            result = result * 26 + (ord(c) - ord('A') + 1)
    
    return max(result, 1)


def clean_link(link: str) -> str:
    """
    Làm sạch link:
    - URL decode (%20 → space, %2C → ,, %5C → \, ...)
    - Giữ nguyên dấu , (không thay thế mù quáng)
    - Chuẩn hóa dấu \
    """
    if not link:
        return link
    
    # Bước 1: URL decode (quan trọng: %20 → space)
    try:
        link = urllib.parse.unquote(link)
    except Exception as e:
        print(f"Warning: URL decode failed: {e}")
    
    # Bước 2: Chuẩn hóa dấu \ (không nhân đôi)
    if link.startswith('\\\\'):
        # UNC path: giữ nguyên 2 dấu \ đầu, chỉ sửa các cặp \\ phía sau
        prefix = '\\\\'
        rest = link[2:]
        rest = rest.replace('\\\\', '\\')
        link = prefix + rest
    else:
        link = link.replace('\\\\', '\\')
    
    # Bước 3: Xóa dấu " thừa
    link = link.replace('"', '')
    
    # Bước 4: Loại bỏ khoảng trắng đầu cuối
    link = link.strip()
    
    return link


def generate_link_variants(link: str) -> list:
    """
    Tạo các biến thể của link để thử khi tải
    - Biến thể 1: link gốc
    - Biến thể 2: thay , bằng \
    - Biến thể 3: thay \ bằng ,
    """
    if not link:
        return []
    
    variants = [link]
    
    # Biến thể 2: thay , bằng \
    if ',' in link:
        variants.append(link.replace(',', '\\'))
    
    # Biến thể 3: thay \ bằng , (ít khả năng hơn)
    if '\\' in link and ',' not in link:
        variants.append(link.replace('\\', ','))
    
    # Loại bỏ trùng lặp
    variants = list(dict.fromkeys(variants))
    
    return variants