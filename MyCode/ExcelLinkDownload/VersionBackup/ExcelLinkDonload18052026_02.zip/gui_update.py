# gui_update.py
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import os
from excel.factory import create_reader
from log_manager import load_log

class UpdateTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.setup_ui()
    
    def setup_ui(self):
        frame1 = ttk.LabelFrame(self, text="File Excel cần cập nhật", padding=5)
        frame1.pack(fill=tk.X, padx=10, pady=10)
        
        self.excel_path = tk.StringVar()
        ttk.Entry(frame1, textvariable=self.excel_path, width=70).pack(side=tk.LEFT, padx=5)
        ttk.Button(frame1, text="Browse", command=self.browse_excel).pack(side=tk.LEFT, padx=5)
        
        frame2 = ttk.LabelFrame(self, text="File data (JSON)", padding=5)
        frame2.pack(fill=tk.X, padx=10, pady=10)
        
        self.json_path = tk.StringVar()
        ttk.Entry(frame2, textvariable=self.json_path, width=70).pack(side=tk.LEFT, padx=5)
        ttk.Button(frame2, text="Browse", command=self.browse_json).pack(side=tk.LEFT, padx=5)
        
        info_frame = ttk.LabelFrame(self, text="Thông tin", padding=5)
        info_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        self.info_text = tk.Text(info_frame, height=10, wrap=tk.WORD)
        scrollbar = ttk.Scrollbar(info_frame, orient=tk.VERTICAL, command=self.info_text.yview)
        self.info_text.configure(yscrollcommand=scrollbar.set)
        
        self.info_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        ttk.Button(self, text="CẬP NHẬT EXCEL", command=self.update_excel,
                  style="Accent.TButton").pack(pady=20)
        
        self.status_label = ttk.Label(self, text="Sẵn sàng")
        self.status_label.pack(pady=5)
    
    def browse_excel(self):
        filepath = filedialog.askopenfilename(
            title="Chọn file Excel cần cập nhật",
            filetypes=[("Excel files", "*.xlsx *.xlsm *.xls *.xlsb"), ("All files", "*.*")]
        )
        if filepath:
            self.excel_path.set(filepath)
            self.load_info()
    
    def browse_json(self):
        filepath = filedialog.askopenfilename(
            title="Chọn file JSON log",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")]
        )
        if filepath:
            self.json_path.set(filepath)
            self.load_info()
    
    def load_info(self):
        if not self.json_path.get():
            return
        
        log = load_log(os.path.dirname(self.json_path.get()))
        if not log:
            self.info_text.delete(1.0, tk.END)
            self.info_text.insert(tk.END, "Không thể đọc file JSON hoặc file không hợp lệ")
            return
        
        self.info_text.delete(1.0, tk.END)
        self.info_text.insert(tk.END, f"File Excel nguồn: {log.source_excel}\n")
        self.info_text.insert(tk.END, f"Cột dữ liệu: {log.data_column}\n")
        self.info_text.insert(tk.END, f"Cột tiêu đề: {log.title_column}\n")
        self.info_text.insert(tk.END, f"Tổng số file đã tải: {len(log.files)}\n\n")
        
        self.info_text.insert(tk.END, "Danh sách file (10 đầu):\n")
        for i, f in enumerate(log.files[:10]):
            self.info_text.insert(tk.END, f"  {i+1}. {f.title} → {f.new_link}\n")
    
    def update_excel(self):
        excel_file = self.excel_path.get()
        json_file = self.json_path.get()
        
        if not excel_file or not json_file:
            messagebox.showerror("Lỗi", "Vui lòng chọn đầy đủ file Excel và file JSON")
            return
        
        if not os.path.exists(excel_file):
            messagebox.showerror("Lỗi", "File Excel không tồn tại")
            return
        
        log = load_log(os.path.dirname(json_file))
        if not log:
            messagebox.showerror("Lỗi", "Không thể đọc file JSON")
            return
        
        try:
            reader = create_reader(excel_file)
        except Exception as e:
            messagebox.showerror("Lỗi", f"Không thể mở file Excel:\n{str(e)}")
            return
        
        data_col_idx = self._col_to_index(log.data_column)
        
        updated = 0
        failed = 0
        
        for file_info in log.files:
            if file_info.new_link and os.path.exists(file_info.new_link):
                try:
                    reader.update_cell(file_info.sheet, file_info.row, data_col_idx, file_info.new_link)
                    updated += 1
                    self.status_label.config(text=f"Đã cập nhật: {updated} file")
                    self.update_idletasks()
                except Exception as e:
                    failed += 1
                    print(f"Lỗi cập nhật dòng {file_info.row}: {e}")
        
        if updated > 0:
            reader.save()
            messagebox.showinfo("Kết quả", f"Cập nhật xong!\nThành công: {updated}\nThất bại: {failed}")
        else:
            messagebox.showinfo("Thông báo", "Không có file nào được cập nhật")
        
        reader.close()
        self.status_label.config(text=f"Hoàn thành! Đã cập nhật: {updated} | Thất bại: {failed}")
    
    def _col_to_index(self, col_str: str) -> int:
        """Chuyển 'A' -> 1, 'Z' -> 26, 'AA' -> 27"""
        result = 0
        for c in col_str.upper():
            result = result * 26 + (ord(c) - ord('A') + 1)
        return result